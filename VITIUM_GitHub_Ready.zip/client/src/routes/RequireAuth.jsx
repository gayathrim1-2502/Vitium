import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext.jsx';

export const ROLE_HOME = {
  engineer: '/dashboard',
  approver: '/reports',
  admin: '/dashboard',
  business: '/instruments',
};

export default function RequireAuth({ children }) {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center bg-cream">
        <div className="flex flex-col items-center gap-3">
          <div className="h-12 w-12 animate-spin rounded-full border-4 border-caramel border-t-transparent" />
          <p className="text-sm font-semibold text-forestsage">Loading your workspace…</p>
        </div>
      </div>
    );
  }
  if (!user) {
    return <Navigate to="/login" state={{ from: location.pathname }} replace />;
  }
  // Redirect users who manually navigate to another role's home
  if (location.pathname === '/' && ROLE_HOME[user.role]) {
    return <Navigate to={ROLE_HOME[user.role]} replace />;
  }
  return children;
}
