import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './auth/AuthContext.jsx';
import RequireAuth, { ROLE_HOME } from './routes/RequireAuth.jsx';
import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Instruments from './pages/Instruments.jsx';
import TestSessions from './pages/TestSessions.jsx';
import TestSessionWizard from './pages/TestSessionWizard.jsx';
import SessionReport from './pages/SessionReport.jsx';
import InstrumentDetail from './pages/InstrumentDetail.jsx';
import Analytics from './pages/Analytics.jsx';
import VerifyPage from './pages/VerifyPage.jsx';
import Reports from './pages/Reports.jsx';
import Users from './pages/Users.jsx';
import Settings from './pages/Settings.jsx';
import Knowledge from './pages/Knowledge.jsx';
import AppLayout from './components/AppLayout.jsx';

function HomeRedirect() {
  const { user } = useAuth();
  return <Navigate to={ROLE_HOME[user.role]} replace />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route
        path="/"
        element={
          <RequireAuth>
            <AppLayout />
          </RequireAuth>
        }
      >
        <Route index element={<HomeRedirect />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="instruments" element={<Instruments />} />
        <Route path="sessions" element={<TestSessions />} />
        <Route path="sessions/new" element={<TestSessions />} />
        <Route path="sessions/:id" element={<TestSessionWizard />} />
        <Route path="sessions/:id/report" element={<SessionReport />} />
        <Route path="instruments/:id" element={<InstrumentDetail />} />
        <Route path="analytics" element={<Analytics />} />
        <Route path="reports" element={<Reports />} />
        <Route path="users" element={<Users />} />
        <Route path="settings" element={<Settings />} />
        <Route path="knowledge" element={<Knowledge />} />
      </Route>
      {/* Public verification page — no auth, opened from QR codes */}
      <Route path="/verify/:reportUid" element={<VerifyPage />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
