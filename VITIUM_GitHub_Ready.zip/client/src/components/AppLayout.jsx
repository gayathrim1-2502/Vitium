import { useEffect, useRef, useState } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Scale, ClipboardList, FileCheck2, Users, Settings as SettingsIcon,
  BarChart3, LogOut, X, ChevronDown, QrCode, BookOpen,
} from 'lucide-react';
import logoUrl from '../assets/vitium-logo.png';
import { useAuth } from '../auth/AuthContext.jsx';
import NotificationBell from './NotificationBell.jsx';
import ScanQrModal from './ScanQrModal.jsx';
import Toast from './Toast.jsx';

const NAV_ITEMS = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['engineer', 'approver', 'admin'] },
  { to: '/instruments', label: 'Instruments', icon: Scale, roles: ['engineer', 'approver', 'admin', 'business'] },
  { to: '/sessions', label: 'Test Sessions', icon: ClipboardList, roles: ['engineer', 'approver', 'admin'] },
  { to: '/reports', label: 'Reports', icon: FileCheck2, roles: ['engineer', 'approver', 'admin', 'business'] },
  { to: '/analytics', label: 'Analytics', icon: BarChart3, roles: ['engineer', 'approver', 'admin'] },
  { to: '/knowledge', label: 'Instrument Info', icon: BookOpen, roles: ['engineer', 'approver', 'admin', 'business'] },
  { to: '/users', label: 'Users', icon: Users, roles: ['admin'] },
  { to: '/settings', label: 'Settings', icon: SettingsIcon, roles: ['admin'] },
];

// Presentation grouping only — the exact same destinations, labels, order
// and role rules as NAV_ITEMS; empty groups (filtered out by role) collapse.
const NAV_GROUPS = [
  { label: 'Workspace', items: ['/dashboard', '/instruments', '/sessions'] },
  { label: 'Reports & analytics', items: ['/reports', '/analytics'] },
  { label: 'Reference', items: ['/knowledge'] },
  { label: 'Administration', items: ['/users', '/settings'] },
];

const ROLE_BADGE = {
  engineer: { label: 'Test Engineer', cls: 'badge-teal' },
  approver: { label: 'Approver', cls: 'badge-amber' },
  admin: { label: 'Admin', cls: 'badge-blue' },
  business: { label: 'Instrument Owner', cls: 'badge-green' },
};

export default function AppLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scanOpen, setScanOpen] = useState(false);
  const [toast, setToast] = useState(null);
  const menuRef = useRef(null);
  const asideRef = useRef(null);
  const hamburgerRef = useRef(null);
  const closeButtonRef = useRef(null);
  const drawerWasOpen = useRef(false);

  // Responsive drawer: below lg the sidebar is an overlay. When it is
  // closed it must be inert, so keyboard focus never lands off-screen.
  const [isDesktop, setIsDesktop] = useState(() => window.matchMedia('(min-width: 1024px)').matches);
  const drawerHidden = !isDesktop && !sidebarOpen;

  useEffect(() => {
    const mq = window.matchMedia('(min-width: 1024px)');
    const onChange = (e) => setIsDesktop(e.matches);
    mq.addEventListener('change', onChange);
    setIsDesktop(mq.matches);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  // Move keyboard focus into the drawer when it opens (to its close button)
  // and back to the toggle when it closes, so focus never strands on an inert
  // off-screen element.
  useEffect(() => {
    if (sidebarOpen) {
      drawerWasOpen.current = true;
      closeButtonRef.current?.focus();
    } else if (drawerWasOpen.current) {
      drawerWasOpen.current = false;
      const active = document.activeElement;
      if (!active || active === document.body || asideRef.current?.contains(active)) {
        hamburgerRef.current?.focus();
      }
    }
  }, [sidebarOpen]);

  // Escape closes the account menu, else the mobile drawer (keyboard parity
  // with click-to-close).
  useEffect(() => {
    function onKey(e) {
      if (e.key !== 'Escape') return;
      if (menuOpen) setMenuOpen(false);
      else if (sidebarOpen) setSidebarOpen(false);
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [menuOpen, sidebarOpen]);

  // Account menu closes on outside click (same pattern as NotificationBell).
  useEffect(() => {
    if (!menuOpen) return undefined;
    function onDoc(e) {
      if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false);
    }
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, [menuOpen]);

  // Expose a global toast helper (used by the wizard for "Draft saved")
  useEffect(() => {
    window.nawiToast = (message, tone = 'success') => setToast({ id: Date.now(), message, tone });
    return () => { delete window.nawiToast; };
  }, []);

  // Dashboard quick action → open the QR scanner
  useEffect(() => {
    const open = () => setScanOpen(true);
    window.addEventListener('vitium:scan', open);
    return () => window.removeEventListener('vitium:scan', open);
  }, []);

  const nav = NAV_ITEMS.filter((item) => item.roles.includes(user.role));
  const badge = ROLE_BADGE[user.role] || { label: user.role, cls: 'badge-slate' };
  // Neutral fallback if a display name is missing — never invent an identity.
  const displayName = user.fullName || 'User';
  const initials = displayName.split(' ').map((p) => p[0]).join('').slice(0, 2).toUpperCase();
  const activeLabel = nav.find((n) => location.pathname.startsWith(n.to))?.label || 'VITIUM';

  useEffect(() => {
    document.title = `${activeLabel} · VITIUM`;
  }, [activeLabel]);

  function handleLogout() {
    logout();
    navigate('/login');
  }

  return (
    <div className="flex h-full">
      {/* Keyboard skip link — first tabbable element on every page. */}
      <a
        href="#main-content"
        className="skip-link"
      >
        Skip to content
      </a>
      {/* ---- Sidebar ---- */}
      <aside
        id="app-sidebar"
        ref={asideRef}
        className={`fixed inset-y-0 left-0 z-40 w-72 transform transition-transform duration-200 lg:static lg:translate-x-0 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
        style={{ backgroundImage: 'linear-gradient(180deg, #C88A5A 0%, #8B5E3C 60%, #6E4A2F 100%)' }}
        inert={drawerHidden ? '' : undefined}
        aria-hidden={drawerHidden || undefined}
      >
        <div className="flex h-full flex-col">
          {/* Logo */}
          <div className="flex items-center justify-between px-4 pb-6 pt-7">
            <div className="flex items-center gap-3">
              <img
                src={logoUrl}
                alt="VITIUM logo"
                className="h-11 w-11 shrink-0 rounded-2xl bg-cream/20 object-contain p-0.5 backdrop-blur"
              />
              <div>
                <p className="text-base font-extrabold tracking-tight text-cream">VITIUM</p>
                <p className="text-[11px] font-semibold text-softgold">Verification & Certification</p>
              </div>
            </div>
            <button
              ref={closeButtonRef}
              className="rounded-lg p-1.5 text-cream/80 hover:bg-cream/15 lg:hidden"
              onClick={() => setSidebarOpen(false)}
              aria-label="Close menu"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Nav — same destinations, labels and permissions, grouped */}
          <nav aria-label="Main navigation" className="flex-1 space-y-4 overflow-y-auto px-4 pb-4">
            {NAV_GROUPS.map((group) => {
              const items = group.items.map((to) => nav.find((n) => n.to === to)).filter(Boolean);
              if (items.length === 0) return null;
              return (
                <div key={group.label}>
                  <p className="nav-group-label">{group.label}</p>
                  <div className="space-y-1">
                    {items.map((item) => (
                      <NavLink
                        key={item.to}
                        to={item.to}
                        onClick={() => setSidebarOpen(false)}
                        className={({ isActive }) => `nav-link ${isActive ? 'nav-link-active' : ''}`}
                      >
                        <item.icon className="h-5 w-5 shrink-0" />
                        {item.label}
                      </NavLink>
                    ))}
                  </div>
                </div>
              );
            })}
          </nav>

          {/* User card */}
          <div className="border-t border-cream/15 p-4">
            <div className="flex items-center gap-3 rounded-xl bg-cream/10 px-3.5 py-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-softgold to-caramel text-sm font-extrabold text-espresso">
                {initials}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-bold text-cream">{displayName}</p>
                <span className={`badge ${badge.cls} mt-1 !px-2 !py-0.5 !text-[10px]`}>{badge.label}</span>
              </div>
              <button
                onClick={handleLogout}
                className="rounded-lg p-2 text-cream/80 transition-colors hover:bg-cream/15 hover:text-cream"
                title="Sign out"
                aria-label="Sign out"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
            <p className="mt-3 px-1 text-[10px] font-medium text-cream/60">
              VITIUM · Legal Metrology Platform
            </p>
          </div>
        </div>
      </aside>

      {/* Backdrop (mobile) */}
      {sidebarOpen && (
        <div
          className="modal-overlay z-30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* ---- Main column ---- */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 border-b border-softgold bg-sagecream/85 backdrop-blur">
          <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-2 px-4 py-3.5 sm:gap-x-4 sm:px-6 lg:px-8">
            <div className="flex min-w-0 items-center gap-3">
              <button
                ref={hamburgerRef}
                className="rounded-lg border border-softgold p-2 text-espresso transition-colors hover:bg-mutedgold/30 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-softgold lg:hidden"
                onClick={() => setSidebarOpen(true)}
                aria-label="Open menu"
                aria-expanded={sidebarOpen}
                aria-controls="app-sidebar"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
                  <path d="M3 6h18M3 12h18M3 18h13" />
                </svg>
              </button>
              <div className="min-w-0">
                <h1 className="text-lg font-extrabold leading-tight tracking-tight text-darkgreen">{activeLabel}</h1>
                {/* Full subtitle only where the header actions still fit on one
                    line; shorter one at tablet widths so the bar never wraps. */}
                <p className="hidden text-xs font-medium text-forestsage xl:block">Legal Metrology Instrument Verification & Certification Platform</p>
                <p className="text-xs font-medium text-forestsage xl:hidden">Verification & Certification</p>
              </div>
            </div>

            {/* Tighter gaps below sm keep the icon row inside a 320px viewport. */}
            <div className="flex shrink-0 items-center gap-1.5 sm:gap-3">
              <button
                onClick={() => setScanOpen(true)}
                className="btn-secondary px-2.5 sm:px-4"
                title="Scan an instrument QR code"
              >
                <QrCode className="h-4 w-4" />
                <span className="hidden sm:inline">Scan QR</span>
              </button>
              <NotificationBell />
              <span className="hidden items-center gap-1.5 rounded-full border border-softgold bg-mutedgold/30 px-3 py-1.5 text-xs font-bold text-errormocha md:inline-flex">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-sage" />
                R-76 mode
              </span>
              <div className="relative" ref={menuRef}>
                <button
                  onClick={() => setMenuOpen((o) => !o)}
                  className="flex h-10 items-center gap-2 rounded-xl border border-softgold bg-sagecream py-1 pl-1 pr-2.5 transition-all hover:shadow-md"
                  aria-expanded={menuOpen}
                  aria-label="Account menu"
                >
                  <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-caramel to-mocha text-xs font-extrabold text-cream">
                    {initials}
                  </span>
                  <span className="hidden text-sm font-bold text-espresso sm:block">{displayName.split(' ')[0]}</span>
                  <ChevronDown className="h-4 w-4 text-forestsage" />
                </button>
                {menuOpen && (
                  <div className="dropdown absolute right-0 w-56 p-2">
                    <div className="px-3 py-2">
                      <p className="text-sm font-bold text-darkgreen">{displayName}</p>
                      <p className="text-xs text-forestsage">{user.email}</p>
                    </div>
                    <button
                      onClick={handleLogout}
                      className="mt-1 flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-semibold text-errormocha transition-colors hover:bg-errormocha/10"
                    >
                      <LogOut className="h-4 w-4" /> Sign out
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </header>

        <main id="main-content" tabIndex={-1} key={location.pathname} className="page-enter flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <Outlet />
        </main>
        <Toast toast={toast} onDone={() => setToast(null)} />
      </div>
      <ScanQrModal open={scanOpen} onClose={() => setScanOpen(false)} />
    </div>
  );
}
