import { useEffect } from 'react';
import { CheckCircle2, Info, XCircle } from 'lucide-react';

const TONES = {
  success: { icon: CheckCircle2, cls: 'border-sage bg-sage/25 text-darkgreen', bar: 'bg-forestsage' },
  info: { icon: Info, cls: 'border-softgold bg-mutedgold/30 text-errormocha', bar: 'bg-caramel' },
  error: { icon: XCircle, cls: 'border-errormocha/40 bg-errormocha/15 text-errormocha', bar: 'bg-errormocha' },
};

export default function Toast({ toast, onDone }) {
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(onDone, 2600);
    return () => clearTimeout(t);
  }, [toast?.id]);

  if (!toast) return null;
  const tone = TONES[toast.tone] || TONES.success;
  return (
    <div className="pointer-events-none fixed inset-x-0 top-4 z-[80] flex justify-center px-4">
      <div key={toast.id} className={`toast pointer-events-auto flex items-center gap-2.5 rounded-2xl border px-4 py-3 shadow-xl ${tone.cls}`}>
        <tone.icon className="h-4.5 w-4.5 shrink-0" />
        <p className="text-sm font-bold">{toast.message}</p>
        <span className={`ml-1 h-1.5 w-1.5 rounded-full ${tone.bar} animate-pulse`} />
      </div>
    </div>
  );
}
