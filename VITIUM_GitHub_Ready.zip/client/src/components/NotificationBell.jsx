import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Bell, ClipboardCheck, CalendarClock, BadgeCheck, X, ShieldAlert, Info, TriangleAlert } from 'lucide-react';
import { api } from '../api.js';

const TYPE_META = {
  pending_approval: { icon: ClipboardCheck, ring: 'bg-sage/40 text-darkgreen' },
  cert_expiry: { icon: BadgeCheck, ring: 'bg-mutedgold/50 text-errormocha' },
  reverify: { icon: CalendarClock, ring: 'bg-softgold/45 text-mocha' },
};

const SEV_META = {
  danger: { icon: ShieldAlert, cls: 'text-errormocha' },
  warning: { icon: TriangleAlert, cls: 'text-errormocha' },
  info: { icon: Info, cls: 'text-forestsage' },
};

export default function NotificationBell() {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState([]);
  const ref = useRef(null);

  const load = () => api('/notifications').then((d) => setItems(d.notifications)).catch(() => {});
  useEffect(() => {
    load();
    const t = setInterval(load, 60000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    function onDoc(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    }
    function onKey(e) {
      if (e.key === 'Escape') setOpen(false);
    }
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('keydown', onKey);
    };
  }, []);

  async function dismiss(e, n) {
    e.stopPropagation();
    setItems((list) => list.filter((x) => !(x.type === n.type && x.instrumentId === n.instrumentId && x.title === n.title)));
    if (n.instrumentId && (n.type === 'cert_expiry' || n.type === 'reverify')) {
      try { await api('/notifications/dismiss', { method: 'POST', body: { instrumentId: n.instrumentId, type: n.type } }); } catch { /* noop */ }
    }
  }

  const count = items.length;
  const dot = items.some((n) => n.severity === 'danger') ? 'bg-errormocha' : items.some((n) => n.severity === 'warning') ? 'bg-mutedgold' : 'bg-sage';

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((o) => !o)}
        className="relative rounded-xl border border-softgold bg-sagecream p-2.5 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md"
        aria-label="Notifications"
        aria-haspopup="true"
        aria-expanded={open}
        title="Notifications"
      >
        <Bell className="h-4.5 w-4.5 text-mocha" />
        {count > 0 && (
          <span className={`absolute -right-1 -top-1 flex h-4.5 min-w-4.5 items-center justify-center rounded-full px-1 text-[10px] font-extrabold text-white ${dot} animate-pulse-ring`}>
            {count > 9 ? '9+' : count}
          </span>
        )}
      </button>

      {open && (
        <div className="dropdown absolute right-0 z-50 w-96 max-w-[92vw] overflow-hidden fade-up">
          <div className="flex items-center justify-between px-4 py-3" style={{ backgroundImage: 'linear-gradient(120deg, #C88A5A, #8B5E3C 55%, #6E4A2F)' }}>
            <p className="flex items-center gap-2 text-sm font-extrabold text-cream">
              <Bell className="h-4 w-4" /> Notifications
            </p>
            <button onClick={() => setOpen(false)} className="rounded-lg p-1 text-cream/80 hover:bg-cream/10"><X className="h-4 w-4" /></button>
          </div>
          <div className="max-h-96 overflow-y-auto">
            {items.length === 0 && (
              <p className="px-4 py-8 text-center text-sm font-medium text-forestsage">You're all caught up 🎉</p>
            )}
            {items.map((n, i) => {
              const meta = TYPE_META[n.type] || TYPE_META.pending_approval;
              const sev = SEV_META[n.severity] || SEV_META.info;
              return (
                <Link
                  key={`${n.type}-${n.instrumentId || n.link}-${i}`}
                  to={n.link}
                  onClick={() => setOpen(false)}
                  className="flex items-start gap-3 border-b border-softgold/50 px-4 py-3 transition-colors hover:bg-mutedgold/30"
                >
                  <span className={`mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${meta.ring}`}>
                    <meta.icon className="h-4.5 w-4.5" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-1.5">
                      <span className="truncate text-xs font-extrabold text-darkgreen">{n.title}</span>
                      <sev.icon className={`h-3.5 w-3.5 shrink-0 ${sev.cls}`} />
                    </span>
                    <span className="mt-0.5 block text-[11px] leading-snug text-forestsage">{n.detail}</span>
                  </span>
                  {(n.type === 'cert_expiry' || n.type === 'reverify') && (
                    <button onClick={(e) => dismiss(e, n)} className="mt-0.5 rounded-md p-1 text-forestsage/60 transition-colors hover:bg-mutedgold/30 hover:text-forestsage" title="Dismiss reminder">
                      <X className="h-3.5 w-3.5" />
                    </button>
                  )}
                </Link>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
