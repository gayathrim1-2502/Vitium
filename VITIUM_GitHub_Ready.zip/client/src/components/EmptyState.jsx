import { Link } from 'react-router-dom';

// Friendly, colorful empty-state illustration (pure CSS/SVG shapes).
export default function EmptyState({ icon: Icon, title, subtitle, ctaLabel, ctaTo, tone = 'teal' }) {
  const tones = {
    teal: { a: '#A8B89F', b: '#65745D', soft: '#E9E4D4' },
    blue: { a: '#C88A5A', b: '#D9B77A', soft: '#F5E6D3' },
    orange: { a: '#D6B98C', b: '#C88A5A', soft: '#F5E6D3' },
    violet: { a: '#8B5E3C', b: '#6E4A2F', soft: '#E9E4D4' },
  }[tone] || {};

  return (
    <div className="flex flex-col items-center justify-center py-16 text-center fade-up">
      <div className="relative mb-5 h-32 w-44">
        <div className="absolute inset-x-0 bottom-0 h-4 rounded-full bg-softgold/50" />
        <div
          className="absolute bottom-3 left-1/2 flex h-24 w-24 -translate-x-1/2 items-center justify-center rounded-3xl shadow-lg"
          style={{ background: `linear-gradient(135deg, ${tones.a}, ${tones.b})`, boxShadow: `0 12px 30px ${tones.b}44` }}
        >
          {Icon && <Icon className="h-11 w-11 text-cream" />}
        </div>
        <div className="absolute left-3 top-2 h-4 w-4 rounded-full opacity-80" style={{ backgroundColor: tones.b }} />
        <div className="absolute right-5 top-6 h-2.5 w-2.5 rounded-full" style={{ backgroundColor: tones.a }} />
        <div className="absolute right-2 top-1 h-5 w-5 rounded-lg rotate-12 opacity-25" style={{ backgroundColor: tones.a }} />
        <div className="absolute left-8 top-10 h-2 w-2 rounded-full bg-caramel" />
        <div className="absolute bottom-4 right-8 h-6 w-6 rounded-full border-4 opacity-30" style={{ borderColor: tones.a }} />
      </div>
      <h3 className="text-base font-extrabold tracking-tight text-darkgreen">{title}</h3>
      {subtitle && <p className="mt-1.5 max-w-sm text-sm text-forestsage">{subtitle}</p>}
      {ctaLabel && ctaTo && (
        <Link to={ctaTo} className="btn-primary mt-5">
          {ctaLabel}
        </Link>
      )}
    </div>
  );
}
