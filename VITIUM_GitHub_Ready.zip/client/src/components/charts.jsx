// Tiny dependency-free SVG chart components with the brand look.

export function LineChart({ data, height = 180, yLabel, limit }) {
  if (!data.length) return null;
  const W = 560;
  const H = height;
  const pad = { t: 14, r: 16, b: 26, l: 46 };
  const vals = data.map((d) => d.value).filter((v) => Number.isFinite(v));
  if (!vals.length) return null;
  const maxV = Math.max(...vals, limit ?? 0) * 1.15 || 1;
  const x = (i) => pad.l + (i * (W - pad.l - pad.r)) / Math.max(data.length - 1, 1);
  const y = (v) => pad.t + (1 - v / maxV) * (H - pad.t - pad.b);
  const pts = data.map((d, i) => ({ cx: x(i), cy: y(d.value), ...d }));
  const path = pts.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.cx.toFixed(1)},${p.cy.toFixed(1)}`).join(' ');
  const area = `${path} L${pts[pts.length - 1].cx.toFixed(1)},${H - pad.b} L${pts[0].cx.toFixed(1)},${H - pad.b} Z`;

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img">
      <defs>
        <linearGradient id="lc-fill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#A8B89F" stopOpacity="0.35" />
          <stop offset="100%" stopColor="#A8B89F" stopOpacity="0" />
        </linearGradient>
      </defs>
      {[0.25, 0.5, 0.75, 1].map((f) => (
        <line key={f} x1={pad.l} x2={W - pad.r} y1={y(maxV * f)} y2={y(maxV * f)} stroke="#D9B77A" strokeOpacity="0.45" strokeWidth="1" />
      ))}
      <path d={area} fill="url(#lc-fill)" />
      {Number.isFinite(limit) && limit > 0 && (
        <>
          <line x1={pad.l} x2={W - pad.r} y1={y(limit)} y2={y(limit)} stroke="#6E4A2F" strokeWidth="1.5" strokeDasharray="6 4" />
          <text x={W - pad.r} y={y(limit) - 5} textAnchor="end" fontSize="10" fontWeight="700" fill="#6E4A2F">MPE {Number(limit.toFixed(4))} kg</text>
        </>
      )}
      <path d={path} fill="none" stroke="#C88A5A" strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round" />
      {pts.map((p, i) => (
        <g key={i}>
          <circle cx={p.cx} cy={p.cy} r="4.5" fill="#F5E6D3" stroke={p.verdict === 'fail' ? '#6E4A2F' : '#C88A5A'} strokeWidth="2.5" />
          <title>{`${p.label}: ${p.value} kg${p.verdict ? ` (${p.verdict})` : ''}`}</title>
        </g>
      ))}
      {pts.map((p, i) => (
        i % Math.ceil(pts.length / 6) === 0 || i === pts.length - 1 ? (
          <text key={i} x={p.cx} y={H - 8} textAnchor="middle" fontSize="10.5" fill="#65745D">{p.label}</text>
        ) : null
      ))}
      <text x={12} y={pad.t + 4} fontSize="10.5" fill="#65745D" transform={`rotate(0)`}>{yLabel}</text>
    </svg>
  );
}

export function BarChart({ data, height = 190, color = '#C88A5A', suffix = '' }) {
  if (!data.length) return null;
  const W = 560;
  const H = height;
  const pad = { t: 16, r: 16, b: 30, l: 34 };
  const maxV = Math.max(...data.map((d) => d.value)) || 1;
  const bw = (W - pad.l - pad.r) / data.length;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img">
      {[0.5, 1].map((f) => (
        <line key={f} x1={pad.l} x2={W - pad.r} y1={pad.t + (1 - f) * (H - pad.t - pad.b)} y2={pad.t + (1 - f) * (H - pad.t - pad.b)} stroke="#D9B77A" strokeOpacity="0.45" />
      ))}
      {data.map((d, i) => {
        const h = (d.value / maxV) * (H - pad.t - pad.b);
        const bx = pad.l + i * bw + bw * 0.18;
        const by = H - pad.b - h;
        return (
          <g key={i}>
            <rect x={bx} y={by} width={bw * 0.64} height={Math.max(h, 2)} rx="5" fill={d.color || color} opacity="0.92">
              <title>{`${d.label}: ${d.value}${suffix}`}</title>
            </rect>
            <text x={bx + bw * 0.32} y={by - 5} textAnchor="middle" fontSize="10.5" fontWeight="800" fill="#30382F">{d.value}{suffix === '%' ? '%' : ''}</text>
            <text x={bx + bw * 0.32} y={H - 10} textAnchor="middle" fontSize="10.5" fill="#65745D">{d.label}</text>
          </g>
        );
      })}
    </svg>
  );
}

export function StackedBars({ data, height = 190 }) {
  if (!data.length) return null;
  const W = 560;
  const H = height;
  const pad = { t: 16, r: 16, b: 30, l: 34 };
  const maxV = Math.max(...data.map((d) => d.approved + d.rejected + d.other)) || 1;
  const bw = (W - pad.l - pad.r) / data.length;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img">
      {[0.5, 1].map((f) => (
        <line key={f} x1={pad.l} x2={W - pad.r} y1={pad.t + (1 - f) * (H - pad.t - pad.b)} y2={pad.t + (1 - f) * (H - pad.t - pad.b)} stroke="#D9B77A" strokeOpacity="0.45" />
      ))}
      {data.map((d, i) => {
        const total = d.approved + d.rejected + (d.other || 0);
        const hApp = (d.approved / maxV) * (H - pad.t - pad.b);
        const hRej = (d.rejected / maxV) * (H - pad.t - pad.b);
        const hOth = ((d.other || 0) / maxV) * (H - pad.t - pad.b);
        const bx = pad.l + i * bw + bw * 0.18;
        let cy = H - pad.b;
        cy -= hOth;
        const oy = cy;
        cy -= hApp;
        const ay = cy;
        cy -= hRej;
        return (
          <g key={i}>
            {hOth > 0 && <rect x={bx} y={oy} width={bw * 0.64} height={hOth} rx="3" fill="#D9B77A" opacity="0.9"><title>{`${d.label}: ${d.other} in progress/other`}</title></rect>}
            {hApp > 0 && <rect x={bx} y={ay} width={bw * 0.64} height={hApp} rx="3" fill="#A8B89F"><title>{`${d.label}: ${d.approved} approved`}</title></rect>}
            {hRej > 0 && <rect x={bx} y={cy + 0.5} width={bw * 0.64} height={Math.max(hRej - 0.5, 0)} rx="3" fill="#6E4A2F"><title>{`${d.label}: ${d.rejected} rejected`}</title></rect>}
            <text x={bx + bw * 0.32} y={pad.t + (1 - total / maxV) * (H - pad.t - pad.b) - 5} textAnchor="middle" fontSize="10.5" fontWeight="800" fill="#30382F">{total}</text>
            <text x={bx + bw * 0.32} y={H - 10} textAnchor="middle" fontSize="10.5" fill="#65745D">{d.label}</text>
          </g>
        );
      })}
    </svg>
  );
}

export function Legend({ items }) {
  return (
    <div className="flex flex-wrap items-center gap-3">
      {items.map((it) => (
        <span key={it.label} className="inline-flex items-center gap-1.5 text-[11px] font-bold text-forestsage">
          <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: it.color }} />
          {it.label}
        </span>
      ))}
    </div>
  );
}
