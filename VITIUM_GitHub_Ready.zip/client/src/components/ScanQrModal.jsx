import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Camera, Keyboard, ScanLine, AlertTriangle } from 'lucide-react';
import { api } from '../api.js';
import useDialogFocus from '../lib/useDialogFocus.js';

export default function ScanQrModal({ open, onClose }) {
  const navigate = useNavigate();
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const rafRef = useRef(0);
  const [mode, setMode] = useState('camera'); // 'camera' | 'manual'
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');
  const [manualCode, setManualCode] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) {
      stopCamera();
      setError('');
      setStatus('');
      setManualCode('');
      setMode('camera');
    }
  }, [open]);

  useEffect(() => {
    if (open && mode === 'camera') startCamera();
    return () => stopCamera();
  }, [open, mode]);

  // Focus + Escape are handled by the shared dialog hook.
  const panelRef = useDialogFocus(open, onClose);

  async function startCamera() {
    setError('');
    setStatus('Starting camera…');
    if (!navigator.mediaDevices?.getUserMedia) {
      setError('Camera is not supported in this browser. Use manual entry instead.');
      setStatus('');
      return;
    }
    if (!('BarcodeDetector' in window)) {
      setError('Live scanning needs a Chromium browser. Use “Enter code manually” — it works everywhere.');
      setMode('manual');
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setStatus('Point the camera at the instrument QR code…');
      tick();
    } catch {
      setError('Unable to access the camera. Check permissions, or enter the instrument code manually.');
      setStatus('');
    }
  }

  function stopCamera() {
    cancelAnimationFrame(rafRef.current);
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  }

  async function tick() {
    if (!streamRef.current || !videoRef.current) return;
    try {
      const detector = new window.BarcodeDetector({ formats: ['qr_code'] });
      const bitmap = await createImageBitmap(videoRef.current);
      const codes = await detector.detect(bitmap);
      bitmap.close?.();
      if (codes.length && codes[0].rawValue) {
        handleCode(codes[0].rawValue);
        return;
      }
    } catch { /* keep scanning */ }
    rafRef.current = requestAnimationFrame(() => setTimeout(tick, 250));
  }

  async function handleCode(raw) {
    if (busy) return;
    setBusy(true);
    stopCamera();
    // Accept both the raw payload (VITIUM-INS:VTM-INS-000001) and the bare code
    const code = String(raw || '').trim().toUpperCase().replace(/^VITIUM-INS:/, '');
    try {
      const { instrumentId } = await api(`/instruments/code/${encodeURIComponent(code)}`);
      onClose();
      navigate(`/instruments/${instrumentId}`);
    } catch (err) {
      setError(err.message);
      setBusy(false);
      if (mode === 'camera') startCamera();
    }
  }

  if (!open) return null;

  return (
    <div className="modal-overlay flex items-center justify-center p-4 bg-darkgreen/60" onClick={onClose}>
      <div ref={panelRef} tabIndex={-1} role="dialog" aria-modal="true" aria-label="Scan Instrument QR" className="card card-flush w-full max-w-md fade-up overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header" style={{ backgroundImage: 'linear-gradient(120deg, #C88A5A, #8B5E3C 60%, #6E4A2F)' }}>
          <h3 className="modal-title flex items-center gap-2 text-cream"><ScanLine className="h-5 w-5" /> Scan Instrument QR</h3>
          <button onClick={onClose} className="modal-close text-cream/80 hover:bg-cream/10 hover:text-cream" aria-label="Close scanner"><X className="h-5 w-5" /></button>
        </div>

        <div className="space-y-4 p-5">
          {error && (
            <div className="flex items-start gap-2 alert-error" role="alert">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" /> {error}
            </div>
          )}
          {status && !error && <p className="text-center text-xs font-semibold text-forestsage">{status}</p>}

          {mode === 'camera' ? (
            <div className="relative overflow-hidden rounded-xl border border-softgold bg-darkgreen/90">
              <video ref={videoRef} className="h-56 w-full object-cover" muted playsInline />
              <div className="pointer-events-none absolute inset-8 rounded-lg border-2 border-softgold/80" />
              {busy && <div className="absolute inset-0 flex items-center justify-center bg-cream/80 text-sm font-bold text-mocha">Opening instrument…</div>}
            </div>
          ) : (
            <form
              onSubmit={(e) => { e.preventDefault(); if (manualCode.trim()) handleCode(manualCode); }}
              className="space-y-3"
            >
              <label className="block text-xs font-bold uppercase tracking-wide text-forestsage" htmlFor="scan-code">Instrument code</label>
              <input
                id="scan-code"
                className="input font-mono"
                placeholder="VTM-INS-000001"
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                autoFocus
              />
              <button type="submit" disabled={busy || !manualCode.trim()} className="btn-primary w-full">
                {busy ? <><span className="btn-spinner" /> Opening…</> : 'Open instrument profile'}
              </button>
            </form>
          )}

          <div className="flex items-center justify-center gap-2 border-t border-softgold pt-3 text-xs font-bold">
            <button
              onClick={() => setMode(mode === 'camera' ? 'manual' : 'camera')}
              className="inline-flex items-center gap-1.5 text-caramel hover:text-mocha"
            >
              {mode === 'camera' ? <><Keyboard className="h-4 w-4" /> Enter code manually</> : <><Camera className="h-4 w-4" /> Use camera</>}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
