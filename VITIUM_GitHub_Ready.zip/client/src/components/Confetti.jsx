import { useEffect } from 'react';
import confetti from 'canvas-confetti';

// Brand-colored celebratory burst. Render (once) when approval lands.
export default function Confetti({ fire = true, duration = 1600 }) {
  useEffect(() => {
    if (!fire) return;
    const colors = ['#C88A5A', '#8B5E3C', '#D9B77A', '#D6B98C', '#A8B89F', '#F5E6D3'];
    const end = Date.now() + duration;
    (function frame() {
      confetti({ particleCount: 5, angle: 60, spread: 60, origin: { x: 0, y: 0.7 }, colors, disableForReducedMotion: true });
      confetti({ particleCount: 5, angle: 120, spread: 60, origin: { x: 1, y: 0.7 }, colors, disableForReducedMotion: true });
      if (Date.now() < end) requestAnimationFrame(frame);
    })();
    confetti({ particleCount: 120, spread: 100, origin: { y: 0.6 }, colors, disableForReducedMotion: true });
    return () => {};
  }, [fire, duration]);
  return null;
}
