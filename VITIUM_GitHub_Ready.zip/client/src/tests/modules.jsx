import {
  ClipboardCheck, Repeat, Grid3X3, Signal, Scale, Crosshair, Scale as TareIcon,
  IndianRupee, Thermometer,
} from 'lucide-react';

// Step colors drawn from the Warm Cream & Sage palette (caramel / gold / sage family).
export const TEST_MODULES = [
  { key: 'visual', label: 'Visual Inspection', short: 'Visual', icon: ClipboardCheck, color: '#C88A5A', soft: 'bg-caramel/10 text-mocha' },
  { key: 'repeatability', label: 'Repeatability Test', short: 'Repeat', icon: Repeat, color: '#D9B77A', soft: 'bg-softgold/25 text-errormocha' },
  { key: 'eccentricity', label: 'Eccentricity (Corner Load)', short: 'Eccent.', icon: Grid3X3, color: '#A8B89F', soft: 'bg-sage/25 text-darkgreen' },
  { key: 'discrimination', label: 'Discrimination Test', short: 'Discrim.', icon: Signal, color: '#8B5E3C', soft: 'bg-mocha/10 text-mocha' },
  { key: 'weighing', label: 'Weighing / Accuracy Test', short: 'Weighing', icon: Scale, color: '#6E4A2F', soft: 'bg-errormocha/10 text-errormocha' },
  { key: 'zero', label: 'Zero-Setting & Zero-Tracking', short: 'Zero', icon: Crosshair, color: '#65745D', soft: 'bg-forestsage/10 text-forestsage' },
  { key: 'tare', label: 'Accuracy of Tare Setting', short: 'Tare', icon: TareIcon, color: '#D6B98C', soft: 'bg-mutedgold/25 text-errormocha' },
  { key: 'price', label: 'Price Computation Accuracy', short: 'Price', icon: IndianRupee, color: '#B07B4F', soft: 'bg-caramel/15 text-mocha' },
  { key: 'influence', label: 'Influence Factors', short: 'Influence', icon: Thermometer, color: '#93A88A', soft: 'bg-sage/20 text-darkgreen' },
];

export const MODULE_ORDER = TEST_MODULES.map((m) => m.key);

export function moduleMeta(key) {
  return TEST_MODULES.find((m) => m.key === key) || { key, label: key, short: key, icon: Scale, color: '#65745D', soft: 'bg-softgold/30 text-forestsage' };
}
