import { Fragment } from 'react';
import { Lightbulb } from 'lucide-react';
import { evaluateModule } from './evaluate.js';
import PassBadge from './PassBadge.jsx';

function Suggestion({ children }) {
  return (
    <div className="flex items-start gap-2 rounded-xl border border-softgold bg-mutedgold/30 px-3.5 py-2.5 text-xs font-medium text-errormocha">
      <Lightbulb className="mt-0.5 h-3.5 w-3.5 shrink-0 text-caramel" />
      <span>{children}</span>
    </div>
  );
}

function Num({ value, onChange, ph = '0.00', step = 'any', id }) {
  return (
    <input
      id={id}
      type="number"
      step={step}
      className="input"
      placeholder={ph}
      value={value ?? ''}
      onChange={(e) => onChange(e.target.value === '' ? null : Number(e.target.value))}
    />
  );
}

const th = 'px-3 py-2 text-left text-[11px] font-bold uppercase tracking-wider text-forestsage border-b border-softgold';
const td = 'px-3 py-2 border-b border-softgold/40';

export default function ModuleForms({ moduleKey, data, update, loadPoints, instrument }) {
  const set = (patch) => update({ ...data, ...patch });
  const evaluation = instrument ? evaluateModule(moduleKey, data, instrument) : { checks: [], verdict: null };
  const checkFor = (key) => evaluation.checks.find((c) => String(c.key) === String(key));
  const verdictOf = (c) => (c === undefined || c === null || c.pass === null || c.pass === undefined) ? null : c.pass ? 'pass' : 'fail';

  switch (moduleKey) {
    /* ---------------- 1. Visual / Administrative ---------------- */
    case 'visual': {
      const keys = [
        ['nameplateLegible', 'Nameplate legible & correct'],
        ['classMarking', 'Accuracy class marked'],
        ['levelIndicator', 'Level indicator working'],
        ['stampArea', 'Stamping area present'],
        ['dashProof', 'Instruments facilities (R-76 A.2.2)'],
        ['noDirtDamage', 'No dirt / mechanical damage'],
      ];
      return (
        <div className="space-y-4">
          <Suggestion>Verify nameplate, accuracy class marking, verification stamp area and leveling indicators before testing.</Suggestion>
          <div className="grid gap-3 sm:grid-cols-2">
            {keys.map(([key, label]) => {
              const c = checkFor(key);
              return (
                <div key={key} className={`flex items-center gap-3 rounded-xl border px-4 py-3 text-sm font-semibold transition-colors ${c?.pass === false ? 'border-errormocha/40 bg-errormocha/10' : c?.pass ? 'border-sage bg-sage/20' : 'border-softgold/60'}`}>
                  {/* The label wraps the box and its text, so the whole row is a
                      comfortable tap target and the checkbox has an accessible name. */}
                  <label className="flex flex-1 cursor-pointer items-center gap-3">
                    <input type="checkbox" checked={!!data[key]} onChange={(e) => set({ [key]: e.target.checked })} className="h-4 w-4 shrink-0 accent-mocha" />
                    <span className="flex-1 text-espresso">{label}</span>
                  </label>
                  <PassBadge verdict={verdictOf(c)} />
                </div>
              );
            })}
          </div>
          <div>
            <label className="field-label" htmlFor="mf-notes">Inspector Notes</label>
            <textarea id="mf-notes" className="input min-h-20" value={data.notes || ''} onChange={(e) => set({ notes: e.target.value })} placeholder="Observations, defects, marking details…" />
          </div>
        </div>
      );
    }

    /* ---------------- 2. Repeatability ---------------- */
    case 'repeatability':
      return (
        <div className="space-y-4">
          <Suggestion>
            Suggested loads: {(loadPoints?.repeatability?.loads || []).map((l) => `${l} kg`).join(', ')} — {loadPoints?.repeatability?.readings ?? 3} readings per load. Spread the load on the load receiver.
          </Suggestion>
          {(data.readings || []).map((row, i) => {
            const c = checkFor(i);
            return (
              <div key={i} className={`rounded-xl border p-4 ${c?.pass === false ? 'border-errormocha/40 bg-errormocha/10' : 'border-softgold/60'}`}>
                <div className="mb-2.5 flex items-center justify-between">
                  <p className="card-title">Load {i + 1}</p>
                  <div className="flex items-center gap-2">
                    {c?.spread !== undefined && c?.pass !== null && (
                      <span className="text-xs font-semibold text-forestsage">spread {c.spread.toFixed(4)} kg</span>
                    )}
                    <PassBadge verdict={verdictOf(c)} />
                    {(data.readings || []).length > 1 && (
                      <button type="button" className="text-xs font-bold text-errormocha hover:text-mocha" onClick={() => set({ readings: data.readings.filter((_, j) => j !== i) })}>
                        Remove
                      </button>
                    )}
                  </div>
                </div>
                <div className="grid gap-3 sm:grid-cols-4">
                  <div>
                    <label className="field-label-sm" htmlFor={`rep-${i}-load`}>Load (kg)</label>
                    <Num id={`rep-${i}-load`} value={row.load} onChange={(v) => { const r = [...data.readings]; r[i] = { ...r[i], load: v }; set({ readings: r }); }} />
                  </div>
                  {[1, 2, 3].map((n) => (
                    <div key={n}>
                      <label className="field-label-sm" htmlFor={`rep-${i}-r${n}`}>Reading {n} (kg)</label>
                      <Num id={`rep-${i}-r${n}`} value={row[`r${n}`]} onChange={(v) => { const r = [...data.readings]; r[i] = { ...r[i], [`r${n}`]: v }; set({ readings: r }); }} />
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
          <button type="button" className="btn-secondary btn-sm" onClick={() => set({ readings: [...(data.readings || []), { load: null, r1: null, r2: null, r3: null }] })}>
            + Add load block
          </button>
        </div>
      );

    /* ---------------- 3. Eccentricity ---------------- */
    case 'eccentricity': {
      const positions = loadPoints?.eccentricity?.positions || ['Center', 'Front-Left', 'Front-Right', 'Back-Left', 'Back-Right'];
      return (
        <div className="space-y-4">
          <Suggestion>Use 1/3 of Max capacity ({loadPoints?.eccentricity?.load ?? '—'} kg) at each of the 5 positions. Each error must stay within MPE (shown live as you type).</Suggestion>
          <table className="w-full text-sm">
            <thead>
              <tr>
                <th scope="col" className={th}>Position</th>
                <th scope="col" className={th}>Indication (kg)</th>
                <th scope="col" className={th}>Error (kg)</th>
                <th scope="col" className={th}>Result</th>
              </tr>
            </thead>
            <tbody>
              {positions.map((p) => {
                const c = checkFor(p);
                return (
                  <tr key={p} className={c?.pass === false ? 'bg-errormocha/10' : ''}>
                    <td className={`${td} font-semibold text-espresso`}>{p}</td>
                    <td className={td}>
                      <Num value={data[p]?.indication} onChange={(v) => set({ [p]: { ...(data[p] || {}), indication: v } })} />
                    </td>
                    <td className={td}>
                      <Num value={data[p]?.error} onChange={(v) => set({ [p]: { ...(data[p] || {}), error: v } })} />
                    </td>
                    <td className={td}><PassBadge verdict={verdictOf(c)} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      );
    }

    /* ---------------- 4. Discrimination ---------------- */
    case 'discrimination':
      return (
        <div className="space-y-4">
          <Suggestion>
            At each load, add extra load of 1.4d (where MPE = 1e or less) or 2d — suggested: {(loadPoints?.discrimination || []).map((p) => `${p.load} kg +${p.extraLoad} kg`).join('; ')}. The indication must change.
          </Suggestion>
          {(data.points || [{ load: null, extraLoad: null, changed: null }, { load: null, extraLoad: null, changed: null }]).map((row, i) => {
            const c = checkFor(i);
            return (
              <div key={i} className={`rounded-xl border p-4 ${c?.pass === false ? 'border-errormocha/40 bg-errormocha/10' : 'border-softgold/60'}`}>
                <div className="grid gap-3 sm:grid-cols-4">
                  <div>
                    <label className="field-label-sm" htmlFor={`dis-${i}-load`}>Load (kg)</label>
                    <Num id={`dis-${i}-load`} value={row.load} onChange={(v) => { const pts = [...(data.points || [])]; pts[i] = { ...pts[i], load: v }; set({ points: pts }); }} />
                  </div>
                  <div>
                    <label className="field-label-sm" htmlFor={`dis-${i}-extra`}>Extra load (kg)</label>
                    <Num id={`dis-${i}-extra`} value={row.extraLoad} onChange={(v) => { const pts = [...(data.points || [])]; pts[i] = { ...pts[i], extraLoad: v }; set({ points: pts }); }} />
                  </div>
                  <label className="flex items-end gap-2 pb-2 text-sm font-semibold text-espresso">
                    <input type="checkbox" className="h-4 w-4 accent-mocha" checked={!!row.changed}
                      onChange={(e) => { const pts = [...(data.points || [])]; pts[i] = { ...pts[i], changed: e.target.checked }; set({ points: pts }); }} />
                    Indication changed
                  </label>
                  <div className="flex items-end justify-end pb-1"><PassBadge verdict={verdictOf(c)} /></div>
                </div>
              </div>
            );
          })}
        </div>
      );

    /* ---------------- 5. Weighing / Accuracy ---------------- */
    case 'weighing':
      return (
        <div className="space-y-4">
          <Suggestion>
            Suggested increasing sequence: {(loadPoints?.weighing?.increasing || []).map((p) => `${p.load}kg (MPE ${p.mpeE}e)`).join(' → ')}. Errors at or above 5e must be rounded to the nearest 0.5e. Enter the error for each load — the badge compares it to MPE live.
          </Suggestion>
          {['increasing', 'decreasing'].map((dir) => (
            <Fragment key={dir}>
              <p className="card-title capitalize">{dir} loads</p>
              <table className="w-full text-sm">
                <thead>
                  <tr>
                    <th scope="col" className={th}>Load (kg)</th>
                    <th scope="col" className={th}>MPE</th>
                    <th scope="col" className={th}>Indication (kg)</th>
                    <th scope="col" className={th}>Error (kg)</th>
                    <th scope="col" className={th}>Result</th>
                  </tr>
                </thead>
                <tbody>
                  {(loadPoints?.weighing?.[dir] || []).map((pt, i) => {
                    const row = (data[dir] || [])[i] || {};
                    const c = checkFor(`${dir}-${i}`);
                    const upd = (patch) => {
                      const arr = [...(data[dir] || [])];
                      arr[i] = { ...row, ...patch };
                      set({ [dir]: arr });
                    };
                    return (
                      <tr key={i} className={c?.pass === false ? 'bg-errormocha/10' : ''}>
                        <td className={`${td} font-semibold text-espresso`}>{pt.load}</td>
                        <td className={`${td} text-forestsage`}>{pt.mpeE}e = ±{(pt.mpeE * (loadPoints?.meta?.eKg ?? 0)).toFixed(4)} kg</td>
                        <td className={td}><Num value={row.indication} onChange={(v) => upd({ indication: v })} /></td>
                        <td className={td}><Num value={row.error} onChange={(v) => upd({ error: v })} /></td>
                        <td className={td}><PassBadge verdict={verdictOf(c)} /></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </Fragment>
          ))}
        </div>
      );

    /* ---------------- 6. Zero-setting & zero-tracking ---------------- */
    case 'zero': {
      const labels = ['Initial zero', 'After 0.5e correction', 'After 1e correction', 'Zero-tracking active 15 min'];
      return (
        <div className="space-y-4">
          <Suggestion>Zero-tracking correctness: apply corrections of 0.5e and 1e and confirm the indicator returns to zero after each correction.</Suggestion>
          <table className="w-full text-sm">
            <thead>
              <tr>
                <th scope="col" className={th}>Check</th>
                <th scope="col" className={th}>Result (kg after)</th>
                <th scope="col" className={th}>OK</th>
                <th scope="col" className={th}>Result</th>
              </tr>
            </thead>
            <tbody>
              {labels.map((label, i) => {
                const row = data.rows?.[i] || {};
                const c = checkFor(i);
                const upd = (patch) => {
                  const rows = { ...(data.rows || {}) };
                  rows[i] = { ...row, ...patch };
                  set({ rows });
                };
                return (
                  <tr key={i} className={c?.pass === false ? 'bg-errormocha/10' : ''}>
                    <td className={`${td} font-semibold text-espresso`}>{label}</td>
                    <td className={td}><Num value={row.value} onChange={(v) => upd({ value: v })} /></td>
                    <td className={td}>
                      {/* Named per row for screen readers; padded label keeps the
                          hit area at 28px without changing the row height. */}
                      <label className="-m-1.5 inline-flex cursor-pointer items-center justify-center p-1.5">
                        <input type="checkbox" aria-label={`${label} — OK`} className="h-4 w-4 accent-mocha" checked={!!row.ok} onChange={(e) => upd({ ok: e.target.checked })} />
                      </label>
                    </td>
                    <td className={td}><PassBadge verdict={verdictOf(c)} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      );
    }

    /* ---------------- 7. Tare ---------------- */
    case 'tare':
      return (
        <div className="space-y-4">
          <Suggestion>Suggested tare load: {loadPoints?.tare?.suggestedTareLoad ?? '—'} kg. Then verify net loads: {(loadPoints?.tare?.netLoads || []).join(', ')} kg.</Suggestion>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="field-label" htmlFor="mf-tare-load">Tare load applied (kg)</label>
              <Num id="mf-tare-load" value={data.tareLoad} onChange={(v) => set({ tareLoad: v })} />
            </div>
            <div>
              <label className="field-label" htmlFor="mf-tare-ind">Tare setting indication (kg)</label>
              <Num id="mf-tare-ind" value={data.tareIndication} onChange={(v) => set({ tareIndication: v })} />
            </div>
          </div>
          <table className="w-full text-sm">
            <thead>
              <tr>
                <th scope="col" className={th}>Net load (kg)</th>
                <th scope="col" className={th}>Indication (kg)</th>
                <th scope="col" className={th}>Error (kg)</th>
                <th scope="col" className={th}>Result</th>
              </tr>
            </thead>
            <tbody>
              {(loadPoints?.tare?.netLoads || [null, null, null]).map((nl, i) => {
                const row = (data.netRows || [])[i] || {};
                const c = checkFor(i);
                const upd = (patch) => {
                  const arr = [...(data.netRows || [])];
                  arr[i] = { ...row, ...patch };
                  set({ netRows: arr });
                };
                return (
                  <tr key={i} className={c?.pass === false ? 'bg-errormocha/10' : ''}>
                    <td className={`${td} font-semibold text-espresso`}>{nl ?? '—'}</td>
                    <td className={td}><Num value={row.indication} onChange={(v) => upd({ indication: v })} /></td>
                    <td className={td}><Num value={row.error} onChange={(v) => upd({ error: v })} /></td>
                    <td className={td}><PassBadge verdict={verdictOf(c)} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      );

    /* ---------------- 8. Price computation ---------------- */
    case 'price':
      return (
        <div className="space-y-4">
          <Suggestion>For retail scales only — verify indicated price = unit price × indicated weight for the suggested loads (tolerance 1e).</Suggestion>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="field-label" htmlFor="mf-unit-price">Unit price used (per kg)</label>
              <Num id="mf-unit-price" value={data.unitPrice} onChange={(v) => set({ unitPrice: v })} />
            </div>
            <div>
              <label className="field-label" htmlFor="mf-applicable">Applicable?</label>
              <select id="mf-applicable" className="input" value={data.applicable ?? 'yes'} onChange={(e) => set({ applicable: e.target.value })}>
                <option value="yes">Yes — price indicating scale</option>
                <option value="no">No — not price indicating</option>
              </select>
            </div>
          </div>
          {data.applicable !== 'no' && (
            <table className="w-full text-sm">
              <thead>
                <tr>
                  <th scope="col" className={th}>Load (kg)</th>
                  <th scope="col" className={th}>Displayed price</th>
                  <th scope="col" className={th}>Expected price</th>
                  <th scope="col" className={th}>Result</th>
                </tr>
              </thead>
              <tbody>
                {(loadPoints?.price?.loads || [null, null, null]).map((l, i) => {
                  const row = (data.rows || [])[i] || {};
                  const c = checkFor(i);
                  const upd = (patch) => {
                    const arr = [...(data.rows || [])];
                    arr[i] = { ...row, ...patch };
                    set({ rows: arr });
                  };
                  return (
                    <tr key={i} className={c?.pass === false ? 'bg-errormocha/10' : ''}>
                      <td className={`${td} font-semibold text-espresso`}>{l ?? '—'}</td>
                      <td className={td}><Num value={row.displayed} onChange={(v) => upd({ displayed: v })} /></td>
                      <td className={td}><Num value={row.expected} onChange={(v) => upd({ expected: v })} /></td>
                      <td className={td}><PassBadge verdict={verdictOf(c)} /></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      );

    /* ---------------- 9. Influence factors ---------------- */
    case 'influence':
      return (
        <div className="space-y-4">
          <Suggestion>Temperature points at {(loadPoints?.influence?.temperaturesC || []).join('°C, ')}°C and warm-up drift at {(loadPoints?.influence?.warmUpMinutes || []).join(' and ')} minutes.</Suggestion>
          {(loadPoints?.influence?.temperaturesC || [10, 20, 30]).map((t, i) => {
            const row = (data.temps || [])[i] || {};
            const c = checkFor(i);
            const upd = (patch) => {
              const arr = [...(data.temps || [])];
              arr[i] = { ...row, ...patch };
              set({ temps: arr });
            };
            return (
              <div key={i} className={`rounded-xl border p-4 ${c?.pass === false ? 'border-errormocha/40 bg-errormocha/10' : 'border-softgold/60'}`}>
                <div className="mb-2.5 flex items-center justify-between">
                  <p className="card-title">{t}°C test point</p>
                  <PassBadge verdict={verdictOf(c)} />
                </div>
                <div className="grid gap-3 sm:grid-cols-3">
                  <div>
                    <label className="field-label-sm" htmlFor={`inf-${i}-actual`}>Actual temp (°C)</label>
                    <Num id={`inf-${i}-actual`} value={row.actual} onChange={(v) => upd({ actual: v })} />
                  </div>
                  <div>
                    <label className="field-label-sm" htmlFor={`inf-${i}-indication`}>Indication @ {loadPoints?.meta?.maxCapacityKg ?? '—'} kg</label>
                    <Num id={`inf-${i}-indication`} value={row.indication} onChange={(v) => upd({ indication: v })} />
                  </div>
                  <div>
                    <label className="field-label-sm" htmlFor={`inf-${i}-error`}>Error (kg)</label>
                    <Num id={`inf-${i}-error`} value={row.error} onChange={(v) => upd({ error: v })} />
                  </div>
                </div>
              </div>
            );
          })}
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="field-label" htmlFor="mf-warm30">Warm-up: indication @ 30 min (kg)</label>
              <Num id="mf-warm30" value={data.warmUp30} onChange={(v) => set({ warmUp30: v })} />
            </div>
            <div>
              <label className="field-label" htmlFor="mf-warm60">Warm-up: indication @ 60 min (kg)</label>
              <Num id="mf-warm60" value={data.warmUp60} onChange={(v) => set({ warmUp60: v })} />
            </div>
          </div>
        </div>
      );

    default:
      return <p className="text-sm text-forestsage/70">Unknown module: {moduleKey}</p>;
  }
}
