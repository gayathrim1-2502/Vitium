import { CheckCircle2, XCircle, CircleDashed } from 'lucide-react';

// verdict: 'pass' | 'fail' | null (pending / not enough data)
export default function PassBadge({ verdict, size = 'sm' }) {
  const pad = size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-3 py-1 text-xs';
  if (verdict === 'pass') {
    return (
      <span className={`inline-flex items-center gap-1 rounded-full bg-sage/50 font-bold text-darkgreen ${pad}`}>
        <CheckCircle2 className="h-3 w-3" /> PASS
      </span>
    );
  }
  if (verdict === 'fail') {
    return (
      <span className={`inline-flex items-center gap-1 rounded-full bg-errormocha/20 font-bold text-errormocha ${pad}`}>
        <XCircle className="h-3 w-3" /> FAIL
      </span>
    );
  }
  return (
    <span className={`inline-flex items-center gap-1 rounded-full bg-softgold/30 font-bold text-forestsage ${pad}`}>
      <CircleDashed className="h-3 w-3" /> PENDING
    </span>
  );
}
