// Client-side mirror of server/src/evaluate.js — computes live pass/fail
// checks from the instrument's class/e and the module form data as the
// tester types. Server re-evaluates authoritatively on save/report.

const has = (v) => v !== null && v !== undefined && v !== '';
const num = (v) => (has(v) ? Number(v) : null);

// MPE in units of e (mirror of R 76-1 default bands; the DB is authoritative
// on the server — this covers live UI feedback with the standard defaults).
export function mpeInE(cls, loadKg, eKg) {
  const n = eKg > 0 ? loadKg / eKg : 0;
  const bands = {
    I: [[0, 50000, 0.5], [50000, Infinity, 1]],
    II: [[0, 5000, 0.5], [5000, 20000, 1], [20000, Infinity, 1.5]],
    III: [[0, 500, 0.5], [500, 2000, 1], [2000, Infinity, 1.5]],
    IIII: [[0, 50, 0.5], [50, 200, 1], [200, Infinity, 1.5]],
  };
  for (const [from, to, m] of bands[cls] || bands.III) {
    if (n >= from && n < to) return m;
  }
  return 1.5;
}

function evalVisual(data) {
  const keys = ['nameplateLegible', 'classMarking', 'levelIndicator', 'stampArea', 'dashProof', 'noDirtDamage'];
  const touched = keys.some((k) => k in data);
  const checks = keys.map((k) => ({
    key: k,
    pass: k in data ? !!data[k] : null,
    label: k.replace(/([A-Z])/g, ' $1').replace(/^./, (s) => s.toUpperCase()),
  }));
  return { checks, verdict: !touched ? null : checks.every((c) => c.pass) ? 'pass' : 'fail' };
}

function evalEccentricity(cls, eKg, data) {
  const positions = ['Center', 'Front-Left', 'Front-Right', 'Back-Left', 'Back-Right'];
  const checks = positions.map((p) => {
    const err = num(data[p]?.error);
    const pass = !has(err) ? null : Math.abs(err) <= 0.5 * eKg + 1e-9;
    return { key: p, pass, err };
  });
  const any = checks.some((c) => c.pass !== null);
  return { checks, verdict: !any ? null : checks.every((c) => c.pass !== false) ? 'pass' : 'fail' };
}

function evalRepeatability(cls, eKg, data) {
  const checks = (data.readings || []).map((row, i) => {
    const vals = [num(row.r1), num(row.r2), num(row.r3)].filter(has);
    if (vals.length < 2) return { key: i, pass: null };
    const spread = Math.max(...vals) - Math.min(...vals);
    const limitE = mpeInE(cls, Number(row.load) || 0, eKg);
    return { key: i, pass: spread <= limitE * eKg + 1e-9, spread };
  });
  const any = checks.some((c) => c.pass !== null);
  return { checks, verdict: !any ? null : checks.every((c) => c.pass !== false) ? 'pass' : 'fail' };
}

function evalDiscrimination(data) {
  const checks = (data.points || []).map((row, i) => ({
    key: i,
    pass: has(row.changed) ? !!row.changed : null,
  }));
  const any = checks.some((c) => c.pass !== null);
  return { checks, verdict: !any ? null : checks.every((c) => c.pass !== false) ? 'pass' : 'fail' };
}

function evalWeighing(cls, eKg, data) {
  const mk = (dir) => (data[dir] || []).map((row, i) => {
    const err = num(row.error);
    const load = num(row.load);
    const limitE = mpeInE(cls, has(load) ? load : 0, eKg);
    return { key: `${dir}-${i}`, pass: !has(err) ? null : Math.abs(err) <= limitE * eKg + 1e-9, err, limitE, load: row.load };
  });
  const checks = [...mk('increasing'), ...mk('decreasing')];
  const any = checks.some((c) => c.pass !== null);
  return { checks, verdict: !any ? null : checks.every((c) => c.pass !== false) ? 'pass' : 'fail' };
}

function evalZero(data) {
  const labels = ['Initial zero', 'After 0.5e correction', 'After 1e correction', 'Zero-tracking 15 min'];
  const checks = Object.entries(data.rows || {}).map(([i, row]) => ({
    key: i,
    pass: has(row.ok) ? !!row.ok : null,
    label: labels[i] || `Check ${i}`,
  }));
  const any = checks.some((c) => c.pass !== null);
  return { checks, verdict: !any ? null : checks.every((c) => c.pass !== false) ? 'pass' : 'fail' };
}

function evalTare(cls, eKg, data) {
  const checks = (data.netRows || []).map((row, i) => {
    const err = num(row.error);
    const indication = num(row.indication);
    const limitE = mpeInE(cls, has(indication) ? indication : 0, eKg);
    return { key: i, pass: !has(err) ? null : Math.abs(err) <= limitE * eKg + 1e-9, err };
  });
  const any = checks.some((c) => c.pass !== null);
  return { checks, verdict: !any ? null : checks.every((c) => c.pass !== false) ? 'pass' : 'fail' };
}

function evalPrice(cls, eKg, data) {
  if (data.applicable === 'no') return { checks: [], verdict: 'pass' };
  const checks = (data.rows || []).map((row, i) => {
    const disp = num(row.displayed);
    const exp = num(row.expected);
    const pass = !has(disp) || !has(exp) ? null : Math.abs(disp - exp) <= eKg + 1e-9;
    return { key: i, pass };
  });
  const any = checks.some((c) => c.pass !== null);
  return { checks, verdict: !any ? null : checks.every((c) => c.pass !== false) ? 'pass' : 'fail' };
}

function evalInfluence(cls, eKg, data) {
  const checks = (data.temps || []).map((row, i) => {
    const err = num(row.error);
    const indication = num(row.indication);
    const limitE = mpeInE(cls, has(indication) ? indication : 0, eKg);
    return { key: i, pass: !has(err) ? null : Math.abs(err) <= limitE * eKg + 1e-9, err };
  });
  const w30 = num(data.warmUp30);
  const w60 = num(data.warmUp60);
  if (has(w30) && has(w60)) {
    const limitE = mpeInE(cls, Math.max(w30, w60), eKg);
    checks.push({ key: 'warmup', pass: Math.abs(w60 - w30) <= limitE * eKg + 1e-9 });
  }
  const any = checks.some((c) => c.pass !== null);
  return { checks, verdict: !any ? null : checks.every((c) => c.pass !== false) ? 'pass' : 'fail' };
}

// Evaluate one module live. instrument: { accuracy_class, e_kg }
export function evaluateModule(moduleKey, data, instrument) {
  const cls = instrument?.accuracy_class || 'III';
  const eKg = Number(instrument?.e_kg) > 0 ? Number(instrument.e_kg) : 0.001;
  const d = data || {};
  switch (moduleKey) {
    case 'visual': return evalVisual(d);
    case 'eccentricity': return evalEccentricity(cls, eKg, d);
    case 'repeatability': return evalRepeatability(cls, eKg, d);
    case 'discrimination': return evalDiscrimination(d);
    case 'weighing': return evalWeighing(cls, eKg, d);
    case 'zero': return evalZero(d);
    case 'tare': return evalTare(cls, eKg, d);
    case 'price': return evalPrice(cls, eKg, d);
    case 'influence': return evalInfluence(cls, eKg, d);
    default: return { checks: [], verdict: null };
  }
}
