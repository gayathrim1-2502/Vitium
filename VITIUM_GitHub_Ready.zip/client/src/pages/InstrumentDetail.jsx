import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import QRCode from 'qrcode';
import code39Svg from '../lib/code128.jsx';
import {
  ArrowLeft, CheckCircle2, XCircle, Clock, Activity, FileBarChart2, TrendingUp, PlayCircle, Info,
  QrCode, Printer, Download, Upload, FileText, MapPin, Trash2, ImageIcon,
} from 'lucide-react';
import { api, getToken } from '../api.js';
import { useAuth } from '../auth/AuthContext.jsx';
import { LineChart } from '../components/charts.jsx';
import EmptyState from '../components/EmptyState.jsx';

const STATUS_BADGE = {
  draft: { label: 'Draft', cls: 'badge-slate', icon: Clock },
  in_progress: { label: 'In Progress', cls: 'badge-amber', icon: Activity },
  submitted: { label: 'Submitted', cls: 'badge-amber', icon: Clock },
  approved: { label: 'Approved', cls: 'badge-green', icon: CheckCircle2 },
  rejected: { label: 'Rejected', cls: 'badge-red', icon: XCircle },
};

const FILE_ICON = { photo: ImageIcon, document: FileText };

export default function InstrumentDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const [payload, setPayload] = useState(null);
  const [error, setError] = useState('');
  const [qrData, setQrData] = useState('');
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');

  useEffect(() => { document.title = 'Instrument Profile · VITIUM'; }, []);

  const load = () => api(`/instruments/${id}/profile`).then((d) => {
    setPayload(d);
    QRCode.toDataURL(`VITIUM-INS:${d.instrument.instrument_code || `VTM-INS-${String(d.instrument.id).padStart(6, '0')}`}`, {
      width: 220, margin: 1, color: { dark: '#3B2720', light: '#F5E6D3' },
    }).then(setQrData).catch(() => setQrData(''));
  }).catch((e) => setError(e.message));

  useEffect(() => { load(); }, [id]);

  async function handleUpload(e) {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    setUploading(true);
    setUploadError('');
    for (const f of files) {
      try {
        await api.raw(`/instruments/${id}/files`, f, { docType: 'other' });
      } catch (err) {
        setUploadError(`${f.name}: ${err.message}`);
      }
    }
    setUploading(false);
    e.target.value = '';
    load();
  }

  async function handleDeleteFile(fileId) {
    if (!window.confirm('Delete this file permanently?')) return;
    try {
      await api(`/files/${fileId}`, { method: 'DELETE' });
      load();
    } catch (err) {
      setUploadError(err.message);
    }
  }

  function printQR() {
    if (!qrData) return;
    const w = window.open('', '_blank', 'width=420,height=560');
    if (!w) return;
    w.document.write(`<html><head><title>${payload.instrument.instrument_code || payload.instrument.name} — QR</title></head>
      <body style="font-family:system-ui;display:flex;flex-direction:column;align-items:center;gap:10px;padding:28px;background:#F5E6D3">
        <img src="${qrData}" width="260" height="260" />
        <strong style="font-size:15px;color:#3B2720">${payload.instrument.instrument_code || payload.instrument.name}</strong>
        <span style="font-size:12px;color:#65745D">S/N ${payload.instrument.serial_number} · ${payload.instrument.manufacturer}</span>
      </body></html>`);
    w.document.close();
    w.focus();
    setTimeout(() => w.print(), 300);
  }

  function downloadQR() {
    if (!qrData) return;
    const a = document.createElement('a');
    a.href = qrData;
    a.download = `${payload.instrument.instrument_code || `instrument-${id}`}-qr.png`;
    a.click();
  }

  if (error) return <div className="card border-errormocha/30 bg-errormocha/10 p-6 text-sm font-semibold text-errormocha">{error}</div>;
  if (!payload) return <div className="card h-72 animate-pulse bg-sagecream" />;

  const { instrument, stats, sessions, certificates, files } = payload;
  const history = sessions;
  const chartData = [...history]
    .filter((h) => h.maxAbsError != null)
    .reverse()
    .map((h) => ({ label: h.id, value: h.maxAbsError, verdict: h.verdict }));
  const lastCert = certificates[0];
  const canUpload = ['admin', 'engineer'].includes(user.role);

  return (
    <div className="fade-up space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Link to="/instruments" className="btn-secondary"><ArrowLeft className="h-4 w-4" /> All instruments</Link>
        <div className="flex flex-wrap gap-2">
          {['draft', 'in_progress'].includes(history[0]?.status) && (
            <Link to={`/sessions/${history[0].id}`} className="btn-primary"><PlayCircle className="h-4 w-4" /> Resume open session</Link>
          )}
          {canUpload && (
            <label className="btn-secondary cursor-pointer">
              <Upload className="h-4 w-4" /> {uploading ? 'Uploading…' : 'Upload Document / Photo'}
              <input type="file" multiple accept="image/*,application/pdf,.csv,.txt,.doc,.docx,.xls,.xlsx" className="hidden" onChange={handleUpload} />
            </label>
          )}
        </div>
      </div>
      {uploadError && (
        <div className="alert-error" role="alert">{uploadError}</div>
      )}

      {/* Instrument header with QR + barcode */}
      <div className="card card-flush relative overflow-hidden">
        <div className="px-6 py-5" style={{ backgroundImage: 'linear-gradient(120deg, #C88A5A 0%, #8B5E3C 50%, #6E4A2F 100%)' }}>
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="min-w-0">
              <p className="font-mono text-[11px] font-bold tracking-widest text-softgold">{instrument.instrument_code || `VTM-INS-${String(instrument.id).padStart(6, '0')}`}</p>
              <h1 className="mt-0.5 text-2xl font-extrabold tracking-tight text-cream">{instrument.name}</h1>
              <p className="mt-0.5 text-xs font-semibold text-cream/85">
                {instrument.instrument_type || 'Instrument'} · {instrument.manufacturer} {instrument.model} · S/N {instrument.serial_number} · Class {instrument.accuracy_class}
              </p>
              <p className="mt-1 flex items-center gap-1.5 text-[11px] text-cream/75"><MapPin className="h-3 w-3" /> {instrument.location}{instrument.owner_name ? ` · Owner: ${instrument.owner_name}` : ''}</p>
            </div>
            <div className="flex flex-col items-center gap-2 rounded-xl bg-cream/95 p-3 shadow-lg">
              {qrData ? <img src={qrData} alt="Instrument QR" className="h-28 w-28" /> : <div className="flex h-28 w-28 items-center justify-center"><QrCode className="h-16 w-16 text-mocha" /></div>}
              <div className="w-full max-w-[220px]" dangerouslySetInnerHTML={{ __html: code39Svg(instrument.instrument_code || `VTM-${String(instrument.id).padStart(6, '0')}`, { height: 34, dark: '#3B2720', light: '#F5E6D3' }) }} />
              <div className="flex gap-1.5">
                <button onClick={printQR} className="rounded-lg border border-softgold bg-cream px-2 py-1 text-[10px] font-bold text-mocha hover:bg-mutedgold/40" title="Print QR"><Printer className="mr-1 inline h-3 w-3" />Print</button>
                <button onClick={downloadQR} className="rounded-lg border border-softgold bg-cream px-2 py-1 text-[10px] font-bold text-mocha hover:bg-mutedgold/40" title="Download QR"><Download className="mr-1 inline h-3 w-3" />PNG</button>
              </div>
            </div>
          </div>
          <div className="mt-4 flex flex-wrap gap-2 text-[11px] font-bold">
            <span className="rounded-full bg-cream/15 px-3 py-1.5 text-cream">{stats.tests} test{stats.tests !== 1 ? 's' : ''}</span>
            <span className="rounded-full bg-cream/15 px-3 py-1.5 text-cream">{stats.failures} failure{stats.failures !== 1 ? 's' : ''}</span>
            <span className="rounded-full bg-cream/15 px-3 py-1.5 text-cream">{stats.certificates} certificate{stats.certificates !== 1 ? 's' : ''}</span>
            {payload.certificate?.expiry && (
              <span className={`rounded-full px-3 py-1.5 ${payload.certificate.status === 'expired' ? 'bg-errormocha/40' : payload.certificate.status === 'expiring' ? 'bg-mutedgold/40' : 'bg-sage/40'} text-cream`}>
                {payload.certificate.number || 'Cert'} · {payload.certificate.status === 'expired' ? 'EXPIRED' : payload.certificate.status === 'expiring' ? 'EXPIRING SOON' : 'VALID'} until {String(payload.certificate.expiry).slice(0, 10)}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Drift chart */}
      {chartData.length >= 2 && (
        <div className="card p-6">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <h2 className="flex items-center gap-2 card-title">
              <TrendingUp className="h-4.5 w-4.5 text-caramel" /> Error Trend Across Sessions (drift detection)
            </h2>
            <p className="text-[11px] font-semibold text-forestsage">max |error| from the weighing test per session</p>
          </div>
          <LineChart data={chartData} yLabel="kg" />
        </div>
      )}

      {/* Test history timeline */}
      <div className="card p-6">
        <h2 className="mb-5 card-title">Test History Timeline</h2>
        {history.length === 0 ? (
          <EmptyState
            tone="teal"
            title="No test sessions yet"
            subtitle="Start the first test session for this instrument to build its history."
            ctaLabel="Start a test session"
            ctaTo={`/sessions/new?instrumentId=${instrument.id}`}
          />
        ) : (
          <ol className="relative ml-3 space-y-6 border-l-2 border-softgold/60 pl-6">
            {history.map((h) => {
              const st = STATUS_BADGE[h.status] || STATUS_BADGE.draft;
              const ok = h.verdict === 'pass';
              // Date/engineer fields differ between the profile and history
              // payloads — build the line from whichever are present.
              const meta = [
                (h.date || h.approved_at || h.submitted_at || h.started_at)?.slice(0, 16).replace('T', ' '),
                h.engineer || h.engineer_name,
                (h.approver || h.approver_name) ? `approved by ${h.approver || h.approver_name}` : null,
              ].filter(Boolean).join(' · ');
              return (
                <li key={h.id} className="relative">
                  <span
                    className={`absolute -left-[31.5px] flex h-6 w-6 items-center justify-center rounded-full border-2 border-sagecream text-cream shadow-md ${ok ? 'bg-sage' : h.verdict === 'fail' ? 'bg-errormocha' : 'bg-mutedgold'}`}
                  >
                    {ok ? <CheckCircle2 className="h-3.5 w-3.5" /> : h.verdict === 'fail' ? <XCircle className="h-3.5 w-3.5" /> : <Clock className="h-3.5 w-3.5" />}
                  </span>
                  <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-softgold/50 bg-sagecream p-4 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md">
                    <div>
                      <p className="text-sm font-extrabold text-darkgreen">
                        Session #{String(h.id).padStart(4, '0')}
                        <span className={`badge ${st.cls} ml-2`}>{st.icon && <st.icon className="h-3 w-3" />}{st.label}</span>
                      </p>
                      {meta && <p className="mt-0.5 text-xs text-forestsage">{meta}</p>}
                    </div>
                    <div className="flex gap-2">
                      {h.reportUid && ['approved'].includes(h.status) && (
                        <a
                          href={`/verify/${h.reportUid}`}
                          target="_blank"
                          rel="noreferrer"
                          className="btn-secondary btn-sm"
                          title="Open public verification page"
                        >
                          Verify ↗
                        </a>
                      )}
                      <Link to={['draft', 'in_progress'].includes(h.status) ? `/sessions/${h.id}` : `/sessions/${h.id}/report`} className="btn-secondary btn-sm">
                        {['draft', 'in_progress'].includes(h.status) ? 'Resume' : <><FileBarChart2 className="h-3.5 w-3.5" /> Report</>}
                      </Link>
                    </div>
                  </div>
                </li>
              );
            })}
          </ol>
        )}
      </div>

      {/* Certificates */}
      <div className="card p-6">
        <h2 className="mb-4 flex items-center gap-2 card-title"><FileText className="h-4.5 w-4.5 text-caramel" /> Certificate History</h2>
        {certificates.length === 0 ? (
          <p className="text-sm text-forestsage">No certificates issued yet — they are generated automatically when a session is approved.</p>
        ) : (
          <div className="space-y-2.5">
            {certificates.map((c) => (
              <div key={c.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-softgold/50 bg-sagecream p-3.5">
                <div>
                  <p className="font-mono text-xs font-extrabold text-darkgreen">{c.cert_number}</p>
                  <p className="text-[11px] text-forestsage">Issued {String(c.issued_at).slice(0, 10)} · valid until {String(c.valid_until).slice(0, 10)} · by {c.verifier_name || '—'}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`badge ${c.status === 'expired' ? 'badge-red' : c.status === 'expiring' ? 'badge-amber' : 'badge-green'}`}>{c.status === 'expired' ? 'Expired' : c.status === 'expiring' ? 'Expiring Soon' : 'Valid'}</span>
                  <Link to={`/sessions/${c.session_id}/report`} className="btn-secondary btn-sm">Open</Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Files: photos & documents */}
      <div className="card p-6">
        <h2 className="mb-4 flex items-center gap-2 card-title"><ImageIcon className="h-4.5 w-4.5 text-caramel" /> Photos & Documents</h2>
        {files.length === 0 ? (
          <p className="text-sm text-forestsage">
            No files yet. {canUpload ? 'Use “Upload Document / Photo” above — nameplate photos, seal photos, calibration documents and previous certificates all belong here.' : ''}
          </p>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {files.map((f) => {
              const Icon = FILE_ICON[f.kind] || FileText;
              return (
                <div key={f.id} className="flex items-center gap-3 rounded-xl border border-softgold/50 bg-sagecream p-3">
                  {f.kind === 'photo' ? (
                    <img src={`/api/files/${f.id}`} alt={f.file_name} className="h-14 w-14 shrink-0 rounded-lg object-cover" loading="lazy" />
                  ) : (
                    <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-lg bg-mutedgold/40"><Icon className="h-6 w-6 text-mocha" /></span>
                  )}
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-xs font-bold text-espresso" title={f.file_name}>{f.file_name}</p>
                    <p className="text-[10px] text-forestsage">{f.doc_type.replace(/_/g, ' ')} · {(f.size_bytes / 1024).toFixed(0)} KB · {String(f.created_at).slice(0, 10)}</p>
                    <div className="mt-1 flex gap-2 text-[10px] font-bold">
                      <a href={`/api/files/${f.id}`} target="_blank" rel="noreferrer" className="text-caramel hover:underline">Open</a>
                      <a href={`/api/files/${f.id}`} download={f.file_name} className="text-caramel hover:underline">Download</a>
                      {canUpload && (
                        <button onClick={() => handleDeleteFile(f.id)} className="link-danger">Delete</button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
