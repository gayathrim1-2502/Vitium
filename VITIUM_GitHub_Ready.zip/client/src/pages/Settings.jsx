import { useEffect, useState } from 'react';
import { Building2, FileBadge, Target, Save, CheckCircle2 } from 'lucide-react';
import { api } from '../api.js';

export default function Settings() {
  const [settings, setSettings] = useState(null);
  const [form, setForm] = useState(null);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    api('/settings')
      .then((d) => {
        setSettings(d.settings);
        setForm({
          orgName: d.settings.org_name,
          certificateFooter: d.settings.certificate_footer,
          defaultPassRateTarget: d.settings.default_pass_rate_target,
        });
      })
      .catch((e) => setError(e.message));
  }, []);

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    setSaved(false);
    try {
      const d = await api('/settings', {
        method: 'PUT',
        body: {
          orgName: form.orgName,
          certificateFooter: form.certificateFooter,
          defaultPassRateTarget: Number(form.defaultPassRateTarget),
        },
      });
      setSettings(d.settings);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  if (error) return <div className="card border-errormocha/30 bg-errormocha/10 p-6 text-sm font-semibold text-errormocha">Failed to load settings: {error}</div>;
  if (!form) return <div className="card h-64 animate-pulse bg-sagecream" />;

  return (
    <div className="fade-up mx-auto max-w-2xl space-y-5">
      <form onSubmit={handleSave} className="card card-flush overflow-hidden">
        <div
          className="px-6 py-4"
          style={{ backgroundImage: 'linear-gradient(120deg, #C88A5A 0%, #8B5E3C 55%, #6E4A2F 100%)' }}
        >
          <h2 className="text-lg font-extrabold tracking-tight text-cream">Organisation Settings</h2>
          <p className="text-xs font-semibold text-softgold">Branding and defaults for generated certificates</p>
        </div>

        <div className="space-y-5 p-6">
          <div>
            <label className="field-label flex items-center gap-1.5" htmlFor="set-org">
              <Building2 className="h-3.5 w-3.5" /> Organisation Name
            </label>
            <input
              className="input"
              id="set-org"
              required
              value={form.orgName}
              onChange={(e) => setForm({ ...form, orgName: e.target.value })}
            />
          </div>

          <div>
            <label className="field-label flex items-center gap-1.5" htmlFor="set-footer">
              <FileBadge className="h-3.5 w-3.5" /> Certificate Footer Text
            </label>
            <textarea
              id="set-footer"
              className="input min-h-20 resize-y"
              value={form.certificateFooter}
              onChange={(e) => setForm({ ...form, certificateFooter: e.target.value })}
            />
            <p className="mt-1.5 text-xs text-forestsage/80">
              Appears at the bottom of every generated OIML R-76 certificate.
            </p>
          </div>

          <div>
            <label className="field-label flex items-center gap-1.5" htmlFor="set-target">
              <Target className="h-3.5 w-3.5" /> Default Pass-Rate Target (%)
            </label>
            <input
              className="input"
              id="set-target"
              type="number"
              min="0"
              max="100"
              required
              value={form.defaultPassRateTarget}
              onChange={(e) => setForm({ ...form, defaultPassRateTarget: e.target.value })}
            />
          </div>

          <div className="flex items-center justify-between border-t border-softgold/50 pt-4">
            <p className="text-xs text-forestsage/80">Last updated: {(settings?.updated_at || '—').slice(0, 16).replace('T', ' ')}</p>
            <button type="submit" disabled={saving} className="btn-primary">
              {saving ? <span className="btn-spinner" /> : saved ? <CheckCircle2 className="h-4.5 w-4.5" /> : <Save className="h-4.5 w-4.5" />}
              {saved ? 'Saved' : saving ? 'Saving…' : 'Save changes'}
            </button>
          </div>
        </div>
      </form>

      <MpeRulesCard />
    </div>
  );
}

function MpeRulesCard() {
  const [meta, setMeta] = useState(null);
  useEffect(() => {
    api('/mpe-rules').then(setMeta).catch(() => {});
  }, []);
  if (!meta) return null;
  const clsColor = { I: 'badge-violet', II: 'badge-violet', III: 'badge-blue', IIII: 'badge-blue' };
  return (
    <div className="card card-flush overflow-hidden">
      <div className="border-b border-softgold/50 px-6 py-4">
        <h3 className="card-title">MPE Engine Rules (configurable)</h3>
        <p className="text-xs text-forestsage">{meta.source}</p>
      </div>
      <div className="overflow-x-auto">
        <table className="table-base">
          <thead>
            <tr><th scope="col">Class</th><th scope="col">From (×e)</th><th scope="col">To (×e)</th><th scope="col">MPE</th></tr>
          </thead>
          <tbody>
            {meta.bands.map((b, i) => (
              <tr key={i}>
                <td><span className={`badge whitespace-nowrap ${clsColor[b.class]}`}>Class {b.class}</span></td>
                <td className="whitespace-nowrap text-forestsage">≥ {b.fromE.toLocaleString()}</td>
                <td className="whitespace-nowrap text-forestsage">{b.toE === null ? '— (uncapped)' : `< ${b.toE.toLocaleString()}`}</td>
                <td><span className="badge whitespace-nowrap badge-teal">±{b.mpeE} e</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="border-t border-softgold/50 px-6 py-4">
        <p className="text-xs font-bold uppercase tracking-wide text-forestsage/80">Test parameters</p>
        <div className="mt-2 flex flex-wrap gap-1.5">
          {Object.entries(meta.params).map(([k, v]) => (
            <span key={k} className="rounded-lg bg-softgold/25 px-2.5 py-1 text-[11px] font-semibold text-forestsage">
              {k} = {String(v)}
            </span>
          ))}
        </div>
        <p className="mt-2.5 text-[11px] text-forestsage/80">
          Stored in the <code className="font-mono">mpe_rules</code> / <code className="font-mono">mpe_params</code> database tables — update them to retune the engine without code changes.
        </p>
      </div>
    </div>
  );
}
