import { useEffect, useState } from 'react';
import { UserPlus, ShieldCheck, FileCheck2, UserCog, Power, X, Mail } from 'lucide-react';
import { api } from '../api.js';
import { useAuth } from '../auth/AuthContext.jsx';
import useDialogFocus from '../lib/useDialogFocus.js';

const ROLE_META = {
  engineer: { label: 'Test Engineer', cls: 'badge-teal', icon: FileCheck2 },
  approver: { label: 'Approver', cls: 'badge-amber', icon: ShieldCheck },
  admin: { label: 'Admin', cls: 'badge-blue', icon: UserCog },
};

// Display-only descriptions for roles that exist in the data but cannot be
// created from this page — kept out of ROLE_META so the role picker is unchanged.
const ROLE_DISPLAY = {
  business: { label: 'Instrument Owner', cls: 'badge-green', icon: UserCog },
};

const emptyForm = { fullName: '', email: '', password: '', role: 'engineer' };

export default function Users() {
  const { user: me } = useAuth();
  const [users, setUsers] = useState(null);
  const [error, setError] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);
  const [rowError, setRowError] = useState('');
  const panelRef = useDialogFocus(modalOpen, () => setModalOpen(false));

  const load = () => api('/users').then((d) => setUsers(d.users)).catch((e) => setError(e.message));
  useEffect(() => { load(); }, []);

  async function handleCreate(e) {
    e.preventDefault();
    setFormError('');
    setSaving(true);
    try {
      await api('/users', { method: 'POST', body: form });
      setModalOpen(false);
      setForm(emptyForm);
      load();
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function toggleActive(u) {
    setRowError('');
    try {
      await api(`/users/${u.id}`, { method: 'PATCH', body: { active: !u.active } });
      load();
    } catch (err) {
      setRowError(err.message);
    }
  }

  if (error) return <div className="card border-errormocha/30 bg-errormocha/10 p-6 text-sm font-semibold text-errormocha">Failed to load users: {error}</div>;

  return (
    <div className="fade-up space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm font-semibold text-forestsage">
          {users ? `${users.length} team members` : 'Loading team…'}
        </p>
        <button className="btn-primary" onClick={() => setModalOpen(true)}>
          <UserPlus className="h-4.5 w-4.5" /> Add User
        </button>
      </div>

      {rowError && (
        <div className="alert-error" role="alert">{rowError}</div>
      )}

      <div className="card card-flush overflow-hidden">
        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th scope="col">User</th>
                <th scope="col">Role</th>
                <th scope="col">Status</th>
                <th className="text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {(users || []).map((u) => {
                const meta = ROLE_META[u.role] || ROLE_DISPLAY[u.role] || { label: u.role, cls: 'badge-slate', icon: UserCog };
                const isSelf = u.id === me.id;
                return (
                  <tr key={u.id}>
                    <td>
                      <div className="flex items-center gap-3">
                        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-caramel to-mocha text-xs font-extrabold text-cream">
                          {(u.fullName || 'User').split(' ').map((p) => p[0]).join('').slice(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <p className="font-bold text-darkgreen">
                            {u.fullName || 'User'} {isSelf && <span className="ml-1 text-xs font-semibold text-caramel">(you)</span>}
                          </p>
                          <p className="flex items-center gap-1 text-xs text-forestsage">
                            <Mail className="h-3 w-3" /> {u.email}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span className={`badge ${meta.cls}`}>
                        <meta.icon className="h-3 w-3" /> {meta.label}
                      </span>
                    </td>
                    <td>
                      <span className={`badge ${u.active ? 'badge-green' : 'badge-slate'}`}>
                        <span className={`h-1.5 w-1.5 rounded-full ${u.active ? 'bg-forestsage' : 'bg-forestsage/40'}`} />
                        {u.active ? 'Active' : 'Disabled'}
                      </span>
                    </td>
                    <td className="text-right">
                      <button
                        onClick={() => toggleActive(u)}
                        disabled={isSelf}
                        title={isSelf ? 'You cannot disable your own account' : u.active ? 'Disable account' : 'Enable account'}
                        className={`btn btn-sm ${u.active ? 'btn-danger' : 'btn-secondary'}`}
                      >
                        <Power className="h-3.5 w-3.5" />
                        {u.active ? 'Disable' : 'Enable'}
                      </button>
                    </td>
                  </tr>
                );
              })}
              {!users && (
                <tr><td colSpan="4" className="py-10 text-center text-sm text-forestsage/70">Loading users…</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add user modal */}
      {modalOpen && (
        <div className="modal-overlay flex items-center justify-center p-4" onClick={() => setModalOpen(false)}>
          <div ref={panelRef} tabIndex={-1} role="dialog" aria-modal="true" aria-label="Add User" className="card w-full max-w-md p-6 fade-up" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h3 className="modal-title text-darkgreen">Add User</h3>
              <button onClick={() => setModalOpen(false)} className="modal-close text-forestsage/70 hover:bg-mutedgold/30 hover:text-forestsage"><X className="h-5 w-5" /></button>
            </div>
            {formError && <div className="mt-4 alert-error" role="alert">{formError}</div>}
            <form onSubmit={handleCreate} className="mt-5 space-y-4">
              <div>
                <label className="field-label" htmlFor="u-name">Full Name</label>
                <input id="u-name" className="input" required placeholder="Jane Doe" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
              </div>
              <div>
                <label className="field-label" htmlFor="u-email">Email</label>
                <input id="u-email" className="input" type="email" required placeholder="jane@company.com" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
              </div>
              <div>
                <label className="field-label" htmlFor="u-password">Temporary Password</label>
                <input id="u-password" className="input" type="text" required minLength={8} placeholder="Min 8 characters" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
              </div>
              <div>
                <label className="field-label">Role</label>
                <div className="grid grid-cols-3 gap-2" role="group" aria-label="Role">
                  {Object.entries(ROLE_META).map(([key, meta]) => (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setForm({ ...form, role: key })}
                      className={`flex flex-col items-center gap-1.5 rounded-xl border-2 px-2 py-3 text-xs font-bold transition-all ${
                        form.role === key
                          ? 'border-caramel bg-mutedgold/30 text-mocha shadow-sm'
                          : 'border-softgold text-forestsage hover:border-caramel'
                      }`}
                    >
                      <meta.icon className="h-4.5 w-4.5" />
                      {meta.label}
                    </button>
                  ))}
                </div>
              </div>
              <button type="submit" disabled={saving} className="btn-primary w-full">
                {saving ? <><span className="btn-spinner" /> Creating…</> : 'Create user'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
