import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Scale, ClipboardList, TrendingUp, FileCheck2, CheckCircle2, XCircle,
  Clock, ArrowRight, Activity, QrCode, PlayCircle, CalendarClock, FileWarning,
  Plus, AlertTriangle, FileText, BadgeCheck,
} from 'lucide-react';
import { api } from '../api.js';
import { useAuth } from '../auth/AuthContext.jsx';
import EmptyState from '../components/EmptyState.jsx';

const STATUS_BADGE = {
  draft: { label: 'Draft', cls: 'badge-slate', icon: Clock },
  in_progress: { label: 'In Progress', cls: 'badge-blue', icon: Activity },
  submitted: { label: 'Submitted', cls: 'badge-amber', icon: Clock },
  approved: { label: 'Approved', cls: 'badge-green', icon: CheckCircle2 },
  rejected: { label: 'Rejected', cls: 'badge-red', icon: XCircle },
};

function KpiCard({ icon: Icon, label, value, sub, accent, to }) {
  return (
    <Link
      to={to}
      className="card group relative overflow-hidden p-5 transition-all duration-200 hover:-translate-y-1 hover:shadow-xl active:-translate-y-0.5"
    >
      <div className="absolute inset-x-0 top-0 h-1.5" style={{ backgroundColor: accent }} />
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-bold uppercase tracking-wider text-forestsage">{label}</p>
          <p className="mt-2 text-3xl font-extrabold tracking-tight tabular-nums text-mocha">{value}</p>
          <p className="mt-1.5 text-xs font-medium text-forestsage">{sub}</p>
        </div>
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-mutedgold/40 text-mocha shadow-md shadow-caramel/20 transition-transform duration-200 group-hover:scale-110">
          <Icon className="h-6 w-6" />
        </div>
      </div>
    </Link>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    document.title = 'Dashboard · VITIUM';
  }, []);

  useEffect(() => {
    let cancelled = false;
    api('/dashboard')
      .then((d) => !cancelled && setData(d))
      .catch((e) => !cancelled && setError(e.message));
    return () => {
      cancelled = true;
    };
  }, []);

  if (error) {
    return (
      <div className="card border-errormocha/30 bg-errormocha/10 p-6 text-sm font-semibold text-errormocha">
        Failed to load dashboard: {error}
      </div>
    );
  }
  if (!data) {
    return (
      <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="card h-32 animate-pulse bg-sagecream" />
        ))}
      </div>
    );
  }

  const { kpis, recentSessions } = data;

  return (
    <div className="fade-up space-y-6">
      {/* Greeting banner */}
      <div
        className="relative overflow-hidden rounded-2xl p-6 shadow-lg lg:p-7"
        style={{ backgroundImage: 'linear-gradient(120deg, #C88A5A 0%, #8B5E3C 55%, #6E4A2F 100%)' }}
      >
        <div className="absolute -right-16 -top-20 h-64 w-64 rounded-full bg-softgold/20 blur-2xl" />
        <div className="absolute -bottom-24 right-40 h-48 w-48 rounded-full bg-sage/25 blur-2xl" />
        <div className="relative z-10 flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-xs font-bold uppercase tracking-widest text-softgold">
              {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}
            </p>
            <h2 className="mt-1 text-2xl font-extrabold tracking-tight text-cream lg:text-3xl">
              Welcome back, {(user.fullName || 'User').split(' ')[0]} 👋
            </h2>
            <p className="mt-1.5 max-w-xl text-sm text-cream/85">
              {user.role === 'approver'
                ? 'Test sessions are waiting for your review and digital signature.'
                : user.role === 'admin'
                ? 'You have full control over users, instruments and master data.'
                : 'Pick up where you left off — start or continue a test session.'}
            </p>
          </div>
          <Link
            to={user.role === 'approver' ? '/reports' : user.role === 'admin' ? '/users' : '/sessions'}
            className="btn-orange shrink-0"
          >
            {user.role === 'approver' ? 'Review reports' : user.role === 'admin' ? 'Manage users' : 'Go to sessions'}
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        <KpiCard
          icon={Scale}
          label="Instruments Tested"
          value={kpis.instrumentsTested}
          sub="Distinct instruments with test history"
          accent="#C88A5A"
          to="/instruments"
        />
        <KpiCard
          icon={ClipboardList}
          label="Pending Approvals"
          value={kpis.pendingApprovals}
          sub="Sessions awaiting review"
          accent="#D6B98C"
          to="/sessions?status=submitted"
        />
        <KpiCard
          icon={TrendingUp}
          label="Pass Rate"
          value={kpis.passRate === null ? '—' : `${kpis.passRate}%`}
          sub="Approved vs rejected sessions"
          accent="#A8B89F"
          to="/reports"
        />
        <KpiCard
          icon={FileCheck2}
          label="Reports This Month"
          value={kpis.reportsThisMonth}
          sub="Submitted in current month"
          accent="#D9B77A"
          to="/reports"
        />
        <KpiCard icon={Activity} label="Tests Today" value={kpis.testsToday} sub="Recorded today" accent="#65745D" to="/sessions" />
        <KpiCard icon={CalendarClock} label="Tests This Week" value={kpis.testsThisWeek} sub="Last 7 days" accent="#8B5E3C" to="/sessions" />
        <KpiCard
          icon={FileWarning}
          label="Expiring Soon (30d)"
          value={kpis.expiring30}
          sub={`${kpis.expiring7} within 7 days · ${kpis.expired} expired`}
          accent="#D6B98C"
          to="/instruments?certStatus=expiring"
        />
        {(user.role === 'engineer' || user.role === 'admin') && (
          <KpiCard icon={XCircle} label="My Open / Rejected" value={`${kpis.myPending} / ${kpis.myRejected}`} sub="My drafts & rejections to fix" accent="#6E4A2F" to="/sessions" />
        )}
      </div>

      {/* Quick actions */}
      {user.role !== 'business' && (
        <div className="card flex flex-wrap items-center gap-2.5 p-4">
          <span className="mr-1 text-xs font-bold uppercase tracking-wider text-forestsage">Quick actions</span>
          <Link to="/sessions" className="btn-primary btn-sm"><PlayCircle className="h-4 w-4" /> Start New Test</Link>
          <button onClick={() => window.dispatchEvent(new CustomEvent('vitium:scan'))} className="btn-secondary btn-sm"><QrCode className="h-4 w-4" /> Scan Instrument</button>
          {user.role === 'admin' && <Link to="/instruments" className="btn-secondary btn-sm"><Plus className="h-4 w-4" /> Register Instrument</Link>}
          <Link to="/sessions?status=submitted" className="btn-secondary btn-sm"><ClipboardList className="h-4 w-4" /> Pending Tests</Link>
        </div>
      )}

      {/* Certificate expiry watchlist */}
      {(data.expiringCertificates?.length || 0) > 0 && (
        <div className="card card-flush overflow-hidden">
          <div className="card-header">
            <div className="flex items-center gap-2.5">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-mutedgold/50 text-errormocha">
                <AlertTriangle className="h-4.5 w-4.5" />
              </div>
              <h3 className="card-title">Certificates Expiring / Expired</h3>
            </div>
            <Link to="/instruments?certStatus=expiring" className="-my-1.5 py-1.5 text-xs font-bold text-caramel hover:text-mocha">View all →</Link>
          </div>
          <div className="divide-y divide-softgold/50">
            {data.expiringCertificates.map((c) => (
              <Link key={c.id} to={`/instruments/${c.id}`} className="flex flex-wrap items-center justify-between gap-2 px-5 py-3 transition-colors hover:bg-cream">
                <div>
                  <p className="text-sm font-bold text-espresso">{c.name} <span className="font-mono text-[11px] text-forestsage">{c.instrument_code || ''}</span></p>
                  <p className="text-xs text-forestsage">{c.certificate_number || 'No certificate on record'} · expires {String(c.certificate_expiry).slice(0, 10)}</p>
                </div>
                <span className={`badge ${c.status === 'expired' ? 'badge-red' : 'badge-amber'}`}>
                  {c.status === 'expired' ? 'Expired' : c.daysLeft <= 7 ? `Expires in ${c.daysLeft}d` : 'Expiring soon'}
                </span>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Recent sessions */}
      <div className="card card-flush overflow-hidden">
        <div className="card-header">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-sage/40 text-forestsage">
              <ClipboardList className="h-4.5 w-4.5" />
            </div>
            <h3 className="card-title">Recent Test Sessions</h3>
          </div>
          <Link to="/sessions" className="-my-1.5 py-1.5 text-xs font-bold text-caramel hover:text-mocha">
            View all →
          </Link>
        </div>
        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th scope="col">Instrument</th>
                <th scope="col">Engineer</th>
                <th scope="col">Reference Standard</th>
                <th scope="col">Status</th>
                <th scope="col">Updated</th>
              </tr>
            </thead>
            <tbody>
              {recentSessions.map((s) => {
                const st = STATUS_BADGE[s.status] || { label: s.status, cls: 'badge-slate' };
                return (
                  <tr key={s.id}>
                    <td>
                      <p className="font-bold text-espresso">{s.instrument_name}</p>
                      <p className="text-xs text-forestsage">{s.serial_number}</p>
                    </td>
                    <td className="text-forestsage">{s.engineer_name}</td>
                    <td className="text-forestsage">{s.reference_standard}</td>
                    <td>
                      <span className={`badge ${st.cls}`}>
                        {st.icon && <st.icon className="h-3 w-3" />}
                        {st.label}
                      </span>
                    </td>
                    <td className="whitespace-nowrap text-forestsage">
                      {(s.submitted_at || s.started_at || '').slice(0, 16).replace('T', ' ')}
                    </td>
                  </tr>
                );
              })}
              {recentSessions.length === 0 && (
                <tr>
                  <td colSpan="5" className="py-6 text-center">
                    <div className="mx-auto max-w-md">
                      <EmptyState tone="blue" icon={ClipboardList} title="No test sessions yet" subtitle="Start a session from the Instruments page to see recent activity here." ctaLabel="Browse instruments" ctaTo="/instruments" />
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
