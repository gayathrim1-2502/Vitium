import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ShieldCheck, CheckCircle2, XCircle, Loader2, FileBarChart2, MapPin, ImageIcon, FileText, CornerUpLeft,
} from 'lucide-react';
import { api } from '../api.js';
import { useAuth } from '../auth/AuthContext.jsx';

// Shown inside the wizard for submitted sessions when the current user is approver/admin.
export default function ApprovalPanel({ session, evaluation, files = [], onDecided }) {
  const { user } = useAuth();
  const [comment, setComment] = useState('');
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');

  if (session.status !== 'submitted') return null;
  if (!['approver', 'admin'].includes(user.role)) {
    return (
      <div className="card flex items-center gap-3 border-softgold bg-mutedgold/30 p-4">
        <Loader2 className="h-4.5 w-4.5 animate-spin text-caramel" />
        <p className="text-sm font-semibold text-errormocha">
          Submitted — awaiting review by an approver.
        </p>
      </div>
    );
  }

  async function decide(decision, correctionRequest = false) {
    setBusy(correctionRequest ? 'correction' : decision);
    setError('');
    try {
      const signature = decision === 'approved' && !correctionRequest
        ? `E-Sign:${user.fullName || 'User'}:${new Date().toISOString()}:session-${session.id}`
        : null;
      const d = await api(`/sessions/${session.id}/approval`, {
        method: 'PUT',
        body: { decision, comment: comment.trim(), signature, correctionRequest },
      });
      onDecided(d);
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy('');
    }
  }

  const failingModules = Object.entries(evaluation?.modules || {})
    .filter(([, m]) => m.verdict === 'fail')
    .map(([k]) => k);

  return (
    <div className="card card-flush overflow-hidden border-2 border-softgold">
      <div className="px-6 py-4" style={{ backgroundImage: 'linear-gradient(120deg, #C88A5A, #8B5E3C 60%, #6E4A2F)' }}>
        <p className="flex items-center gap-2 text-sm font-extrabold text-cream">
          <ShieldCheck className="h-5 w-5" /> Approver Review — {user.fullName || 'User'}
        </p>
        <p className="text-xs font-semibold text-softgold">
          Server evaluation: {evaluation?.overall === 'pass' ? 'PASS' : evaluation?.overall === 'fail' ? 'FAIL' : 'INCOMPLETE'}
          {failingModules.length > 0 && ` (failing: ${failingModules.join(', ')})`}
        </p>
      </div>
      <div className="p-6">
        {error && (
          <div className="mb-4 alert-error" role="alert">{error}</div>
        )}

        {/* Evidence summary for the reviewer */}
        <div className="mb-4 grid gap-3 sm:grid-cols-2">
          <div className="rounded-xl border border-softgold bg-sagecream px-4 py-3">
            <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-forestsage"><MapPin className="h-3.5 w-3.5" /> Inspection location</p>
            {session.latitude != null ? (
              <p className="mt-1 font-mono text-xs font-bold text-espresso">{session.latitude}, {session.longitude}{session.location_accuracy != null ? ` · ±${session.location_accuracy}m` : ''}</p>
            ) : session.location_text ? (
              <p className="mt-1 text-xs font-semibold text-espresso">{session.location_text}</p>
            ) : (
              <p className="mt-1 text-xs text-forestsage">Not captured by the engineer</p>
            )}
          </div>
          <div className="rounded-xl border border-softgold bg-sagecream px-4 py-3">
            <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-forestsage"><ImageIcon className="h-3.5 w-3.5" /> Evidence files ({files.length})</p>
            {files.length === 0 ? (
              <p className="mt-1 text-xs text-forestsage">No photos or documents attached</p>
            ) : (
              <div className="mt-1.5 flex flex-wrap gap-1.5">
                {files.slice(0, 4).map((f) => (
                  <a key={f.id} href={`/api/files/${f.id}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 rounded-lg border border-softgold bg-cream px-2 py-1 text-[10px] font-bold text-mocha hover:border-caramel">
                    {f.kind === 'photo' ? <ImageIcon className="h-3 w-3" /> : <FileText className="h-3 w-3" />}
                    {f.file_name.length > 18 ? `${f.file_name.slice(0, 16)}…` : f.file_name}
                  </a>
                ))}
                {files.length > 4 && <span className="text-[10px] font-bold text-forestsage">+{files.length - 4} more</span>}
              </div>
            )}
          </div>
        </div>

        <label className="field-label" htmlFor="ap-comment">Remarks / observations</label>
        <textarea
          id="ap-comment"
          className="input min-h-20"
          placeholder="Reviewer comments — required for rejections & corrections, optional for approvals…"
          value={comment}
          onChange={(e) => setComment(e.target.value)}
        />
        <div className="mt-4 flex flex-wrap items-center gap-3">
          <button onClick={() => decide('approved')} disabled={!!busy} className="btn-primary flex-1">
            {busy === 'approved' ? <span className="btn-spinner" /> : <CheckCircle2 className="h-4.5 w-4.5" />}
            Approve & e-sign
          </button>
          <button onClick={() => decide('rejected')} disabled={!!busy || !comment.trim()} className="btn-orange flex-1" title={comment.trim() ? 'Reject and send back with your remarks' : 'Add a remark first so the tester knows what to fix'}>
            {busy === 'rejected' ? <span className="btn-spinner" /> : <XCircle className="h-4.5 w-4.5" />}
            Reject with remarks
          </button>
        </div>
        <div className="mt-2.5 flex flex-wrap items-center gap-3">
          <button
            onClick={() => decide('approved', true)}
            disabled={!!busy || !comment.trim()}
            className="btn-secondary flex-1"
            title={comment.trim() ? 'Send back to the engineer for corrections without a formal rejection' : 'Describe what needs correcting first'}
          >
            {busy === 'correction' ? <span className="btn-spinner" /> : <CornerUpLeft className="h-4 w-4" />}
            Request correction
          </button>
          <Link to={`/sessions/${session.id}/report`} className="btn-secondary flex-1">
            <FileBarChart2 className="h-4 w-4" /> Open full report
          </Link>
        </div>
        <p className="field-hint mt-3 text-forestsage/80">
          Approving records your name + timestamp as an electronic signature, generates the certificate and locks the session read-only. “Request correction” returns it to the engineer without a formal rejection.
        </p>
      </div>
    </div>
  );
}
