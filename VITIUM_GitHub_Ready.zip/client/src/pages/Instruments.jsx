import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  Scale, Plus, Search, MapPin, Package, X,
  FlaskConical, Thermometer, PlayCircle, Pencil, CheckCircle2, XCircle, Info, TrendingUp,
} from 'lucide-react';
import { api } from '../api.js';
import { useAuth } from '../auth/AuthContext.jsx';
import EmptyState from '../components/EmptyState.jsx';
import useDialogFocus from '../lib/useDialogFocus.js';

const CLASS_COLORS = { I: 'badge-teal', II: 'badge-teal', III: 'badge-blue', IIII: 'badge-blue' };

const TEST_STATUS_META = {
  not_tested: { label: 'Not Tested', cls: 'badge-slate' },
  in_progress: { label: 'In Progress', cls: 'badge-amber' },
  passed: { label: 'Passed', cls: 'badge-green', icon: CheckCircle2 },
  failed: { label: 'Failed', cls: 'badge-red', icon: XCircle },
};

const INSTRUMENT_TYPES = ['Platform Scale', 'Bench Scale', 'Retail Scale', 'Jewellery Balance', 'Truck Weighbridge', 'Other Measuring Instrument'];

const emptyForm = {
  name: '', instrumentType: 'Platform Scale', manufacturer: '', model: '', serialNumber: '',
  maxCapacityKg: '', minCapacityKg: '', verificationScaleInterval: '', actualScaleInterval: '',
  division: '', unit: 'kg', accuracyClass: 'III', tareRange: '', location: '',
  ownerName: '', ownerContact: '', address: '', city: '', state: '', pinCode: '',
  installationDate: '', lastVerificationDate: '', certificateNumber: '', certificateExpiry: '',
  notes: '',
  applicantName: '', testLab: '', testDate: '',
};

export default function Instruments() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const [instruments, setInstruments] = useState(null);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState(params.get('notice') || '');
  const [query, setQuery] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);
  const panelRef = useDialogFocus(modalOpen, () => setModalOpen(false));

  useEffect(() => { document.title = 'Instruments · VITIUM'; }, []);
  useEffect(() => {
    if (notice) {
      const t = setTimeout(() => setNotice(''), 6000);
      return () => clearTimeout(t);
    }
  }, [notice]);

  const load = () => api('/instruments').then((d) => setInstruments(d.instruments)).catch((e) => setError(e.message));
  useEffect(() => { load(); }, []);

  function openCreate() {
    setEditing(null);
    setForm({ ...emptyForm, testDate: new Date().toISOString().slice(0, 10) });
    setFormError('');
    setModalOpen(true);
  }

  function openEdit(inst) {
    setEditing(inst);
    setForm({
      name: inst.name, manufacturer: inst.manufacturer, model: inst.model,
      serialNumber: inst.serial_number, maxCapacityKg: String(inst.max_capacity_kg),
      minCapacityKg: inst.min_capacity_kg != null ? String(inst.min_capacity_kg) : '',
      verificationScaleInterval: inst.verification_scale_interval,
      actualScaleInterval: inst.actual_scale_interval || '',
      tareRange: inst.tare_range || '', accuracyClass: inst.accuracy_class, location: inst.location,
      applicantName: inst.applicant_name || '', testLab: inst.test_lab || '', testDate: inst.test_date || '',
      instrumentType: inst.instrument_type || 'Platform Scale', division: inst.division || '', unit: inst.unit || 'kg',
      ownerName: inst.owner_name || '', ownerContact: inst.owner_contact || '', address: inst.address || '',
      city: inst.city || '', state: inst.state || '', pinCode: inst.pin_code || '',
      installationDate: inst.installation_date || '', lastVerificationDate: inst.last_verification_date || '',
      certificateNumber: inst.certificate_number || '', certificateExpiry: inst.certificate_expiry || '',
      notes: inst.notes || '',
    });
    setFormError('');
    setModalOpen(true);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setFormError('');
    setSaving(true);
    try {
      if (editing) {
        await api(`/instruments/${editing.id}`, { method: 'PATCH', body: form });
      } else {
        await api('/instruments', { method: 'POST', body: form });
      }
      setModalOpen(false);
      load();
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  }

  const filtered = (instruments || []).filter((i) =>
    `${i.name} ${i.manufacturer} ${i.model} ${i.serial_number} ${i.location} ${i.applicant_name} ${i.test_lab}`
      .toLowerCase().includes(query.toLowerCase())
  );

  if (error) return <div className="card border-errormocha/30 bg-errormocha/10 p-6 text-sm font-semibold text-errormocha">Failed to load instruments: {error}</div>;

  const input = (key, label, ph, type = 'text') => (
    <div>
      <label className="field-label" htmlFor={`i-${key}`}>{label}</label>
      <input id={`i-${key}`} className="input" type={type} required={key !== 'minCapacityKg'} placeholder={ph}
        value={form[key]} onChange={(e) => setForm({ ...form, [key]: e.target.value })} />
    </div>
  );

  return (
    <div className="fade-up space-y-5">
      {notice && (
        <div className="flex items-start gap-2.5 rounded-xl border border-softgold bg-mutedgold/30 px-4 py-3 text-sm font-medium text-errormocha">
          <Info className="mt-0.5 h-4 w-4 shrink-0" /> {notice}
        </div>
      )}

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="relative w-full max-w-sm">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-forestsage/70" />
          <input className="input pl-10" aria-label="Search instruments" placeholder="Search by name, model, serial, lab…" value={query} onChange={(e) => setQuery(e.target.value)} />
        </div>
        {user.role === 'admin' && (
          <button className="btn-primary" onClick={openCreate}>
            <Plus className="h-4.5 w-4.5" /> Register Instrument
          </button>
        )}
      </div>
      {instruments && (
        <p className="text-xs font-medium text-forestsage/80">Showing {filtered.length} of {instruments.length} instruments</p>
      )}

      {!instruments ? (
        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {[...Array(6)].map((_, i) => <div key={i} className="card h-52 animate-pulse bg-sagecream" />)}
        </div>
      ) : filtered.length === 0 && instruments.length === 0 ? (
        <div className="card">
          <EmptyState
            tone="blue"
            icon={Scale}
            title="No instruments registered yet"
            subtitle={user.role === 'admin' ? 'Use “Register Instrument” above to add your first instrument and get its auto-generated ID, QR code and barcode.' : 'An administrator needs to register instruments before test sessions can begin.'}
          />
        </div>
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((inst) => {
            const st = TEST_STATUS_META[inst.test_status] || TEST_STATUS_META.not_tested;
            return (
              <div key={inst.id} className="card group relative overflow-hidden p-5 transition-all duration-200 hover:-translate-y-1 hover:shadow-xl active:-translate-y-0.5">
                <div className={`absolute inset-x-0 top-0 h-1.5 ${inst.test_status === 'passed' ? 'bg-gradient-to-r from-sage to-forestsage' : inst.test_status === 'failed' ? 'bg-gradient-to-r from-errormocha to-mocha' : inst.test_status === 'in_progress' ? 'bg-gradient-to-r from-mutedgold to-softgold' : 'bg-gradient-to-r from-softgold to-mutedgold'}`} />
                <div className="flex items-start justify-between">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-caramel to-mocha text-cream shadow-md shadow-mocha/20 transition-transform duration-200 group-hover:scale-110">
                    <Scale className="h-5.5 w-5.5" />
                  </div>
                  <span className={`badge ${st.cls}`}>
                    {st.icon && <st.icon className="h-3 w-3" />} {st.label}
                  </span>
                </div>
                <h3 className="mt-3.5">
                <button
                type="button"
                className="text-left text-base font-extrabold tracking-tight text-darkgreen transition-colors hover:text-caramel"
                onClick={() => navigate(`/instruments/${inst.id}`)}
                title="View history & drift analytics"
              >
                {inst.name}
                </button>
              </h3>
                <p className="text-xs font-semibold text-forestsage">{inst.manufacturer} · {inst.model}</p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  <button onClick={() => navigate(`/instruments/${inst.id}`)} className={`badge ${CLASS_COLORS[inst.accuracy_class] || 'badge-slate'} transition-transform hover:scale-105`}>Class {inst.accuracy_class}</button>
                  <span className="badge badge-teal">{inst.verification_scale_interval}</span>
                  {inst.test_count > 0 && <button onClick={() => navigate(`/instruments/${inst.id}`)} className="badge badge-slate transition-transform hover:scale-105">{inst.test_count} session{inst.test_count !== 1 ? 's' : ''}</button>}
                </div>
                <div className="mt-4 space-y-1.5 border-t border-softgold/40 pt-3.5 text-xs text-forestsage">
                  <p className="flex items-center gap-1.5"><Package className="h-3.5 w-3.5 text-forestsage/70" /> S/N {inst.serial_number} · {inst.min_capacity_kg ?? 0}–{inst.max_capacity_kg} kg</p>
                  <p className="flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5 text-forestsage/70" /> {inst.location}</p>
                  <p className="flex items-center gap-1.5"><FlaskConical className="h-3.5 w-3.5 text-forestsage/70" /> {inst.test_lab || '—'}</p>
                </div>
                <div className="mt-4 flex gap-2">
                  <button
                    onClick={() => navigate(`/sessions/new?instrumentId=${inst.id}`)}
                    className="btn-primary flex-1 btn-sm"
                  >
                    <PlayCircle className="h-4 w-4" /> {inst.test_status === 'in_progress' ? 'Resume Test' : 'Start Test'}
                  </button>
                  <button onClick={() => navigate(`/instruments/${inst.id}`)} className="btn-secondary btn-sm" title="History & drift chart">
                    <TrendingUp className="h-4 w-4" />
                  </button>
                  {user.role === 'admin' && (
                    <button onClick={() => openEdit(inst)} className="btn-secondary btn-sm" title="Edit instrument">
                      <Pencil className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
          {filtered.length === 0 && (
            <div className="card col-span-full">
              <EmptyState
                tone="blue"
                icon={Scale}
                title="No instruments match your search"
                subtitle="Try a different manufacturer, model or serial number."
              />
            </div>
          )}
        </div>
      )}

      {/* Add / edit instrument modal */}
      {modalOpen && (
        <div className="modal-overlay flex items-start justify-center overflow-y-auto p-4 sm:p-8" onClick={() => setModalOpen(false)}>
          <div ref={panelRef} tabIndex={-1} role="dialog" aria-modal="true" aria-label={editing ? 'Edit Instrument' : 'Register Instrument'} className="card card-flush w-full max-w-2xl fade-up" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header rounded-t-2xl" style={{ backgroundImage: 'linear-gradient(120deg, #C88A5A, #8B5E3C 55%, #6E4A2F)' }}>
              <h3 className="modal-title text-cream">{editing ? 'Edit Instrument' : 'Register Instrument'}</h3>
              <button onClick={() => setModalOpen(false)} className="modal-close text-cream/80 hover:bg-cream/10 hover:text-cream"><X className="h-5 w-5" /></button>
            </div>
            {formError && <div className="mx-6 mt-4 alert-error" role="alert">{formError}</div>}
            <form onSubmit={handleSubmit} className="grid gap-4 p-6 sm:grid-cols-2">
              {input('name', 'Instrument Name', 'Platform Scale A')}
              <div>
                <label className="field-label" htmlFor="i-instrumentType">Instrument Type</label>
                <select id="i-instrumentType" className="input" value={form.instrumentType} onChange={(e) => setForm({ ...form, instrumentType: e.target.value })}>
                  {INSTRUMENT_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              {input('serialNumber', 'Serial No.', 'MT-PTH-0091')}
              {input('manufacturer', 'Manufacturer', 'Mettler Toledo')}
              {input('model', 'Model', 'PTH-300')}
              {input('maxCapacityKg', 'Max Capacity (kg)', '300', 'number')}
              {input('minCapacityKg', 'Capacity (Min, kg)', '1', 'number')}
              {input('division', 'Division / Resolution', '20 g')}
              <div>
                <label className="field-label" htmlFor="i-unit">Unit</label>
                <select id="i-unit" className="input" value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })}>
                  {['kg', 'g', 't'].map((u) => <option key={u} value={u}>{u}</option>)}
                </select>
              </div>
              {input('verificationScaleInterval', 'Verification Interval (e)', 'e = 100 g')}
              {input('actualScaleInterval', 'Actual Scale Interval (d)', 'd = 20 g')}
              {input('tareRange', 'Tare Range', '-10% Max to 0')}
              <div>
                <label className="field-label" htmlFor="i-accuracyClass">Accuracy Class</label>
                <select id="i-accuracyClass" className="input" value={form.accuracyClass} onChange={(e) => setForm({ ...form, accuracyClass: e.target.value })}>
                  {['I', 'II', 'III', 'IIII'].map((c) => <option key={c} value={c}>Class {c}</option>)}
                </select>
              </div>
              {input('location', 'Location', 'Warehouse 1, Mumbai')}
              {input('ownerName', 'Owner / Business Name', 'Acme Industries Ltd')}
              {input('ownerContact', 'Owner Contact', '+91 98765 43210')}
              {input('address', 'Address', 'Plot 12, MIDC Phase 2')}
              {input('city', 'City', 'Pune')}
              {input('state', 'State', 'Maharashtra')}
              {input('pinCode', 'PIN Code', '411019')}
              {input('installationDate', 'Installation Date', '', 'date')}
              {input('lastVerificationDate', 'Last Verification Date', '', 'date')}
              {input('certificateNumber', 'Certificate Number', 'VTM-CERT-2026-000001')}
              {input('certificateExpiry', 'Certificate Expiry Date', '', 'date')}
              <div className="sm:col-span-2">
                <label className="field-label" htmlFor="i-notes">Notes</label>
                <textarea id="i-notes" className="input" rows={2} placeholder="Optional remarks — seals, accessories, site conditions…" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
              </div>
              {input('applicantName', 'Applicant Name', 'Acme Industries Ltd')}
              {input('testLab', 'Test Lab', 'NAWI Test Lab 1')}
              {input('testDate', 'Date', '', 'date')}
              <div className="flex items-end gap-1.5 text-xs text-forestsage/80 sm:col-span-2">
                <Thermometer className="h-3.5 w-3.5" /> On creation, a unique Instrument ID (VTM-INS-XXXXXX), QR code and barcode are generated automatically.
              </div>
              <div className="sm:col-span-2">
                <button type="submit" disabled={saving} className="btn-primary w-full">
                  {saving ? 'Saving…' : editing ? 'Save changes' : 'Register instrument'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
