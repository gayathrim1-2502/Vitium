import { useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { Plus, CheckCircle2, XCircle, Clock, Activity, FileEdit, Info, X, PlayCircle, FileBarChart2, ClipboardList, Eye } from 'lucide-react';
import { api } from '../api.js';
import { useAuth } from '../auth/AuthContext.jsx';
import { MODULE_ORDER } from '../tests/modules.jsx';
import EmptyState from '../components/EmptyState.jsx';
import useDialogFocus from '../lib/useDialogFocus.js';

const FILTERS = [
  { key: 'all', label: 'All' },
  { key: 'draft', label: 'Draft' },
  { key: 'in_progress', label: 'In Progress' },
  { key: 'submitted', label: 'Submitted' },
  { key: 'approved', label: 'Approved' },
  { key: 'rejected', label: 'Rejected' },
];

const STATUS_BADGE = {
  draft: { label: 'Draft', cls: 'badge-slate', icon: FileEdit },
  in_progress: { label: 'In Progress', cls: 'badge-blue', icon: Activity },
  submitted: { label: 'Submitted', cls: 'badge-amber', icon: Clock },
  approved: { label: 'Approved', cls: 'badge-green', icon: CheckCircle2 },
  rejected: { label: 'Rejected', cls: 'badge-red', icon: XCircle },
};

export default function TestSessions() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const statusFilter = params.get('status') || 'all';
  const preselectInstrument = params.get('instrumentId') || '';
  const [sessions, setSessions] = useState(null);
  const [instruments, setInstruments] = useState([]);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({ instrumentId: '', referenceStandard: '', ambientTempC: '', ambientHumidityPct: '' });
  const [formError, setFormError] = useState('');
  const [creating, setCreating] = useState(false);
  const panelRef = useDialogFocus(modalOpen, () => setModalOpen(false));

  useEffect(() => { document.title = 'Test Sessions · VITIUM'; }, []);

  const load = () => {
    api('/sessions').then((d) => setSessions(d.sessions)).catch((e) => setError(e.message));
    api('/instruments').then((d) => setInstruments(d.instruments)).catch(() => {});
  };
  useEffect(() => { load(); }, []);

  const canCreate = user.role === 'engineer' || user.role === 'admin';

  // Auto-open the new-session modal when arriving with ?instrumentId= (from Instruments page)
  useEffect(() => {
    if (preselectInstrument && canCreate) {
      setForm((f) => ({ ...f, instrumentId: preselectInstrument }));
      setModalOpen(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [preselectInstrument]);

  async function handleCreate(e) {
    e.preventDefault();
    setFormError('');
    setCreating(true);
    try {
      const d = await api('/sessions', { method: 'POST', body: { instrumentId: Number(form.instrumentId), referenceStandard: form.referenceStandard, ambientTempC: form.ambientTempC === '' ? null : Number(form.ambientTempC), ambientHumidityPct: form.ambientHumidityPct === '' ? null : Number(form.ambientHumidityPct) } });
      setModalOpen(false);
      params.delete('instrumentId');
      setParams(params, { replace: true });
      navigate(`/sessions/${d.session.id}`);
    } catch (err) {
      if (err.status === 409 && err.data?.sessionId) {
        setModalOpen(false);
        setNotice('This instrument already has an open session — resuming it.');
        navigate(`/sessions/${err.data.sessionId}`);
      } else {
        setFormError(err.message);
      }
    } finally {
      setCreating(false);
    }
  }

  const filtered = (sessions || []).filter((s) => statusFilter === 'all' || s.status === statusFilter);
  const selectedInst = instruments.find((i) => String(i.id) === String(form.instrumentId));

  if (error) return <div className="card border-errormocha/30 bg-errormocha/10 p-6 text-sm font-semibold text-errormocha">Failed to load sessions: {error}</div>;

  return (
    <div className="fade-up space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-2">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              onClick={() => (f.key === 'all' ? setParams({}) : setParams({ status: f.key }))}
              className={`rounded-full px-4 py-2 text-xs font-bold transition-all duration-200 active:scale-95 ${
                statusFilter === f.key
                  ? 'bg-gradient-to-r from-caramel to-mocha text-cream shadow-md shadow-mocha/25'
                  : 'border border-softgold bg-sagecream text-forestsage hover:border-caramel hover:text-mocha'
              }`}
            >
              {f.label}
              {f.key !== 'all' && sessions && (
                <span className="ml-1.5 opacity-70">{sessions.filter((s) => s.status === f.key).length}</span>
              )}
            </button>
          ))}
        </div>
        {canCreate && (
          <button className="btn-orange" onClick={() => { setForm({ instrumentId: '', referenceStandard: '', ambientTempC: '', ambientHumidityPct: '' }); setFormError(''); setModalOpen(true); }}>
            <Plus className="h-4.5 w-4.5" /> New Session
          </button>
        )}
      </div>

      {notice && (
        <div className="flex items-start gap-2.5 rounded-xl border border-softgold bg-mutedgold/30 px-4 py-3 text-sm font-medium text-errormocha">
          <Info className="mt-0.5 h-4 w-4 shrink-0" /> {notice}
        </div>
      )}

      <div className="card card-flush overflow-hidden">
        <div className="overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr>
                <th scope="col">Session</th>
                <th scope="col">Instrument</th>
                <th scope="col">Engineer</th>
                <th scope="col">Reference Standard</th>
                <th scope="col">Progress</th>
                <th scope="col">Status</th>
                <th scope="col">Started</th>
                <th scope="col"></th>
              </tr>
            </thead>
            <tbody>
              {(filtered || []).map((s) => {
                const st = STATUS_BADGE[s.status] || { label: s.status, cls: 'badge-slate' };
                // Only the owning engineer (or an admin) may resume/edit a session.
                const isMine = user.role === 'admin' || s.engineer_id === user.id;
                const editable = ['draft', 'in_progress'].includes(s.status) && isMine;
                const pct = Math.round((s.completed_tests / MODULE_ORDER.length) * 100);
                return (
                  <tr key={s.id}>
                    <td className="font-bold text-darkgreen">#{String(s.id).padStart(4, '0')}</td>
                    <td>
                      <p className="font-semibold text-espresso">{s.instrument_name}</p>
                      <p className="whitespace-nowrap text-xs text-forestsage">{s.serial_number} · Class {s.accuracy_class}</p>
                    </td>
                    <td className="whitespace-nowrap text-forestsage">{s.engineer_name}</td>
                    <td className="whitespace-nowrap text-forestsage">{s.reference_standard}</td>
                    <td className="min-w-36">
                      <div className="flex items-center gap-2">
                        <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-softgold/30">
                          <div
                            className={`h-full rounded-full transition-all duration-300 ${s.completed_tests === MODULE_ORDER.length ? 'bg-gradient-to-r from-sage to-forestsage' : 'bg-gradient-to-r from-caramel to-softgold'}`}
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                        <span className="text-xs font-bold text-forestsage">{s.completed_tests}/{MODULE_ORDER.length}</span>
                      </div>
                    </td>
                    <td className="whitespace-nowrap">
                      <span className={`badge ${st.cls}`}>
                        {st.icon && <st.icon className="h-3 w-3" />}
                        {st.label}
                      </span>
                    </td>
                    <td className="whitespace-nowrap text-forestsage">{(s.started_at || '').slice(0, 16).replace('T', ' ')}</td>
                    <td className="text-right">
                      {editable && canCreate ? (
                        <Link to={`/sessions/${s.id}`} className="btn-secondary btn-sm">
                          <PlayCircle className="h-3.5 w-3.5" /> Resume
                        </Link>
                      ) : ['draft', 'in_progress'].includes(s.status) ? (
                        <Link to={`/sessions/${s.id}`} className="btn-secondary btn-sm">
                          <Eye className="h-3.5 w-3.5" /> View
                        </Link>
                      ) : (
                        <Link to={`/sessions/${s.id}/report`} className="btn-secondary btn-sm">
                          <FileBarChart2 className="h-3.5 w-3.5" /> Report
                        </Link>
                      )}
                    </td>
                  </tr>
                );
              })}
              {!sessions && (
                <tr><td colSpan="8" className="py-10 text-center text-sm text-forestsage/70">Loading sessions…</td></tr>
              )}
              {sessions && filtered.length === 0 && (
                <tr><td colSpan="8" className="py-6 text-center">
                  <div className="mx-auto max-w-md">
                    <EmptyState tone="blue" icon={ClipboardList} title="No sessions with this status" subtitle="Completed sessions appear here as they move through the workflow." />
                  </div>
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      {sessions && (
        <p className="text-xs font-medium text-forestsage/80">Showing {filtered.length} of {sessions.length} sessions</p>
      )}

      {/* New session modal */}
      {modalOpen && (
        <div className="modal-overlay flex items-center justify-center p-4" onClick={() => setModalOpen(false)}>
          <div ref={panelRef} tabIndex={-1} role="dialog" aria-modal="true" aria-label="New Test Session" className="card card-flush w-full max-w-md fade-up" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header rounded-t-2xl" style={{ backgroundImage: 'linear-gradient(120deg, #C88A5A, #8B5E3C 55%, #6E4A2F)' }}>
              <h3 className="modal-title text-cream">New Test Session</h3>
              <button onClick={() => setModalOpen(false)} className="modal-close text-cream/80 hover:bg-cream/10 hover:text-cream"><X className="h-5 w-5" /></button>
            </div>
            {formError && <div className="mx-6 mt-4 alert-error" role="alert">{formError}</div>}
            <form onSubmit={handleCreate} className="space-y-4 p-6">
              <div>
                <label className="field-label" htmlFor="ts-instrument">Instrument</label>
                <select id="ts-instrument" className="input" required value={form.instrumentId} onChange={(e) => setForm({ ...form, instrumentId: e.target.value })}>
                  <option value="">Select an instrument…</option>
                  {instruments.map((i) => (
                    <option key={i.id} value={i.id}>
                      {i.name} · {i.serial_number}
                    </option>
                  ))}
                </select>
                {selectedInst && (
                  <p className="mt-1.5 text-xs text-forestsage/80">
                    Class {selectedInst.accuracy_class} · {selectedInst.verification_scale_interval} · Max {selectedInst.max_capacity_kg} kg
                  </p>
                )}
              </div>
              <div>
                <label className="field-label" htmlFor="ts-refstd">Reference Standard</label>
                <input id="ts-refstd" className="input" required placeholder="E2-1kg Certified Set" value={form.referenceStandard} onChange={(e) => setForm({ ...form, referenceStandard: e.target.value })} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="field-label" htmlFor="ts-temp">Ambient Temp (°C)</label>
                  <input id="ts-temp" className="input" type="number" step="0.1" placeholder="23" value={form.ambientTempC} onChange={(e) => setForm({ ...form, ambientTempC: e.target.value })} />
                </div>
                <div>
                  <label className="field-label" htmlFor="ts-humidity">Humidity (% RH)</label>
                  <input id="ts-humidity" className="input" type="number" step="0.1" placeholder="48" value={form.ambientHumidityPct} onChange={(e) => setForm({ ...form, ambientHumidityPct: e.target.value })} />
                </div>
              </div>
              <button type="submit" disabled={creating} className="btn-primary w-full">
                {creating ? 'Creating…' : 'Create & open wizard'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
