import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, Download, CheckCircle2, XCircle, ShieldCheck, Lock, QrCode } from 'lucide-react';
import QRCodeLib from 'qrcode';
import { api } from '../api.js';
import { TEST_MODULES, moduleMeta } from '../tests/modules.jsx';
import PassBadge from '../tests/PassBadge.jsx';

const fmtKg = (v) => (v === null || v === undefined || v === '' ? '—' : `${Math.round(Number(v) * 10000) / 10000} kg`);
// '—' when a row was never evaluated (no data entered), instead of a misleading Fail
const vTxt = (c) => (c?.pass === true ? 'Pass' : c?.pass === false ? 'Fail' : '—');

function ResultTable({ title, columns, rows }) {
  if (!rows.length) return null;
  return (
    <div className="mt-4">
      <p className="mb-1.5 text-xs font-extrabold uppercase tracking-wider text-mocha">{title}</p>
      <table className="w-full text-xs">
        <thead>
          <tr>
            {columns.map((c, i) => (
              <th key={i} scope="col" className="border border-softgold bg-cream px-2.5 py-1.5 text-left font-bold text-forestsage">{c}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className={r.fail ? 'bg-errormocha/10' : ''}>
              {r.cells.map((c, j) => (
                <td key={j} className="border border-softgold/60 px-2.5 py-1.5 text-espresso">{c}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function SessionReport() {
  const { id } = useParams();
  const [payload, setPayload] = useState(null);
  const [error, setError] = useState('');
  const [generating, setGenerating] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState(null);

  useEffect(() => { document.title = 'Test Report · VITIUM'; }, []);

  useEffect(() => {
    api(`/sessions/${id}/report`).then(setPayload).catch((e) => setError(e.message));
  }, [id]);

  // Hooks must run on every render — keep QR generation above the early returns.
  const reportUid = payload?.session?.report_uid || null;
  const verifyUrl = reportUid ? `${window.location.origin}/verify/${reportUid}` : null;
  useEffect(() => {
    if (!verifyUrl) { setQrDataUrl(null); return; }
    QRCodeLib.toDataURL(verifyUrl, { width: 220, margin: 1, color: { dark: '#3B2720', light: '#F5E6D3' } })
      .then(setQrDataUrl)
      .catch(() => {});
  }, [verifyUrl]);

  if (error) {
    return (
      <div className="space-y-4">
        <div className="card border-errormocha/30 bg-errormocha/10 p-6 text-sm font-semibold text-errormocha">{error}</div>
        <Link to="/sessions" className="btn-secondary">← Back to sessions</Link>
      </div>
    );
  }
  if (!payload) return <div className="card h-96 animate-pulse bg-sagecream" />;

  const { session, instrument, tests, evaluation, approval, org, mpeSource, loadPoints } = payload;
  const approved = session.status === 'approved';
  const overall = evaluation?.overall;

  // Verdict pill sits on the dark report header, so it needs an opaque surface:
  // translucent fills wash out and leave the label unreadable.
  const verdictStyle = overall === 'pass'
    ? { border: 'border-forestsage', text: 'text-darkgreen' }
    : overall === 'fail'
    ? { border: 'border-errormocha', text: 'text-errormocha' }
    : { border: 'border-softgold', text: 'text-forestsage' };

  // ---- tables per module ----
  const tables = [];
  const lp = loadPoints;
  const t = tests;

  tables.push({
    key: 'visual',
    title: '1. Visual / Administrative Inspection',
    columns: ['Requirement', 'Observed', 'Verdict'],
    rows: (evaluation?.modules?.visual?.checks || []).map((c) => ({
      cells: [c.label, c.observed, vTxt(c)],
      fail: !c.pass,
    })),
  });

  const repRows = (t.repeatability?.data?.readings || []).map((row, i) => {
    const vals = [row.r1, row.r2, row.r3].filter((v) => v !== null && v !== undefined && v !== '');
    const spread = vals.length >= 2 ? (Math.max(...vals.map(Number)) - Math.min(...vals.map(Number))).toFixed(4) : '—';
    const c = evaluation?.modules?.repeatability?.checks?.[i];
    return { cells: [`${row.load ?? '—'} kg`, row.r1 ?? '—', row.r2 ?? '—', row.r3 ?? '—', spread, vTxt(c)], fail: c && !c.pass };
  });
  tables.push({ key: 'repeatability', title: '2. Repeatability Test', columns: ['Load', 'Reading 1', 'Reading 2', 'Reading 3', 'Spread', 'Verdict'], rows: repRows });

  const pos = lp?.eccentricity?.positions || [];
  const eccRows = pos.map((p, i) => {
    const d = t.eccentricity?.data?.[p] || {};
    const c = evaluation?.modules?.eccentricity?.checks?.[i];
    return { cells: [p, fmtKg(d.indication), fmtKg(d.error), vTxt(c)], fail: c && !c.pass };
  });
  tables.push({ key: 'eccentricity', title: '3. Eccentricity (Corner Load) Test', columns: ['Position', 'Indication', 'Error', 'Verdict'], rows: eccRows });

  const discRows = (t.discrimination?.data?.points || []).map((row, i) => {
    const c = evaluation?.modules?.discrimination?.checks?.[i];
    return { cells: [fmtKg(row.load), `+${row.extraLoad ?? '—'} kg`, row.changed ? 'Changed' : 'No change', vTxt(c)], fail: c && !c.pass };
  });
  tables.push({ key: 'discrimination', title: '4. Discrimination Test', columns: ['Load', 'Extra Load', 'Indication Change', 'Verdict'], rows: discRows });

  const weighRows = [];
  for (const dir of ['increasing', 'decreasing']) {
    for (const [i, row] of (t.weighing?.data?.[dir] || []).entries()) {
      const pt = lp?.weighing?.[dir]?.[i];
      const check = (evaluation?.modules?.weighing?.checks || []).find((c) => c.label.includes(dir === 'increasing' ? '↑' : '↓') && c.label.includes(`${row.load}`));
      weighRows.push({
        cells: [dir === 'increasing' ? '↑' : '↓', `${row.load ?? '—'} kg`, pt ? `${pt.mpeE}e` : '—', fmtKg(row.indication), fmtKg(row.error), vTxt(check)],
        fail: check && !check.pass,
      });
    }
  }
  tables.push({ key: 'weighing', title: '5. Weighing / Accuracy Test', columns: ['Dir', 'Load', 'MPE', 'Indication', 'Error', 'Verdict'], rows: weighRows });

  const zeroLabels = ['Initial zero', 'After 0.5e correction', 'After 1e correction', 'Zero-tracking 15 min'];
  const zeroRows = Object.entries(t.zero?.data?.rows || {}).map(([i, row]) => {
    const c = evaluation?.modules?.zero?.checks?.find((x) => x.label === zeroLabels[i]);
    return { cells: [zeroLabels[i] || `Check ${i}`, fmtKg(row.value), row.ok ? 'Yes' : 'No', vTxt(c)], fail: c && !c.pass };
  });
  tables.push({ key: 'zero', title: '6. Zero-Setting & Zero-Tracking', columns: ['Check', 'Result (kg)', 'OK', 'Verdict'], rows: zeroRows });

  const tareRows = (lp?.tare?.netLoads || []).map((nl, i) => {
    const row = (t.tare?.data?.netRows || [])[i] || {};
    const c = evaluation?.modules?.tare?.checks?.[i];
    return { cells: [`${nl ?? '—'} kg`, fmtKg(row.indication), fmtKg(row.error), vTxt(c)], fail: c && !c.pass };
  });
  tables.push({ key: 'tare', title: '7. Accuracy of Tare Setting', columns: ['Net Load', 'Indication', 'Error', 'Verdict'], rows: tareRows });

  const priceApplicable = t.price?.data?.applicable !== 'no';
  const priceRows = priceApplicable
    ? (lp?.price?.loads || []).map((l, i) => {
        const row = (t.price?.data?.rows || [])[i] || {};
        const c = evaluation?.modules?.price?.checks?.[i];
        return { cells: [`${l ?? '—'} kg`, row.displayed ?? '—', row.expected ?? '—', vTxt(c)], fail: c && !c.pass };
      })
    : [{ cells: ['Not applicable — non price-indicating instrument', '', '', 'Pass'], fail: false }];
  tables.push({ key: 'price', title: '8. Price Computation Accuracy', columns: ['Load', 'Displayed', 'Expected', 'Verdict'], rows: priceRows });

  const inflRows = (lp?.influence?.temperaturesC || []).map((temp, i) => {
    const row = (t.influence?.data?.temps || [])[i] || {};
    const c = evaluation?.modules?.influence?.checks?.[i];
    return { cells: [`${temp}°C`, `${row.actual ?? '—'}°C`, fmtKg(row.indication), fmtKg(row.error), vTxt(c)], fail: c && !c.pass };
  });
  if (t.influence?.data?.warmUp30 != null || t.influence?.data?.warmUp60 != null) {
    const check = (evaluation?.modules?.influence?.checks || []).find((c) => c.label.includes('Warm-up'));
    inflRows.push({ cells: ['Warm-up 30→60 min', '', fmtKg(t.influence?.data?.warmUp60), check?.observed || '—', vTxt(check)], fail: check && !check.pass });
  }
  tables.push({ key: 'influence', title: '9. Influence Factors (Temperature / Warm-up)', columns: ['Point', 'Actual', 'Indication', 'Error / Drift', 'Verdict'], rows: inflRows });

  // ---- PDF generation (jsPDF, vector text — no screenshots) ----
  async function downloadPdf() {
    setGenerating(true);
    try {
      const { jsPDF } = await import('jspdf');
      const doc = new jsPDF({ unit: 'mm', format: 'a4' });
      const W = 210, M = 14;
      let y = 0;

      // Brand header band
      doc.setFillColor(139, 94, 60);
      doc.rect(0, 0, W, 30, 'F');
      doc.setFillColor(217, 183, 122);
      doc.rect(0, 30, W, 2.5, 'F');
      doc.setTextColor(255);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(16);
      doc.text(org.org_name || 'VITIUM', M, 13);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.text('Test Report — Non-Automatic Weighing Instruments (OIML R 76)', M, 20);
      doc.setFontSize(8);
      doc.text(`Session #${String(session.id).padStart(4, '0')}`, W - M, 13, { align: 'right' });
      doc.text(session.started_at?.slice(0, 16).replace('T', ' ') || '', W - M, 20, { align: 'right' });
      y = 42;

      const section = (label) => {
        doc.setTextColor(139, 94, 60);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10.5);
        doc.text(label, M, y);
        y += 2;
        doc.setDrawColor(200, 138, 90);
        doc.setLineWidth(0.6);
        doc.line(M, y, M + 34, y);
        y += 4.5;
        doc.setTextColor(59, 39, 32);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(9);
      };

      const kv = (pairs) => {
        for (const [k, v] of pairs) {
          doc.setFont('helvetica', 'bold');
          doc.text(`${k}:`, M, y);
          doc.setFont('helvetica', 'normal');
          doc.text(String(v ?? '—'), M + 42, y, { maxWidth: W - M * 2 - 44 });
          y += 5.4;
        }
      };

      const table = (cols, widths, rows, opts = {}) => {
        if (y > 258) { doc.addPage(); y = 20; }
        const h0 = 5.6;
        let x = M;
        doc.setFillColor(245, 230, 211);
        doc.rect(M, y - 4.2, W - M * 2, h0, 'F');
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(7.6);
        cols.forEach((c, i) => { doc.text(String(c), x + 1.4, y); x += widths[i]; });
        y += h0;
        doc.setFont('helvetica', 'normal');
        rows.forEach((r) => {
          if (y > 282) { doc.addPage(); y = 20; }
          const cells = Array.isArray(r) ? r : r.cells;
          const fail = Array.isArray(r) ? String(r[r.length - 1]).toLowerCase() === 'fail' : !!r.fail;
          const rowH = 5.4;
          if (opts.markFails && fail) {
            doc.setFillColor(240, 232, 222);
            doc.rect(M, y - 4.2, W - M * 2, rowH, 'F');
            doc.setTextColor(110, 74, 47);
          } else {
            doc.setTextColor(59, 39, 32);
          }
          let xx = M;
          cells.forEach((cell, i) => {
            doc.text(String(cell ?? ''), xx + 1.4, y, { maxWidth: widths[i] - 2.4 });
            xx += widths[i];
          });
          doc.setDrawColor(217, 183, 122);
          doc.setLineWidth(0.2);
          doc.line(M, y + 1.2, W - M, y + 1.2);
          y += rowH;
          doc.setTextColor(59, 39, 32);
        });
        y += 4;
      };

      section('Instrument Details');
      kv([
        ['Instrument', `${instrument.name} (${instrument.manufacturer} ${instrument.model})`],
        ['Serial number', instrument.serial_number],
        ['Accuracy class', instrument.accuracy_class],
        ['Capacity (Min–Max)', `${instrument.min_capacity_kg ?? 0} – ${instrument.max_capacity_kg} kg`],
        ['Scale intervals', `e ${instrument.verification_scale_interval} · d ${instrument.actual_scale_interval || instrument.verification_scale_interval}`],
        ['Tare range', instrument.tare_range || '—'],
        ['Applicant', instrument.applicant_name || '—'],
        ['Test lab', instrument.test_lab || '—'],
        ['Location', instrument.location],
        ['Test date', session.started_at?.slice(0, 10) || instrument.test_date || '—'],
        ['Reference standard', session.reference_standard],
        ['Ambient', `${session.ambient_temp_c ?? '—'} °C · ${session.ambient_humidity_pct ?? '—'} % RH`],
        ['Tested by', session.engineer_name],
      ]);
      y += 2;

      const defs = {
        visual: { t: '1. Visual / Administrative Inspection', c: ['Requirement', 'Observed', 'Verdict'], w: [95, 55, 32] },
        repeatability: { t: '2. Repeatability Test', c: ['Load', 'R1', 'R2', 'R3', 'Spread', 'Verdict'], w: [32, 30, 30, 30, 32, 28] },
        eccentricity: { t: '3. Eccentricity (Corner Load)', c: ['Position', 'Indication', 'Error', 'Verdict'], w: [55, 45, 45, 37] },
        discrimination: { t: '4. Discrimination Test', c: ['Load', 'Extra', 'Change', 'Verdict'], w: [45, 45, 55, 37] },
        weighing: { t: '5. Weighing / Accuracy Test', c: ['Dir', 'Load', 'MPE', 'Indication', 'Error', 'Verdict'], w: [14, 32, 26, 40, 40, 30] },
        zero: { t: '6. Zero-Setting & Zero-Tracking', c: ['Check', 'Result (kg)', 'OK', 'Verdict'], w: [75, 40, 25, 42] },
        tare: { t: '7. Accuracy of Tare Setting', c: ['Net Load', 'Indication', 'Error', 'Verdict'], w: [40, 45, 45, 52] },
        price: { t: '8. Price Computation Accuracy', c: ['Load', 'Displayed', 'Expected', 'Verdict'], w: [40, 45, 45, 52] },
        influence: { t: '9. Influence Factors', c: ['Point', 'Actual', 'Indication', 'Err/Drift', 'Verdict'], w: [36, 30, 38, 40, 38] },
      };
      for (const tb of tables) {
        const def = defs[tb.key];
        section(def.t);
        table(def.c, def.w, tb.rows, { markFails: true });
      }

      // Verdict box
      if (y > 235) { doc.addPage(); y = 20; }
      const pass = overall === 'pass';
      doc.setFillColor(pass ? 226 : 240, pass ? 232 : 232, pass ? 220 : 222);
      doc.setDrawColor(pass ? 101 : 110, pass ? 116 : 74, pass ? 93 : 47);
      doc.setLineWidth(0.5);
      doc.roundedRect(M, y, W - M * 2, 16, 2.5, 2.5, 'FD');
      doc.setTextColor(pass ? 48 : 110, pass ? 56 : 74, pass ? 47 : 47);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(12);
      doc.text(`OVERALL VERDICT: ${pass ? 'PASS' : overall === 'fail' ? 'FAIL' : 'INCOMPLETE'}`, W / 2, y + 10, { align: 'center' });
      y += 24;

      // QR verification block
      if (qrDataUrl && session.report_uid) {
        if (y > 220) { doc.addPage(); y = 20; }
        const qrSize = 26;
        doc.setDrawColor(200, 138, 90);
        doc.setLineWidth(0.4);
        doc.roundedRect(M, y, W - M * 2, qrSize + 8, 2, 2, 'S');
        doc.addImage(qrDataUrl, 'PNG', M + 4, y + 4, qrSize, qrSize);
        doc.setTextColor(139, 94, 60);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(9.5);
        doc.text('Scan to verify authenticity', M + qrSize + 10, y + 10);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8);
        doc.setTextColor(101, 116, 93);
        doc.text('This QR code opens the public verification page and confirms the report', M + qrSize + 10, y + 16);
        doc.text('was issued and digitally approved by the laboratory.', M + qrSize + 10, y + 21, { maxWidth: W - M * 2 - qrSize - 14 });
        doc.setTextColor(139, 94, 60);
        doc.setFontSize(7.5);
        doc.text(verifyUrl, M + qrSize + 10, y + 29, { maxWidth: W - M * 2 - qrSize - 14 });
        y += qrSize + 14;
      }

      // Signature section
      section('Signatures');
      doc.setFontSize(9);
      doc.text(`Tester: ${session.engineer_name}`, M, y);
      doc.text(`Date: ${session.submitted_at?.slice(0, 16).replace('T', ' ') || session.started_at?.slice(0, 16).replace('T', ' ') || '—'}`, M + 90, y);
      y += 8;
      if (approval) {
        doc.setFont('helvetica', 'bold');
        doc.text(`Reviewer: ${approval.approver_name}`, M, y);
        doc.setFont('helvetica', 'normal');
        doc.text(`Date: ${approval.signed_at?.slice(0, 16).replace('T', ' ') || '—'}`, M + 90, y);
        y += 6;
        doc.text(`Decision: ${approval.decision.toUpperCase()}`, M, y);
        y += 6;
        doc.text(`Signature: ${approval.signature || '—'}`, M, y, { maxWidth: W - M * 2 });
        y += 6;
        if (approval.comment) {
          doc.text(`Remarks: ${approval.comment}`, M, y, { maxWidth: W - M * 2 });
          y += 6;
        }
      } else {
        doc.text('Reviewer: pending approval', M, y);
        y += 6;
      }

      // Footer on every page
      const pages = doc.getNumberOfPages();
      for (let p = 1; p <= pages; p++) {
        doc.setPage(p);
        doc.setDrawColor(217, 183, 122);
        doc.setLineWidth(0.4);
        doc.line(M, 285, W - M, 285);
        doc.setFontSize(7.5);
        doc.setTextColor(101, 116, 93);
        doc.setFont('helvetica', 'normal');
        doc.text(org.certificate_footer || 'Issued in accordance with OIML R-76', M, 290);
        doc.text(`Page ${p} of ${pages}`, W - M, 290, { align: 'right' });
        doc.text(mpeSource || 'MPE per OIML R 76-1', W / 2, 290, { align: 'center', maxWidth: 70 });
      }

      doc.save(`NAWI-TestPro-Report-${String(session.id).padStart(4, '0')}.pdf`);
    } finally {
      setGenerating(false);
    }
  }

  return (
    <div className="fade-up mx-auto max-w-4xl space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Link to={`/sessions/${id}`} className="btn-secondary">
          <ArrowLeft className="h-4 w-4" /> Back to wizard
        </Link>
        <button onClick={downloadPdf} disabled={generating} className="btn-primary">
          {generating ? <span className="btn-spinner" /> : <Download className="h-4 w-4" />}
          Download PDF report
        </button>
      </div>

      {/* Report sheet */}
      <div className="card card-flush overflow-hidden">
        <div className="relative px-7 py-6" style={{ backgroundImage: 'linear-gradient(120deg, #C88A5A 0%, #8B5E3C 50%, #6E4A2F 100%)' }}>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-xs font-bold uppercase tracking-widest text-softgold">{org.org_name}</p>
              <h1 className="mt-0.5 text-2xl font-extrabold tracking-tight text-cream">Test Report — OIML R 76</h1>
              <p className="text-xs font-semibold text-cream/85">Non-Automatic Weighing Instruments · Session #{String(session.id).padStart(4, '0')}</p>
            </div>
            <div className="flex flex-col items-end gap-2">
              <span className={`badge ${approved ? 'badge-green' : session.status === 'rejected' ? 'badge-red' : session.status === 'submitted' ? 'badge-amber' : 'badge-slate'} !px-3 !py-1.5 !text-xs`}>
                {approved ? <CheckCircle2 className="h-3.5 w-3.5" /> : session.status === 'rejected' ? <XCircle className="h-3.5 w-3.5" /> : <Lock className="h-3.5 w-3.5" />}
                {session.status.toUpperCase()}
              </span>
              <span className={`rounded-xl border bg-cream px-3 py-1.5 text-xs font-extrabold ${verdictStyle.border} ${verdictStyle.text}`}>
                Verdict: {overall === 'pass' ? 'PASS' : overall === 'fail' ? 'FAIL' : 'INCOMPLETE'}
              </span>
            </div>
          </div>
        </div>

        {/* Instrument details grid */}
        <div className="grid gap-x-6 gap-y-2.5 border-b border-softgold/50 px-7 py-5 text-sm sm:grid-cols-2">
          {[
            ['Instrument', `${instrument.name} (${instrument.manufacturer} ${instrument.model})`],
            ['Serial number', instrument.serial_number],
            ['Accuracy class', instrument.accuracy_class],
            ['Capacity (Min–Max)', `${instrument.min_capacity_kg ?? 0} – ${instrument.max_capacity_kg} kg`],
            ['Scale intervals', `e ${instrument.verification_scale_interval} · d ${instrument.actual_scale_interval || instrument.verification_scale_interval}`],
            ['Tare range', instrument.tare_range || '—'],
            ['Applicant', instrument.applicant_name || '—'],
            ['Test lab', instrument.test_lab || '—'],
            ['Reference standard', session.reference_standard],
            ['Ambient', `${session.ambient_temp_c ?? '—'} °C · ${session.ambient_humidity_pct ?? '—'} % RH`],
            ['Tested by', session.engineer_name],
            ['Test date', session.started_at?.slice(0, 10)],
          ].map(([k, v]) => (
            <div key={k} className="flex justify-between gap-3 border-b border-dashed border-softgold/50 pb-1.5">
              <span className="text-xs font-bold uppercase tracking-wide text-forestsage/80">{k}</span>
              <span className="text-right text-xs font-semibold text-espresso">{v || '—'}</span>
            </div>
          ))}
        </div>

        {/* Results tables */}
        <div className="overflow-x-auto px-7 py-5">
          {tables.map((tb) => (
            <ResultTable key={tb.key} title={tb.title} columns={tb.columns} rows={tb.rows} />
          ))}

          <p className="mt-5 text-[11px] leading-relaxed text-forestsage/70">{mpeSource}</p>
        </div>

        {/* QR verification strip */}
        {verifyUrl && (
          <div className="flex flex-wrap items-center gap-5 border-t border-softgold/50 px-7 py-5">
            {qrDataUrl && (
              <img src={qrDataUrl} alt="Verification QR code" className="h-28 w-28 rounded-xl border border-softgold" />
            )}
            <div className="min-w-0 flex-1">
              <p className="flex items-center gap-2 text-sm font-extrabold text-mocha">
                <QrCode className="h-4.5 w-4.5 text-caramel" /> Scan to verify authenticity
              </p>
              <p className="mt-1 text-xs leading-relaxed text-forestsage">
                The QR on the downloaded PDF opens a public, login-free page confirming this report was issued and digitally approved.
              </p>
              <a href={verifyUrl} target="_blank" rel="noreferrer" className="mt-2 inline-block break-all text-[11px] font-bold text-caramel hover:text-mocha">
                {verifyUrl}
              </a>
            </div>
          </div>
        )}

        {/* Approval section */}
        <div className="border-t border-softgold/50 bg-cream/70 px-7 py-5">
          <p className="mb-3 flex items-center gap-2 text-xs font-extrabold uppercase tracking-wider text-mocha">
            <ShieldCheck className="h-4 w-4 text-caramel" /> Approval & Signature
          </p>
          {approval ? (
            <div className={`rounded-xl border p-4 ${approval.decision === 'approved' ? 'border-sage bg-sage/15' : 'border-errormocha/40 bg-errormocha/10'}`}>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="text-sm font-extrabold text-darkgreen">{approval.approver_name}</p>
                <span className={`badge ${approval.decision === 'approved' ? 'badge-green' : 'badge-red'}`}>
                  {approval.decision === 'approved' ? <CheckCircle2 className="h-3 w-3" /> : <XCircle className="h-3 w-3" />}
                  {approval.decision.toUpperCase()}
                </span>
              </div>
              <p className="mt-1 text-xs font-semibold text-forestsage">Signed: {approval.signed_at?.slice(0, 16).replace('T', ' ')}</p>
              <p className="mt-2 text-xs font-medium text-forestsage">
                <span className="font-bold text-espresso">Signature:</span> {approval.signature || '—'}
              </p>
              {approval.comment && (
                <p className="mt-2 text-xs font-medium italic text-forestsage">“{approval.comment}”</p>
              )}
            </div>
          ) : (
            <p className="text-sm font-medium text-forestsage/70">
              Awaiting reviewer decision — the approver signs here with name and timestamp.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
