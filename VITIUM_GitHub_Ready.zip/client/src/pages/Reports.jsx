import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { FileCheck2, CheckCircle2, XCircle, PenLine, FileBarChart2, Search } from 'lucide-react';
import { api } from '../api.js';
import EmptyState from '../components/EmptyState.jsx';

export default function Reports() {
  const [reports, setReports] = useState(null);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');

  useEffect(() => {
    let cancelled = false;
    api('/reports')
      .then((d) => !cancelled && setReports(d.reports))
      .catch((e) => !cancelled && setError(e.message));
    return () => { cancelled = true; };
  }, []);

  const filtered = (reports || []).filter((r) =>
    `${r.instrument_name} ${r.serial_number} ${r.engineer_name} ${r.id}`
      .toLowerCase()
      .includes(query.toLowerCase())
  );

  if (error) return <div className="card border-errormocha/30 bg-errormocha/10 p-6 text-sm font-semibold text-errormocha">Failed to load reports: {error}</div>;

  return (
    <div className="fade-up space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="relative w-full max-w-sm">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-forestsage/70" />
          <input
            className="input pl-10"
            aria-label="Search reports"
            placeholder="Search reports by instrument, engineer…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        {reports && (
          <p className="text-xs font-semibold text-forestsage">
            {reports.length} signed report{reports.length !== 1 ? 's' : ''}
          </p>
        )}
      </div>

      {!reports ? (
        <div className="grid gap-5 lg:grid-cols-2">
          {[...Array(4)].map((_, i) => <div key={i} className="card h-40 animate-pulse bg-sagecream" />)}
        </div>
      ) : (
        <div className="grid gap-5 lg:grid-cols-2">
          {filtered.map((r) => {
            const ok = r.status === 'approved';
            return (
              <div key={r.id} className={`card relative overflow-hidden p-5 transition-all duration-200 hover:-translate-y-1 hover:shadow-xl active:-translate-y-0.5`}>
                <div className={`absolute inset-x-0 top-0 h-1.5 ${ok ? 'bg-gradient-to-r from-sage to-forestsage' : 'bg-gradient-to-r from-errormocha to-mocha'}`} />
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className={`flex h-11 w-11 items-center justify-center rounded-xl text-cream shadow-md ${ok ? 'bg-gradient-to-br from-forestsage to-sage shadow-sage/40' : 'bg-gradient-to-br from-errormocha to-mocha shadow-mocha/30'}`}>
                      <FileCheck2 className="h-5.5 w-5.5" />
                    </div>
                    <div>
                      <p className="card-title">
                        Report #{String(r.id).padStart(4, '0')}
                      </p>
                      <p className="text-xs font-semibold text-forestsage">{r.instrument_name} · {r.serial_number}</p>
                    </div>
                  </div>
                  <span className={`badge ${ok ? 'badge-green' : 'badge-red'}`}>
                    {ok ? <CheckCircle2 className="h-3 w-3" /> : <XCircle className="h-3 w-3" />}
                    {ok ? 'Approved' : 'Rejected'}
                  </span>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-3 text-xs">
                  <div className="rounded-xl bg-cream p-3">
                    <p className="font-bold uppercase tracking-wide text-forestsage/70">Tested by</p>
                    <p className="mt-1 font-semibold text-espresso">{r.engineer_name}</p>
                  </div>
                  <div className="rounded-xl bg-cream p-3">
                    <p className="font-bold uppercase tracking-wide text-forestsage/70">Signed</p>
                    <p className="mt-1 font-semibold text-espresso">{(r.signed_at || r.approved_at || '').slice(0, 16).replace('T', ' ')}</p>
                  </div>
                </div>

                {r.comment && (
                  <p className="mt-3 rounded-xl border border-softgold/40 bg-cream px-3.5 py-2.5 text-xs italic text-forestsage">
                    “{r.comment}”
                  </p>
                )}

                <div className="mt-4 flex items-center justify-between border-t border-softgold/50 pt-3.5">
                  <span className={`inline-flex items-center gap-1.5 text-xs font-bold ${ok ? 'text-forestsage' : 'text-errormocha'}`}>
                    <PenLine className="h-3.5 w-3.5" />
                    {r.signature || 'Digital signature pending'}
                  </span>
                  <Link
                    to={`/sessions/${r.id}/report`}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-mocha px-3 py-1.5 text-xs font-bold text-cream transition-all hover:bg-errormocha hover:shadow-md"
                  >
                    <FileBarChart2 className="h-3.5 w-3.5" /> View report / PDF
                  </Link>
                </div>
              </div>
            );
          })}
          {reports.length === 0 && (
            <div className="card col-span-full">
              <EmptyState
                tone="orange"
                icon={FileCheck2}
                title="No signed reports yet"
                subtitle="Reports appear here once approvers review and digitally sign submitted sessions."
                ctaLabel="View test sessions"
                ctaTo="/sessions"
              />
            </div>
          )}
          {reports.length > 0 && filtered.length === 0 && (
            <div className="card col-span-full py-16 text-center text-sm text-forestsage/70">No reports match your search.</div>
          )}
        </div>
      )}
    </div>
  );
}
