import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { ShieldCheck, CheckCircle2, XCircle, Loader2, Fingerprint } from 'lucide-react';
import logoUrl from '../assets/vitium-logo.png';

// Public, login-free verification page opened from the QR code on approved reports.
export default function VerifyPage() {
  const { reportUid } = useParams();
  const [state, setState] = useState('loading'); // loading | ok | error
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    document.title = 'Verify Report · VITIUM';
  }, []);

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/verify/${reportUid}`)
      .then(async (r) => {
        const d = await r.json().catch(() => ({}));
        if (!cancelled) {
          if (r.ok && d.verified) { setData(d); setState('ok'); }
          else { setError(d.error || 'Verification failed'); setState('error'); }
        }
      })
      .catch(() => !cancelled && (setError('Network error'), setState('error')));
    return () => { cancelled = true; };
  }, [reportUid]);

  return (
    <div
      className="relative flex min-h-screen items-center justify-center overflow-hidden p-5"
      style={{ backgroundImage: 'linear-gradient(150deg, #C88A5A 0%, #8B5E3C 45%, #6E4A2F 100%)' }}
    >
      <div className="absolute -right-24 -top-24 h-96 w-96 rounded-full bg-softgold/25 blur-3xl" />
      <div className="absolute -bottom-32 -left-16 h-96 w-96 rounded-full bg-sage/25 blur-3xl" />
      <div className="absolute right-16 top-1/4 h-40 w-40 rounded-full border-[22px] border-cream/10" />

      <div className="w-full max-w-lg">
        <div className="mb-6 flex items-center justify-center gap-3">
          <img
            src={logoUrl}
            alt="VITIUM logo"
            className="h-12 w-12 shrink-0 rounded-2xl bg-cream/20 object-contain p-0.5 backdrop-blur"
          />
          <div>
            <p className="text-lg font-extrabold tracking-tight text-cream">VITIUM</p>
            <p className="text-xs font-semibold text-softgold">OIML R-76 Report Verification</p>
          </div>
        </div>

        <div className="card card-flush overflow-hidden fade-up">
          {state === 'loading' && (
            <div className="flex flex-col items-center gap-3 px-8 py-16">
              <Loader2 className="h-9 w-9 animate-spin text-caramel" />
              <p className="text-sm font-bold text-forestsage">Verifying report…</p>
            </div>
          )}

          {state === 'error' && (
            <div className="px-8 py-12 text-center">
              <span className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-errormocha/15">
                <XCircle className="h-9 w-9 text-errormocha" />
              </span>
              <h1 className="text-xl font-extrabold tracking-tight text-darkgreen">Not verified</h1>
              <p className="mx-auto mt-2 max-w-xs text-sm text-forestsage">{error}</p>
            </div>
          )}

          {state === 'ok' && data && (
            <div className="px-8 py-10 text-center">
              <span className="animate-check-pop mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-forestsage to-sage shadow-xl shadow-sage/50">
                <ShieldCheck className="h-11 w-11 text-cream" />
              </span>
              <div className="mx-auto inline-flex items-center gap-2 rounded-full bg-sage/45 px-4 py-1.5 text-xs font-extrabold uppercase tracking-widest text-darkgreen">
                <CheckCircle2 className="h-4 w-4" /> Verified Authentic
              </div>
              <h1 className="mt-4 text-2xl font-extrabold tracking-tight text-darkgreen">{data.reportId}</h1>
              <p className="mt-1 text-xs font-semibold text-forestsage">issued by {data.orgName || 'VITIUM'}</p>

              <div className="mt-6 grid gap-2.5 text-left">
                {[
                  ['Instrument', `${data.instrument.name}`],
                  ['Model', `${data.instrument.manufacturer} ${data.instrument.model}`],
                  ['Serial number', data.instrument.serialNumber],
                  ['Accuracy class', data.instrument.accuracyClass],
                  ['Tested by', data.engineerName],
                  ['Approved by', data.approverName],
                  ['Approval date', data.approvedAt?.slice(0, 16).replace('T', ' ')],
                ].map(([k, v]) => (
                  <div key={k} className="flex items-center justify-between gap-3 border-b border-dashed border-softgold/60 pb-2">
                    <span className="text-[11px] font-bold uppercase tracking-wide text-forestsage/80">{k}</span>
                    <span className="text-xs font-bold text-espresso">{v || '—'}</span>
                  </div>
                ))}
              </div>

              <div className="mt-6 flex items-center justify-center gap-2 rounded-2xl bg-mutedgold/25 px-4 py-3 text-xs font-semibold text-errormocha">
                <Fingerprint className="h-4 w-4" />
                Certificate ID {data.reportUid.slice(0, 13)}… · verified live against the issuing database
              </div>
            </div>
          )}
        </div>

        <p className="mt-6 text-center text-[11px] font-medium text-cream/70">
          This page is public and read-only — it confirms only that the report exists and was digitally approved.
        </p>
      </div>
    </div>
  );
}
