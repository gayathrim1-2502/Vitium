import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  BarChart3, TrendingUp, Factory, Layers, AlertTriangle, Wrench, PackageSearch,
  FileWarning, ArrowRight,
} from 'lucide-react';
import { api } from '../api.js';
import { BarChart, StackedBars, Legend } from '../components/charts.jsx';
import EmptyState from '../components/EmptyState.jsx';

// Chart series colors from the Warm Cream & Sage palette: Caramel, Soft Gold, Sage (rotating).
const SERIES = ['#C88A5A', '#D9B77A', '#A8B89F', '#8B5E3C', '#D6B98C', '#65745D'];
const CLASS_COLORS = { I: '#C88A5A', II: '#D9B77A', III: '#A8B89F', IIII: '#8B5E3C' };

export default function Analytics() {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => { document.title = 'Analytics · VITIUM'; }, []);

  useEffect(() => {
    api('/analytics').then(setData).catch((e) => setError(e.message));
  }, []);

  if (error) return <div className="card border-errormocha/30 bg-errormocha/10 p-6 text-sm font-semibold text-errormocha">{error}</div>;
  if (!data) return <div className="grid gap-5 lg:grid-cols-2">{[...Array(4)].map((_, i) => <div key={i} className="card h-64 animate-pulse bg-sagecream" />)}</div>;

  const classData = data.passByClass
    .filter((c) => c.approved + c.rejected > 0)
    .map((c) => ({
      label: `Class ${c.cls}`,
      value: Math.round((c.approved / (c.approved + c.rejected)) * 100),
      color: CLASS_COLORS[c.cls] || '#C88A5A',
    }));

  const monthData = data.perMonth.slice(-6).map((m) => ({
    label: new Date(m.ym + '-01T00:00:00').toLocaleDateString('en-US', { month: 'short' }),
    approved: m.approved,
    rejected: m.rejected,
    other: m.n - m.approved - m.rejected,
  }));

  const mfgData = data.byManufacturer.slice(0, 6).map((m, i) => ({
    label: m.name.length > 12 ? m.name.slice(0, 11) + '…' : m.name,
    value: m.tests,
    color: SERIES[i % SERIES.length],
  }));

  const typeData = (data.byType || []).map((t, i) => ({
    label: t.name.length > 14 ? t.name.slice(0, 13) + '…' : t.name,
    value: t.tests,
    color: SERIES[i % SERIES.length],
  }));

  const workloadData = (data.engineerWorkload || []).map((w, i) => ({
    label: w.name.split(' ')[0].length > 10 ? w.name.split(' ')[0].slice(0, 9) + '…' : w.name.split(' ')[0],
    value: w.tests,
    color: SERIES[i % SERIES.length],
  }));

  const totalTests = data.perMonth.reduce((s, m) => s + m.n, 0);
  const totalApproved = data.passByClass.reduce((s, c) => s + c.approved, 0);
  const totalDecided = data.passByClass.reduce((s, c) => s + c.approved + c.rejected, 0);
  const totals = data.totals || {};

  return (
    <div className="fade-up space-y-5">
      <div
        className="relative overflow-hidden rounded-2xl p-6 shadow-lg"
        style={{ backgroundImage: 'linear-gradient(120deg, #C88A5A 0%, #8B5E3C 45%, #6E4A2F 100%)' }}
      >
        <div className="absolute -right-16 -top-20 h-56 w-56 rounded-full bg-softgold/20 blur-2xl" />
        <div className="relative z-10 flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-xs font-bold uppercase tracking-widest text-softgold">Laboratory analytics</p>
            <h1 className="mt-1 text-2xl font-extrabold tracking-tight text-cream lg:text-3xl">Quality at a glance</h1>
            <p className="mt-1.5 text-sm text-cream/85">
              {totalTests} sessions · {totalDecided > 0 ? Math.round((totalApproved / totalDecided) * 100) : '—'}% pass rate ·{' '}
              {totals.pending || 0} awaiting review · {totals.open || 0} in progress
            </p>
          </div>
          <BarChart3 className="h-12 w-12 text-softgold/80" />
        </div>
      </div>

      {totalTests === 0 ? (
        <div className="card">
          <EmptyState
            tone="violet"
            icon={BarChart3}
            title="No analytics yet"
            subtitle="Charts appear as soon as your team completes and submits test sessions."
            ctaLabel="Go to test sessions"
            ctaTo="/sessions"
          />
        </div>
      ) : (
        <>
          {/* Trend alerts */}
          {(data.trendAlerts || []).length > 0 && (
            <div className="card border-mutedgold bg-mutedgold/25 p-5">
              <h2 className="flex items-center gap-2 card-title">
                <AlertTriangle className="h-5 w-5 text-errormocha" /> ATTENTION — patterns needing review
              </h2>
              <p className="mt-1 text-xs font-medium text-forestsage">
                Statistical alerts only — they do not label an instrument defective. Inspect and review before deciding.
              </p>
              <div className="mt-3 space-y-2.5">
                {data.trendAlerts.map((a) => (
                  <div key={a.instrumentId} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-softgold bg-cream px-4 py-3">
                    <div>
                      <p className="text-sm font-extrabold text-errormocha">
                        {a.name} <span className="font-mono text-[11px] font-bold text-forestsage">{a.code}</span>
                      </p>
                      <p className="text-xs text-espresso">
                        Rejected in {a.rejections} of the last {a.recentTests} tests · reason: {a.reason}
                      </p>
                    </div>
                    <Link to={`/instruments/${a.instrumentId}`} className="btn-secondary btn-sm">
                      View Instrument History <ArrowRight className="h-3.5 w-3.5" />
                    </Link>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Totals strip */}
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-5">
            {[
              ['Total Tests', totals.totalTests || 0, '#C88A5A'],
              ['Approved', totals.approved || 0, '#A8B89F'],
              ['Rejected', totals.rejected || 0, '#6E4A2F'],
              ['Pending', totals.pending || 0, '#D6B98C'],
              ['In Progress', totals.open || 0, '#65745D'],
            ].map(([label, v, c]) => (
              <div key={label} className="card relative overflow-hidden p-4">
                <div className="absolute inset-x-0 top-0 h-1" style={{ backgroundColor: c }} />
                <p className="text-[11px] font-bold uppercase tracking-wider text-forestsage">{label}</p>
                <p className="mt-1 text-2xl font-extrabold tabular-nums text-mocha">{v}</p>
              </div>
            ))}
          </div>

          <div className="grid gap-5 lg:grid-cols-2">
            <div className="card p-6">
              <h2 className="flex items-center gap-2 card-title">
                <Layers className="h-4.5 w-4.5 text-caramel" /> Pass Rate by Accuracy Class
              </h2>
              <p className="mb-2 text-xs text-forestsage/80">approved / (approved + rejected), all time</p>
              {classData.length ? <BarChart data={classData} suffix="%" /> : <p className="py-10 text-center text-sm text-forestsage/70">No decided sessions yet.</p>}
            </div>

            <div className="card p-6">
              <h2 className="flex items-center gap-2 card-title">
                <TrendingUp className="h-4.5 w-4.5 text-caramel" /> Tests per Month
              </h2>
              <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                <p className="text-xs text-forestsage/80">session volume by outcome</p>
                <Legend items={[{ label: 'Approved', color: '#A8B89F' }, { label: 'Rejected', color: '#6E4A2F' }, { label: 'Other', color: '#D9B77A' }]} />
              </div>
              <StackedBars data={monthData} />
            </div>

            <div className="card p-6">
              <h2 className="flex items-center gap-2 card-title">
                <PackageSearch className="h-4.5 w-4.5 text-caramel" /> Tests by Instrument Type
              </h2>
              <p className="mb-2 text-xs text-forestsage/80">all sessions grouped by instrument type</p>
              {typeData.length ? <BarChart data={typeData} /> : <p className="py-10 text-center text-sm text-forestsage/70">No data yet.</p>}
            </div>

            <div className="card p-6">
              <h2 className="flex items-center gap-2 card-title">
                <Factory className="h-4.5 w-4.5 text-caramel" /> Top Manufacturers Tested
              </h2>
              <p className="mb-2 text-xs text-forestsage/80">total test sessions per manufacturer</p>
              {mfgData.length ? <BarChart data={mfgData} /> : <p className="py-10 text-center text-sm text-forestsage/70">No data yet.</p>}
            </div>

            <div className="card p-6">
              <h2 className="flex items-center gap-2 card-title">
                <Wrench className="h-4.5 w-4.5 text-caramel" /> Engineer Workload
              </h2>
              <p className="mb-2 text-xs text-forestsage/80">test sessions per engineer</p>
              {workloadData.length ? <BarChart data={workloadData} /> : <p className="py-10 text-center text-sm text-forestsage/70">No data yet.</p>}
            </div>

            <div className="card p-6">
              <h2 className="flex items-center gap-2 card-title">
                <FileWarning className="h-4.5 w-4.5 text-caramel" /> Failure Reasons (from rejections)
              </h2>
              <p className="mb-2 text-xs text-forestsage/80">most common approver-stated reasons</p>
              {(data.failureReasons || []).length ? (
                <div className="space-y-2">
                  {data.failureReasons.map((f, i) => (
                    <div key={f.reason} className="flex items-center gap-3">
                      <span className="w-6 text-right font-mono text-xs font-extrabold text-mocha">{f.count}×</span>
                      <div className="h-3 flex-1 overflow-hidden rounded-full bg-softgold/40">
                        <div
                          className="h-full rounded-full transition-all duration-300"
                          style={{ width: `${(f.count / data.failureReasons[0].count) * 100}%`, backgroundColor: SERIES[i % SERIES.length] }}
                        />
                      </div>
                      <span className="max-w-[45%] truncate text-xs font-semibold text-espresso" title={f.reason}>{f.reason}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="py-10 text-center text-sm text-forestsage/70">No rejections recorded — a good sign.</p>
              )}
            </div>

            <div className="card p-6 lg:col-span-2">
              <h2 className="flex items-center gap-2 card-title">
                <FileWarning className="h-4.5 w-4.5 text-caramel" /> Certificate Expiry Trend (next 6 months)
              </h2>
              <p className="mb-2 text-xs text-forestsage/80">how many certificates fall due each month — plan re-verifications ahead</p>
              {(data.expiryTrend || []).length ? (
                <BarChart
                  data={data.expiryTrend.map((e, i) => ({
                    label: new Date(e.ym + '-01T00:00:00').toLocaleDateString('en-US', { month: 'short' }),
                    value: e.n,
                    color: SERIES[i % SERIES.length],
                  }))}
                />
              ) : (
                <p className="py-10 text-center text-sm text-forestsage/70">No certificates expiring in the next 6 months.</p>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
