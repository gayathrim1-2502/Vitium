import { useEffect, useState } from 'react';
import { BookOpen, Pencil, X, Save, ChevronDown, ShieldAlert, Cog, FlaskConical, Info } from 'lucide-react';
import { api } from '../api.js';
import { useAuth } from '../auth/AuthContext.jsx';
import EmptyState from '../components/EmptyState.jsx';

// Representative model photo per instrument type (served from /instruments/*)
const TYPE_PHOTOS = {
  'Platform Scale': { src: '/instruments/mettler-toledo-pth300.png', model: 'Mettler Toledo PTH-300' },
  'Bench Scale': { src: '/instruments/ohaus-defender-5000.png', model: 'Ohaus Defender 5000' },
  'Jewellery Balance': { src: '/instruments/sartorius-entris-ii.png', model: 'Sartorius Entris II' },
  'Retail Scale': { src: '/instruments/essae-ds415.png', model: 'Essae DS-415' },
  'Truck Weighbridge': { src: '/instruments/avery-wc60t.png', model: 'Avery WC-60T' },
};

const SECTIONS = [
  ['description', 'Description', Info],
  ['purpose', 'Purpose', Info],
  ['how_it_works', 'How it works', Cog],
  ['test_methods', 'Common testing methods', FlaskConical],
  ['failure_modes', 'Common failure conditions', ShieldAlert],
  ['safety_notes', 'Safety notes', ShieldAlert],
];

export default function Knowledge() {
  const { user } = useAuth();
  const isAdmin = user.role === 'admin';
  const [types, setTypes] = useState(null);
  const [error, setError] = useState('');
  const [expanded, setExpanded] = useState(null);
  const [editing, setEditing] = useState(null); // { id, form }
  const [saving, setSaving] = useState(false);

  useEffect(() => { document.title = 'Instrument Info · VITIUM'; }, []);

  const load = () => api('/instrument-types').then((d) => setTypes(d.types)).catch((e) => setError(e.message));
  useEffect(() => { load(); }, []);

  function openEdit(t) {
    setEditing({
      id: t.id,
      form: {
        description: t.description || '', purpose: t.purpose || '', howItWorks: t.how_it_works || '',
        specs: t.specs || '', testMethods: t.test_methods || '', failureModes: t.failure_modes || '',
        safetyNotes: t.safety_notes || '',
      },
    });
  }

  async function handleSave() {
    setSaving(true);
    try {
      await api(`/instrument-types/${editing.id}`, { method: 'PUT', body: editing.form });
      setEditing(null);
      load();
      window.nawiToast?.('Instrument information updated', 'success');
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  const field = (key, label, rows = 3) => (
    <div>
      <label className="mb-1 block text-[11px] font-bold uppercase tracking-wide text-forestsage" htmlFor={`kn-${key}`}>{label}</label>
      <textarea
        id={`kn-${key}`}
        className="input"
        rows={rows}
        value={editing.form[key]}
        onChange={(e) => setEditing({ ...editing, form: { ...editing.form, [key]: e.target.value } })}
      />
    </div>
  );

  if (error) return <div className="card border-errormocha/30 bg-errormocha/10 p-6 text-sm font-semibold text-errormocha">{error}</div>;
  if (!types) return <div className="card h-72 animate-pulse bg-sagecream" />;

  return (
    <div className="fade-up space-y-5">
      <div
        className="relative overflow-hidden rounded-2xl p-6 shadow-lg"
        style={{ backgroundImage: 'linear-gradient(120deg, #C88A5A 0%, #8B5E3C 50%, #6E4A2F 100%)' }}
      >
        <div className="absolute -right-14 -top-16 h-48 w-48 rounded-full bg-softgold/20 blur-2xl" />
        <div className="relative z-10 flex items-center justify-between gap-4">
          <div>
            <p className="text-xs font-bold uppercase tracking-widest text-softgold">Reference library</p>
            <h1 className="mt-1 text-2xl font-extrabold tracking-tight text-cream">Instrument Information</h1>
            <p className="mt-1.5 max-w-xl text-sm text-cream/85">
              How each instrument type works, how it is tested, and what typically fails — maintained by administrators for the whole team.
            </p>
          </div>
          <BookOpen className="h-11 w-11 text-softgold/80" />
        </div>
      </div>

      {types.length === 0 && (
        <div className="card"><EmptyState tone="teal" icon={BookOpen} title="No instrument types defined" subtitle="Types appear here once instruments are registered." /></div>
      )}

      <div className="grid gap-5 lg:grid-cols-2">
        {types.map((t) => {
          const isOpen = expanded === t.id;
          const isEditing = editing?.id === t.id;
          const counts = t.modules?.length ?? 0;
          const photo = TYPE_PHOTOS[t.name];
          return (
            <div key={t.id} className="card card-flush overflow-hidden">
              <button
                onClick={() => setExpanded(isOpen ? null : t.id)}
                className="flex w-full items-center justify-between gap-3 px-5 py-4 text-left transition-colors hover:bg-cream"
              >
                <div className="flex min-w-0 items-center gap-3.5">
                  {/* Keep the text column aligned for types without a photo. */}
                  {photo ? (
                    <img
                      src={photo.src}
                      alt={`${t.name} — ${photo.model}`}
                      loading="lazy"
                      className="h-14 w-14 shrink-0 rounded-xl border border-softgold bg-cream object-contain p-1"
                    />
                  ) : (
                    <span
                      aria-hidden="true"
                      className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl border border-softgold/60 bg-cream text-forestsage/70"
                    >
                      <Cog className="h-6 w-6" />
                    </span>
                  )}
                  <div className="min-w-0">
                    <p className="text-base font-extrabold tracking-tight text-darkgreen">{t.name}</p>
                    {photo && <p className="truncate text-[11px] font-semibold text-caramel">e.g. {photo.model}</p>}
                    <p className="text-xs font-semibold text-forestsage">{counts} standard test step{counts !== 1 ? 's' : ''} · checklist configurable</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {isAdmin && !isEditing && (
                    <span
                      role="button"
                      tabIndex={0}
                      onClick={(e) => { e.stopPropagation(); openEdit(t); }}
                      onKeyDown={(e) => e.key === 'Enter' && openEdit(t)}
                      className="rounded-lg border border-softgold bg-cream p-2 text-mocha hover:border-caramel"
                      title="Edit information"
                    >
                      <Pencil className="h-4 w-4" />
                    </span>
                  )}
                  <ChevronDown className={`h-5 w-5 text-forestsage transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                </div>
              </button>

              {isOpen && (
                <div className="space-y-4 border-t border-softgold/60 px-5 py-4">
                  {photo && (
                    <div className="flex items-center justify-center overflow-hidden rounded-xl border border-softgold bg-cream p-4">
                      <img
                        src={photo.src}
                        alt={`${t.name} — ${photo.model}`}
                        loading="lazy"
                        className="max-h-56 w-full rounded-lg object-contain"
                      />
                    </div>
                  )}
                  {isEditing ? (
                    <>
                      {field('description', 'Description')}
                      {field('purpose', 'Purpose')}
                      {field('howItWorks', 'How it works')}
                      <div>
                        <label className="mb-1 block text-[11px] font-bold uppercase tracking-wide text-forestsage" htmlFor="kn-specs">Main specifications (one per line)</label>
                        <textarea id="kn-specs" className="input" rows={4} value={editing.form.specs} onChange={(e) => setEditing({ ...editing, form: { ...editing.form, specs: e.target.value } })} />
                      </div>
                      {field('testMethods', 'Common testing methods')}
                      {field('failureModes', 'Common failure conditions')}
                      {field('safetyNotes', 'Safety notes')}
                      <div>
                        <label className="mb-1 block text-[11px] font-bold uppercase tracking-wide text-forestsage">Test checklist (ordered module keys)</label>
                        <p className="text-[11px] text-forestsage">Current: {(t.modules || []).join(' → ') || 'default 9 modules'}</p>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={handleSave} disabled={saving} className="btn-primary btn-sm flex-1">{saving ? <span className="btn-spinner" /> : <Save className="h-4 w-4" />} {saving ? 'Saving…' : 'Save information'}</button>
                        <button onClick={() => setEditing(null)} className="btn-secondary btn-sm"><X className="h-4 w-4" /> Cancel</button>
                      </div>
                    </>
                  ) : (
                    <>
                      {SECTIONS.map(([key, label]) => {
                        const val = t[key === 'how_it_works' ? 'how_it_works' : key] || t[key];
                        const text = key === 'how_it_works' ? t.how_it_works : t[key];
                        if (!text) return null;
                        return (
                          <div key={key}>
                            <p className="text-[11px] font-bold uppercase tracking-wide text-forestsage">{label}</p>
                            <p className="mt-0.5 whitespace-pre-line text-sm leading-relaxed text-espresso">{text}</p>
                          </div>
                        );
                      })}
                      {t.specs && (
                        <div>
                          <p className="text-[11px] font-bold uppercase tracking-wide text-forestsage">Main specifications</p>
                          <ul className="mt-1 list-inside list-disc text-sm text-espresso">
                            {String(t.specs).split('\n').filter(Boolean).map((s, i) => <li key={i}>{s}</li>)}
                          </ul>
                        </div>
                      )}
                      <div className="rounded-xl border border-softgold bg-sagecream px-4 py-3">
                        <p className="text-[11px] font-bold uppercase tracking-wide text-forestsage">Standard test checklist</p>
                        <p className="mt-1 text-xs font-semibold text-espresso">{(t.modules || []).join(' → ') || 'Default 9-module OIML R-76 flow'}</p>
                      </div>
                      {!t.description && !t.purpose && !t.specs && (
                        <p className="text-sm text-forestsage">
                          No reference information yet. {isAdmin ? 'Use the pencil icon to add a description, specifications and testing guidance.' : 'An administrator can add it.'}
                        </p>
                      )}
                    </>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
