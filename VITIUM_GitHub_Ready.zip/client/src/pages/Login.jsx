import { useEffect, useRef, useState } from 'react';
import { useNavigate, Navigate } from 'react-router-dom';
import {
  LogIn, ShieldCheck, FileCheck2, UserCog, Eye, EyeOff, Lock, Mail, AlertCircle,
  UserPlus, User, ArrowLeft, KeyRound, RefreshCw, CheckCircle2,
} from 'lucide-react';
import logoUrl from '../assets/vitium-logo.png';
import { useAuth } from '../auth/AuthContext.jsx';
import { api } from '../api.js';
import { ROLE_HOME } from '../routes/RequireAuth.jsx';

export default function Login() {
  const { user, login, finishAuth } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState('signin'); // 'signin' | 'signup' | 'otp'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);

  // Signup state
  const [suName, setSuName] = useState('');
  const [suEmail, setSuEmail] = useState('');
  const [suRole, setSuRole] = useState('engineer');
  const [suPw, setSuPw] = useState('');
  const [suPw2, setSuPw2] = useState('');

  // OTP state
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [otpEmail, setOtpEmail] = useState('');
  const [demoCode, setDemoCode] = useState('');
  const [cooldown, setCooldown] = useState(0);
  const otpRefs = useRef([]);

  useEffect(() => {
    document.title = 'Sign in · VITIUM';
  }, []);

  // OTP resend cooldown ticker
  useEffect(() => {
    if (cooldown <= 0) return undefined;
    const t = setInterval(() => setCooldown((s) => (s <= 1 ? 0 : s - 1)), 1000);
    return () => clearInterval(t);
  }, [cooldown > 0]); // eslint-disable-line react-hooks/exhaustive-deps

  if (user) return <Navigate to={ROLE_HOME[user.role]} replace />;

  async function handleSignIn(e) {
    e.preventDefault();
    setError('');
    setNotice('');
    setBusy(true);
    try {
      const u = await login(email.trim(), password);
      navigate(ROLE_HOME[u.role] || '/dashboard', { replace: true });
    } catch (err) {
      if (err.status === 403 && err.data?.code === 'EMAIL_NOT_VERIFIED') {
        setOtpEmail(err.data.email || email.trim());
        setDemoCode(err.data.demoCode || '');
        setCooldown(err.data.cooldownSeconds || 45);
        setMode('otp');
      } else {
        setError(err.message || 'Login failed');
      }
    } finally {
      setBusy(false);
    }
  }

  async function handleSignUp(e) {
    e.preventDefault();
    setError('');
    setNotice('');
    if (suPw !== suPw2) {
      setError('Passwords do not match');
      return;
    }
    setBusy(true);
    try {
      const data = await api('/auth/register', {
        method: 'POST',
        body: { fullName: suName.trim(), email: suEmail.trim(), password: suPw, role: suRole },
      });
      setOtpEmail(data.email);
      setDemoCode(data.demoCode || '');
      setCooldown(data.cooldownSeconds || 45);
      setNotice(data.message);
      setMode('otp');
    } catch (err) {
      setError(err.message || 'Could not create the account');
    } finally {
      setBusy(false);
    }
  }

  async function handleVerify(e) {
    if (e) e.preventDefault();
    setError('');
    setBusy(true);
    try {
      const data = await api('/auth/verify-otp', {
        method: 'POST',
        body: { email: otpEmail, code: otp.join('') },
      });
      finishAuth(data.token, data.user);
      navigate(ROLE_HOME[data.user.role] || '/dashboard', { replace: true });
    } catch (err) {
      setError(err.message || 'Verification failed');
      setOtp(['', '', '', '', '', '']);
      otpRefs.current[0]?.focus();
    } finally {
      setBusy(false);
    }
  }

  async function handleResend() {
    setError('');
    setNotice('');
    setBusy(true);
    try {
      const data = await api('/auth/resend-otp', { method: 'POST', body: { email: otpEmail } });
      setDemoCode(data.demoCode || '');
      setCooldown(data.cooldownSeconds || 45);
      setNotice(data.message);
    } catch (err) {
      setError(err.message || 'Could not resend the code');
      if (err.data?.retryAfter) setCooldown(err.data.retryAfter);
    } finally {
      setBusy(false);
    }
  }

  function onOtpChange(i, v) {
    const digit = v.replace(/\D/g, '').slice(-1);
    setOtp((prev) => {
      const next = [...prev];
      next[i] = digit;
      return next;
    });
    if (digit && i < 5) otpRefs.current[i + 1]?.focus();
  }

  function onOtpKeyDown(i, e) {
    if (e.key === 'Backspace' && !otp[i] && i > 0) otpRefs.current[i - 1]?.focus();
  }

  function onOtpPaste(e) {
    const text = (e.clipboardData?.getData('text') || '').replace(/\D/g, '').slice(0, 6);
    if (!text) return;
    e.preventDefault();
    setOtp((prev) => {
      const next = [...prev];
      text.split('').forEach((d, idx) => { if (idx < 6) next[idx] = d; });
      return next;
    });
    otpRefs.current[Math.min(text.length, 5)]?.focus();
    if (text.length === 6) setTimeout(() => handleVerify(), 50);
  }

  function goBackToSignIn() {
    setMode('signin');
    setError('');
    setNotice('');
    setOtp(['', '', '', '', '', '']);
    setDemoCode('');
  }

  const demoCodeIsLive = Boolean(demoCode);
  const otpComplete = otp.every((d) => d !== '');

  return (
    <div className="flex min-h-screen bg-cream">
      {/* Left branding panel */}
      <div
        className="relative hidden w-[46%] flex-col justify-between overflow-hidden p-12 lg:flex"
        style={{ backgroundImage: 'linear-gradient(150deg, #C88A5A 0%, #8B5E3C 55%, #6E4A2F 100%)' }}
      >
        <div className="absolute -right-24 -top-24 h-96 w-96 rounded-full bg-softgold/30 blur-3xl" />
        <div className="absolute -bottom-32 -left-16 h-96 w-96 rounded-full bg-sage/30 blur-3xl" />
        <div className="absolute right-16 top-1/3 h-40 w-40 rounded-full border-[22px] border-cream/10" />

        <div className="relative z-10 flex items-center gap-3">
          <img
            src={logoUrl}
            alt="VITIUM logo"
            className="h-12 w-12 shrink-0 rounded-2xl bg-cream/20 object-contain p-0.5 backdrop-blur"
          />
          <div>
            <p className="text-lg font-extrabold tracking-tight text-cream">VITIUM</p>
            <p className="text-xs font-semibold text-softgold">Legal Metrology Verification & Certification</p>
          </div>
        </div>

        <div className="relative z-10">
          <h1 className="text-4xl font-extrabold leading-tight text-cream">
            {mode === 'signup' ? (
              <>
                Join the lab.
                <br />
                <span className="text-softgold">Get verified in seconds.</span>
              </>
            ) : (
              <>
                Digital test reports,
                <br />
                <span className="text-softgold">certified with confidence.</span>
              </>
            )}
          </h1>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-cream/85">
            {mode === 'signup'
              ? 'Create your account, confirm your email with a one-time code, and start issuing digitally signed OIML R-76 compliance certificates.'
              : 'Plan instrument verifications, capture results and issue digitally signed certificates of verification — from one professional workspace.'}
          </p>
          <div className="mt-8 flex items-center gap-6">
            {[
              { icon: ShieldCheck, label: 'Digitally signed' },
              { icon: FileCheck2, label: 'R-76 workflows' },
              { icon: UserCog, label: 'Role-based access' },
            ].map(({ icon: Icon, label }) => (
              <div key={label} className="flex items-center gap-2">
                <Icon className="h-4.5 w-4.5 text-softgold" />
                <span className="text-xs font-semibold text-cream/90">{label}</span>
              </div>
            ))}
          </div>
        </div>

        <p className="relative z-10 text-xs font-medium text-cream/60">
          Non-Automatic Weighing Instruments · Legal Metrology
        </p>
      </div>

      {/* Right form panel */}
      <div className="flex flex-1 items-center justify-center px-6 py-10">
        <div className="w-full max-w-md fade-up">
          {/* Mobile logo */}
          <div className="mb-8 flex items-center gap-3 lg:hidden">
            <img
              src={logoUrl}
              alt="VITIUM logo"
              className="h-11 w-11 shrink-0 rounded-2xl bg-cream object-contain p-0.5 shadow-md"
            />
            <div>
              <p className="text-lg font-extrabold text-darkgreen">VITIUM</p>
              <p className="text-xs font-semibold text-forestsage">Legal Metrology Verification & Certification</p>
            </div>
          </div>

          {mode === 'signin' && (
            <>
              <h2 className="text-3xl font-extrabold tracking-tight text-darkgreen">Welcome back</h2>
              <p className="mt-1.5 text-sm text-forestsage">Sign in to your testing workspace</p>

              {error && (
                <div className="mt-5 flex items-start gap-2.5 alert-error" role="alert">
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                  {error}
                </div>
              )}

              <form onSubmit={handleSignIn} className="mt-6 space-y-4">
                <div>
                  <label className="field-label" htmlFor="li-email">
                    Email
                  </label>
                  <div className="relative">
                    <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-forestsage/70" />
                    <input
                      id="li-email"
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@company.com"
                      className="input pl-10"
                      autoComplete="email"
                    />
                  </div>
                </div>
                <div>
                  <label className="field-label" htmlFor="li-password">
                    Password
                  </label>
                  <div className="relative">
                    <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-forestsage/70" />
                    <input
                      id="li-password"
                      type={showPw ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="input pl-10 pr-11"
                      autoComplete="current-password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPw((s) => !s)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 rounded-lg p-1 text-forestsage/70 transition-colors hover:text-caramel"
                      aria-label={showPw ? 'Hide password' : 'Show password'}
                    >
                      {showPw ? <EyeOff className="h-4.5 w-4.5" /> : <Eye className="h-4.5 w-4.5" />}
                    </button>
                  </div>
                </div>

                <button type="submit" disabled={busy} className="btn-primary w-full">
                  {busy ? (
                    <>
                      <span className="btn-spinner" />
                      Signing in…
                    </>
                  ) : (
                    <>
                      <LogIn className="h-4.5 w-4.5" />
                      Sign in
                    </>
                  )}
                </button>
              </form>

              <p className="mt-4 text-center text-sm text-forestsage">
                New here?{' '}
                <button
                  type="button"
                  onClick={() => { setMode('signup'); setError(''); setNotice(''); }}
                  className="py-1 font-bold text-caramel underline decoration-softgold decoration-2 underline-offset-4 transition-colors hover:text-mocha"
                >
                  Create an account
                </button>
              </p>

            </>
          )}

          {mode === 'signup' && (
            <>
              <h2 className="text-3xl font-extrabold tracking-tight text-darkgreen">Create your account</h2>
              <p className="mt-1.5 text-sm text-forestsage">We'll email you a one-time code to verify it's you</p>

              {error && (
                <div className="mt-5 flex items-start gap-2.5 alert-error" role="alert">
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                  {error}
                </div>
              )}

              <form onSubmit={handleSignUp} className="mt-6 space-y-4">
                <div>
                  <label className="field-label" htmlFor="su-name">Full name</label>
                  <div className="relative">
                    <User className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-forestsage/70" />
                    <input
                      id="su-name"
                      type="text"
                      required
                      value={suName}
                      onChange={(e) => setSuName(e.target.value)}
                      placeholder="e.g. Aditi Sharma"
                      className="input pl-10"
                      autoComplete="name"
                    />
                  </div>
                </div>
                <div>
                  <label className="field-label" htmlFor="su-email">Email</label>
                  <div className="relative">
                    <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-forestsage/70" />
                    <input
                      id="su-email"
                      type="email"
                      required
                      value={suEmail}
                      onChange={(e) => setSuEmail(e.target.value)}
                      placeholder="you@company.com"
                      className="input pl-10"
                      autoComplete="email"
                    />
                  </div>
                </div>
                <div>
                  <label className="field-label">Role</label>
                  <div className="grid grid-cols-2 gap-3" role="group" aria-label="Role">
                    {[
                      { value: 'engineer', label: 'Test Engineer', desc: 'Run test sessions', icon: FileCheck2 },
                      { value: 'approver', label: 'Approver', desc: 'Review & sign reports', icon: ShieldCheck },
                    ].map((r) => (
                      <button
                        key={r.value}
                        type="button"
                        onClick={() => setSuRole(r.value)}
                        className={`rounded-xl border p-3 text-left transition-all duration-200 ${
                          suRole === r.value
                            ? 'border-caramel bg-caramel/10 shadow-sm ring-1 ring-caramel'
                            : 'border-softgold bg-sagecream hover:border-caramel/60'
                        }`}
                      >
                        <r.icon className={`h-4.5 w-4.5 ${suRole === r.value ? 'text-caramel' : 'text-forestsage'}`} />
                        <p className={`mt-1.5 text-sm font-bold ${suRole === r.value ? 'text-espresso' : 'text-espresso/80'}`}>
                          {r.label}
                        </p>
                        <p className="text-[11px] leading-snug text-forestsage">{r.desc}</p>
                      </button>
                    ))}
                  </div>
                  <p className="field-hint mt-1.5">
                    Admin accounts are provisioned by an existing administrator in Users.
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="field-label" htmlFor="su-password">Password</label>
                    <div className="relative">
                      <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-forestsage/70" />
                      <input
                        id="su-password"
                        type={showPw ? 'text' : 'password'}
                        required
                        minLength={8}
                        value={suPw}
                        onChange={(e) => setSuPw(e.target.value)}
                        placeholder="Min. 8 characters"
                        className="input pl-10 pr-3"
                        autoComplete="new-password"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="field-label" htmlFor="su-confirm">Confirm</label>
                    <div className="relative">
                      <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-forestsage/70" />
                      <input
                        id="su-confirm"
                        type={showPw ? 'text' : 'password'}
                        required
                        minLength={8}
                        value={suPw2}
                        onChange={(e) => setSuPw2(e.target.value)}
                        placeholder="Repeat password"
                        className="input pl-10"
                        autoComplete="new-password"
                      />
                    </div>
                  </div>
                </div>
                <label className="flex cursor-pointer items-center gap-2 text-xs text-forestsage">
                  <input
                    type="checkbox"
                    checked={showPw}
                    onChange={(e) => setShowPw(e.target.checked)}
                    className="h-3.5 w-3.5 accent-caramel"
                  />
                  Show passwords
                </label>

                <button type="submit" disabled={busy} className="btn-primary w-full">
                  {busy ? (
                    <>
                      <span className="btn-spinner" />
                      Creating account…
                    </>
                  ) : (
                    <>
                      <UserPlus className="h-4.5 w-4.5" />
                      Create account & send code
                    </>
                  )}
                </button>
              </form>

              <p className="mt-4 text-center text-sm text-forestsage">
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => { setMode('signin'); setError(''); setNotice(''); }}
                  className="py-1 font-bold text-caramel underline decoration-softgold decoration-2 underline-offset-4 transition-colors hover:text-mocha"
                >
                  Sign in
                </button>
              </p>
            </>
          )}

          {mode === 'otp' && (
            <>
              <button
                type="button"
                onClick={goBackToSignIn}
                className="mb-5 inline-flex items-center gap-1.5 text-sm font-bold text-forestsage transition-colors hover:text-caramel"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to sign in
              </button>
              <h2 className="text-3xl font-extrabold tracking-tight text-darkgreen">Verify your email</h2>
              <p className="mt-1.5 text-sm text-forestsage">
                We sent a 6-digit code to <span className="font-bold text-espresso">{otpEmail}</span>.
                It expires in 10 minutes.
              </p>

              {notice && (
                <div className="mt-5 flex items-start gap-2.5 rounded-xl border border-sage bg-sage/25 px-4 py-3 text-sm font-medium text-darkgreen">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
                  {notice}
                </div>
              )}
              {error && (
                <div className="mt-5 flex items-start gap-2.5 alert-error" role="alert">
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                  {error}
                </div>
              )}

              {demoCodeIsLive && (
                <div className="mt-5 rounded-xl border border-softgold bg-sagecream px-4 py-3">
                  <p className="text-[11px] font-bold uppercase tracking-wide text-forestsage">
                    Demo mode — SMTP not configured on this server
                  </p>
                  <p className="mt-1 text-sm text-espresso">
                    Your verification code is{' '}
                    <span className="font-mono text-base font-extrabold tracking-widest text-mocha">{demoCode}</span>
                    {' '}(also printed in the server console). Add SMTP_HOST, SMTP_USER and SMTP_PASS
                    environment variables to send real emails.
                  </p>
                </div>
              )}

              <form onSubmit={handleVerify} className="mt-6">
                <label className="field-label" id="otp-label">
                  Verification code
                </label>
                <div className="flex justify-between gap-2" role="group" aria-labelledby="otp-label" onPaste={onOtpPaste}>
                  {otp.map((d, i) => (
                    <input
                      key={i}
                      ref={(el) => { otpRefs.current[i] = el; }}
                      type="text"
                      inputMode="numeric"
                      autoComplete="one-time-code"
                      maxLength={6}
                      value={d}
                      onChange={(e) => onOtpChange(i, e.target.value)}
                      onKeyDown={(e) => onOtpKeyDown(i, e)}
                      onFocus={(e) => e.target.select()}
                      className="input h-14 w-full px-0 text-center text-xl font-extrabold tracking-widest"
                      aria-label={`Digit ${i + 1}`}
                    />
                  ))}
                </div>

                <button
                  type="submit"
                  disabled={busy || !otpComplete}
                  className="btn-primary mt-5 w-full"
                >
                  {busy ? (
                    <>
                      <span className="btn-spinner" />
                      Verifying…
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="h-4.5 w-4.5" />
                      Verify & continue
                    </>
                  )}
                </button>
              </form>

              <div className="mt-4 flex items-center justify-between text-sm">
                <span className="text-forestsage">Didn't get the code?</span>
                <button
                  type="button"
                  onClick={handleResend}
                  disabled={cooldown > 0 || busy}
                  className="inline-flex items-center gap-1.5 font-bold text-caramel transition-colors hover:text-mocha disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <RefreshCw className={`h-4 w-4 ${cooldown > 0 ? 'animate-spin [animation-duration:2.5s]' : ''}`} />
                  {cooldown > 0 ? `Resend in ${cooldown}s` : 'Resend code'}
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
