import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  ArrowLeft, ArrowRight, Check, CheckCircle2, Circle, Save, Send, Loader2,
  X, Thermometer, Droplets, FlaskConical, FileText, Lock, MapPin, Crosshair, Upload, ImageIcon, Trash2, Eye,
} from 'lucide-react';
import { api } from '../api.js';
import { useAuth } from '../auth/AuthContext.jsx';
import { TEST_MODULES, moduleMeta } from '../tests/modules.jsx';
import ModuleForms from '../tests/ModuleForms.jsx';
import { evaluateModule } from '../tests/evaluate.js';
import PassBadge from '../tests/PassBadge.jsx';
import ApprovalPanel from './ApprovalPanel.jsx';
import Confetti from '../components/Confetti.jsx';
import { FileBarChart2, AlertTriangle, RotateCcw } from 'lucide-react';

const DOC_TYPES = [
  ['test_setup_photo', 'Test setup photo'], ['test_result_photo', 'Test result photo'],
  ['nameplate_photo', 'Nameplate photo'], ['seal_photo', 'Seal photo'],
  ['calibration_document', 'Calibration document'], ['previous_certificate', 'Previous certificate'],
  ['supporting_document', 'Supporting document'], ['other', 'Other'],
];

function LocationEvidenceCard({ sessionId, session, files, editable, onRefresh }) {
  const [loc, setLoc] = useState({
    latitude: session.latitude, longitude: session.longitude,
    accuracy: session.location_accuracy, capturedAt: session.location_captured_at,
    locationText: session.location_text || '',
  });
  const [gpsState, setGpsState] = useState('idle'); // idle | locating | error
  const [gpsError, setGpsError] = useState('');
  const [manualText, setManualText] = useState(session.location_text || '');
  const [docType, setDocType] = useState('test_setup_photo');
  const [uploading, setUploading] = useState(false);
  const [fileError, setFileError] = useState('');

  const hasGps = loc.latitude != null && loc.longitude != null;

  function captureGps() {
    if (!navigator.geolocation) {
      setGpsState('error');
      setGpsError('Geolocation is not supported by this browser. Please enter the location manually.');
      return;
    }
    setGpsState('locating');
    setGpsError('');
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const next = {
          latitude: Number(pos.coords.latitude.toFixed(6)),
          longitude: Number(pos.coords.longitude.toFixed(6)),
          accuracy: pos.coords.accuracy != null ? Math.round(pos.coords.accuracy) : null,
          capturedAt: new Date().toISOString().slice(0, 19).replace('T', ' '),
          locationText: loc.locationText,
        };
        setLoc(next);
        setGpsState('idle');
        try {
          await api(`/sessions/${sessionId}/location`, {
            method: 'PUT',
            body: { latitude: next.latitude, longitude: next.longitude, accuracy: next.accuracy, locationText: next.locationText },
          });
          window.nawiToast?.('Inspection location captured', 'success');
        } catch (e) { setGpsError(e.message); }
      },
      (err) => {
        setGpsState('error');
        setGpsError('Unable to capture GPS location. Please enable location permission or enter the location manually.');
      },
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 }
    );
  }

  async function saveManual() {
    try {
      const d = await api(`/sessions/${sessionId}/location`, { method: 'PUT', body: { manual: true, locationText: manualText } });
      setLoc((l) => ({ ...l, locationText: d.session.location_text }));
      window.nawiToast?.('Location saved', 'success');
    } catch (e) { setGpsError(e.message); }
  }

  async function handleUpload(e) {
    const list = Array.from(e.target.files || []);
    if (!list.length) return;
    setUploading(true);
    setFileError('');
    for (const f of list) {
      try {
        await api.raw(`/sessions/${sessionId}/files`, f, { docType });
      } catch (err) {
        setFileError(`${f.name}: ${err.message}`);
      }
    }
    setUploading(false);
    e.target.value = '';
    onRefresh();
    window.nawiToast?.(list.length === 1 ? 'File uploaded' : `${list.length} files uploaded`, 'success');
  }

  async function handleDelete(fileId) {
    if (!window.confirm('Delete this file?')) return;
    try {
      await api(`/files/${fileId}`, { method: 'DELETE' });
      onRefresh();
    } catch (e) { setFileError(e.message); }
  }

  const mapSrc = hasGps
    ? `https://www.openstreetmap.org/export/embed.html?bbox=${loc.longitude - 0.004}%2C${loc.latitude - 0.0025}%2C${loc.longitude + 0.004}%2C${loc.latitude + 0.0025}&layer=mapnik&marker=${loc.latitude}%2C${loc.longitude}`
    : null;

  return (
    <div className="card p-5">
      <div className="grid gap-5 lg:grid-cols-2">
        {/* Location */}
        <div>
          <h3 className="flex items-center gap-2 card-title"><MapPin className="h-4.5 w-4.5 text-caramel" /> Inspection Location</h3>
          {gpsError && <p className="mt-2 alert-error" role="alert">{gpsError}</p>}
          {hasGps ? (
            <div className="mt-3 overflow-hidden rounded-xl border border-softgold">
              <iframe title="Inspection location map" src={mapSrc} className="h-40 w-full" loading="lazy" />
            </div>
          ) : (
            <p className="mt-2 text-xs text-forestsage">Capture the GPS position where this inspection is performed — only on your explicit action, never tracked in the background.</p>
          )}
          <div className="mt-3 flex flex-wrap items-center gap-2">
            {editable && (
              <button onClick={captureGps} disabled={gpsState === 'locating'} className="btn-primary btn-sm">
                <Crosshair className={`h-4 w-4 ${gpsState === 'locating' ? 'animate-pulse' : ''}`} />
                {gpsState === 'locating' ? 'Locating…' : hasGps ? 'Re-capture location' : 'Capture Current Location'}
              </button>
            )}
            {hasGps && (
              <span className="rounded-full bg-softgold/30 px-3 py-1.5 font-mono text-[11px] font-bold text-espresso">
                {loc.latitude}, {loc.longitude}{loc.accuracy != null ? ` · ±${loc.accuracy}m` : ''}
              </span>
            )}
            {loc.capturedAt && <span className="text-[10px] text-forestsage">at {loc.capturedAt}</span>}
          </div>
          <div className="mt-3 flex gap-2">
            <input className="input btn-sm" placeholder="Or enter location manually (site / address)" value={manualText} onChange={(e) => setManualText(e.target.value)} disabled={!editable} />
            {editable && <button onClick={saveManual} disabled={!manualText.trim()} className="btn-secondary btn-sm">Save</button>}
          </div>
          {loc.locationText && <p className="mt-1.5 text-[11px] font-semibold text-forestsage">Saved: {loc.locationText}</p>}
        </div>

        {/* Evidence files */}
        <div>
          <h3 className="flex items-center gap-2 card-title"><ImageIcon className="h-4.5 w-4.5 text-caramel" /> Photos & Documents ({files.length})</h3>
          {fileError && <p className="mt-2 alert-error" role="alert">{fileError}</p>}
          {editable && (
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <select className="input !w-auto btn-sm" value={docType} onChange={(e) => setDocType(e.target.value)}>
                {DOC_TYPES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
              </select>
              <label className="btn-secondary cursor-pointer btn-sm">
                {uploading ? <span className="btn-spinner" /> : <Upload className="h-4 w-4" />} {uploading ? 'Uploading…' : 'Upload files'}
                <input type="file" multiple accept="image/*,application/pdf,.csv,.txt,.doc,.docx,.xls,.xlsx" className="hidden" onChange={handleUpload} disabled={uploading} />
              </label>
            </div>
          )}
          {files.length === 0 ? (
            <p className="mt-3 text-xs text-forestsage">No files yet — add nameplate/seal photos, test-setup pictures or supporting documents.</p>
          ) : (
            <div className="mt-3 grid grid-cols-2 gap-2.5 sm:grid-cols-3">
              {files.map((f) => (
                <div key={f.id} className="group relative overflow-hidden rounded-xl border border-softgold/50 bg-sagecream">
                  {f.kind === 'photo' ? (
                    <img src={`/api/files/${f.id}`} alt={f.file_name} className="h-20 w-full object-cover" loading="lazy" />
                  ) : (
                    <div className="flex h-20 items-center justify-center"><FileText className="h-7 w-7 text-mocha" /></div>
                  )}
                  <div className="flex items-center justify-between gap-1 px-2 py-1.5">
                    <span className="truncate text-[10px] font-bold text-espresso" title={f.file_name}>{f.file_name}</span>
                    <div className="flex shrink-0 gap-1">
                      <a href={`/api/files/${f.id}`} target="_blank" rel="noreferrer" className="rounded p-0.5 text-caramel hover:bg-cream" title="Preview"><Eye className="h-3 w-3" /></a>
                      {editable && (
                        <button onClick={() => handleDelete(f.id)} className="link-danger rounded p-0.5 hover:bg-cream" title="Delete"><Trash2 className="h-3 w-3" /></button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Stepper({ current, completedMap, onJump, editable }) {
  const pct = (Object.values(completedMap).filter(Boolean).length / TEST_MODULES.length) * 100;
  return (
    <div className="card card-flush overflow-hidden">
      <div className="h-2 w-full bg-softgold/30">
        <div
          className="h-full bg-gradient-to-r from-caramel via-softgold to-sage transition-all duration-300"
          style={{ width: `${pct}%` }}
        />
      </div>
      <div className="flex overflow-x-auto px-2 py-3">
        {TEST_MODULES.map((m, idx) => {
          const done = !!completedMap[m.key];
          const active = idx === current;
          const clickable = editable;
          return (
            <button
              key={m.key}
              type="button"
              disabled={!clickable}
              onClick={() => clickable && onJump(idx)}
              className={`group relative flex min-w-24 flex-1 flex-col items-center gap-1.5 px-1 py-1.5 rounded-xl transition-all ${
                active ? 'bg-cream shadow-inner' : ''
              } ${clickable ? 'cursor-pointer hover:bg-cream' : 'cursor-default'}`}
            >
              <span
                className="flex h-9 w-9 items-center justify-center rounded-full border-2 text-cream transition-all duration-200"
                style={{
                  background: done ? m.color : active ? m.color : '#E9E4D4',
                  borderColor: done || active ? m.color : '#D9B77A',
                  transform: active ? 'scale(1.12)' : 'none',
                  boxShadow: active ? `0 4px 12px ${m.color}55` : done ? `0 2px 6px ${m.color}33` : 'none',
                  color: done || active ? '#F5E6D3' : '#65745D',
                }}
              >
                {done ? <Check className="h-4.5 w-4.5" /> : <m.icon className="h-4.5 w-4.5" />}
              </span>
              <span className={`text-[10px] font-bold leading-tight ${active ? 'text-darkgreen' : done ? 'text-espresso' : 'text-forestsage'}`}>
                {m.short}
              </span>
              {idx < TEST_MODULES.length - 1 && (
                <span
                  className="absolute right-0 top-6 hidden h-0.5 w-3 lg:block"
                  style={{ background: done ? m.color : '#D9B77A' }}
                />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default function TestSessionWizard() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [payload, setPayload] = useState(null);
  const [error, setError] = useState('');
  const [current, setCurrent] = useState(0);
  const [data, setData] = useState({});
  const [completedMap, setCompletedMap] = useState({});
  const [saveState, setSaveState] = useState('idle'); // idle | saving | saved | error
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');

  useEffect(() => { document.title = 'Test Wizard · VITIUM'; }, []);

  const load = useCallback(() => {
    api(`/sessions/${id}`)
      .then((d) => {
        setPayload(d);
        const tests = d.tests || {};
        const cm = {};
        for (const m of TEST_MODULES) cm[m.key] = !!tests[m.key]?.completed;
        setCompletedMap(cm);
        setData(tests[TEST_MODULES[0].key]?.data || {});
      })
      .catch((e) => setError(e.message));
  }, [id]);

  useEffect(() => { load(); }, [load]);

  if (error) {
    return (
      <div className="space-y-4">
        <div className="card border-errormocha/30 bg-errormocha/10 p-6 text-sm font-semibold text-errormocha">{error}</div>
        <Link to="/sessions" className="btn-secondary">← Back to sessions</Link>
      </div>
    );
  }
  if (!payload) {
    return <div className="card h-72 animate-pulse bg-sagecream" />;
  }

  const { session, instrument, loadPoints, evaluation, approval } = payload;
  // Only the owning engineer (or an admin) may edit a session — mirrors the
  // server's ownership check so the UI never offers an action that would 403.
  const isMine = user.role === 'admin' || session.engineer_id === user.id;
  const editable = ['draft', 'in_progress'].includes(session.status) && isMine;
  const module = TEST_MODULES[current];
  const liveEval = evaluateModule(module.key, data, instrument);
  const serverModuleEval = evaluation?.modules?.[module.key];
  const moduleVerdict = liveEval.verdict ?? (completedMap[module.key] ? serverModuleEval?.verdict ?? null : null);

  function switchStep(idx) {
    setCurrent(idx);
    setData(payload.tests?.[TEST_MODULES[idx].key]?.data || {});
  }

  async function persist(key, dataObj, completed) {
    setSaveState('saving');
    try {
      await api(`/sessions/${id}/tests/${key}`, { method: 'PUT', body: { data: dataObj, completed } });
      setCompletedMap((m) => ({ ...m, [key]: completed }));
      setPayload((p) => ({ ...p, tests: { ...p.tests, [key]: { completed, data: dataObj } }, session: { ...p.session, status: p.session.status === 'draft' ? 'in_progress' : p.session.status } }));
      setSaveState('saved');
      window.nawiToast?.(completed ? `${moduleMeta(key).label} marked complete` : 'Draft saved — resume anytime', 'success');
      setTimeout(() => setSaveState('idle'), 1800);
    } catch (e) {
      setSaveState('error');
      setSubmitError(e.message);
    }
  }

  async function handleSaveAndExit() {
    await persist(module.key, data, completedMap[module.key] || false);
    navigate('/sessions');
  }

  async function handleMarkComplete() {
    await persist(module.key, data, true);
  }

  async function handleSubmit() {
    setSubmitting(true);
    setSubmitError('');
    try {
      // persist current module first
      await persist(module.key, data, completedMap[module.key] || false);
      await api(`/sessions/${id}/status`, { method: 'PUT', body: { status: 'submitted' } });
      navigate('/sessions?status=submitted');
    } catch (e) {
      setSubmitError(e.message);
    } finally {
      setSubmitting(false);
    }
  }

  const completedCount = Object.values(completedMap).filter(Boolean).length;
  const allDone = completedCount === TEST_MODULES.length;
  const approvedNow = session.status === 'approved';

  return (
    <div className="fade-up space-y-5">
      {approvedNow && <Confetti fire />}
      {/* Header card */}
      <div className="card flex flex-wrap items-center justify-between gap-4 p-5">
        <div className="flex items-start gap-4">
          <Link to="/sessions" className="btn-secondary" aria-label="Back to sessions" title="Back to sessions">
            <ArrowLeft className="h-4.5 w-4.5" />
          </Link>
          <div>
            <h2 className="text-xl font-extrabold tracking-tight text-darkgreen">
              Session #{String(session.id).padStart(4, '0')} — {instrument.name}
            </h2>
            <p className="mt-0.5 text-xs font-semibold text-forestsage">
              {instrument.manufacturer} {instrument.model} · S/N {instrument.serial_number} · Class {instrument.accuracy_class} · e {instrument.verification_scale_interval} · {instrument.max_capacity_kg} kg max
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-3 text-xs font-semibold text-forestsage">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-softgold/30 px-3 py-1.5">
            <FlaskConical className="h-3.5 w-3.5 text-caramel" /> {session.reference_standard}
          </span>
          {session.ambient_temp_c != null && (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-softgold/30 px-3 py-1.5">
              <Thermometer className="h-3.5 w-3.5 text-errormocha" /> {session.ambient_temp_c}°C
            </span>
          )}
          {session.ambient_humidity_pct != null && (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-softgold/30 px-3 py-1.5">
              <Droplets className="h-3.5 w-3.5 text-forestsage" /> {session.ambient_humidity_pct}% RH
            </span>
          )}
          {!editable && (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-mutedgold/40 px-3 py-1.5 text-errormocha">
              <Lock className="h-3.5 w-3.5" /> {session.status} — read only
            </span>
          )}
        </div>
      </div>

      <Stepper current={current} completedMap={completedMap} onJump={switchStep} editable={editable} />

      {/* Inspection location + evidence uploads */}
      <LocationEvidenceCard sessionId={id} session={session} files={payload.files} editable={editable} onRefresh={load} />

      {/* Approver review panel (submitted sessions) */}
      {session.status === 'submitted' && (
        <ApprovalPanel
          session={session}
          evaluation={evaluation}
          files={payload.files || []}
          onDecided={(d) => setPayload((p) => ({ ...p, session: d.session, approval: d.approval, evaluation: d.evaluation }))}
        />
      )}

      {/* Rejection banner */}
      {session.status === 'approved' && (
        <div className="card flex items-center gap-4 border-sage bg-sage/20 p-5">
          <span className="animate-check-pop flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-forestsage to-sage text-cream shadow-lg shadow-sage/40">
            <CheckCircle2 className="h-6 w-6" />
          </span>
          <div className="flex-1">
            <p className="text-sm font-extrabold text-darkgreen">Approved & digitally signed by {approval?.approver_name}</p>
            <p className="text-xs font-semibold text-forestsage">{approval?.signed_at?.slice(0, 16).replace('T', ' ')} · this session is now read-only</p>
          </div>
          <Link to={`/sessions/${id}/report`} className="btn-primary btn-sm shrink-0">
            <FileBarChart2 className="h-4 w-4" /> Open report
          </Link>
        </div>
      )}

      {session.status === 'rejected' && approval?.comment && (
        <div className="card border-errormocha/40 bg-errormocha/10 p-5">
          <div className="flex items-start gap-3">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-errormocha/15 text-errormocha">
              <AlertTriangle className="h-5 w-5" />
            </span>
            <div className="flex-1">
              <p className="text-sm font-extrabold text-errormocha">Rejected by {approval.approver_name} — {approval.signed_at?.slice(0, 16).replace('T', ' ')}</p>
              <p className="mt-1 text-sm font-medium text-errormocha">“{approval.comment}”</p>
            </div>
            {editable && (
              <button
                className="btn-orange btn-sm shrink-0"
                onClick={async () => {
                  const d = await api(`/sessions/${id}/reopen`, { method: 'PUT', body: {} });
                  setPayload((p) => ({ ...p, session: { ...p.session, status: d.session.status } }));
                }}
              >
                <RotateCcw className="h-4 w-4" /> Reopen & fix
              </button>
            )}
          </div>
        </div>
      )}

      {/* Module form card */}
      <div className="card card-flush overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-4" style={{ backgroundColor: `${module.color}0D` }}>
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl text-white shadow-md" style={{ backgroundColor: module.color, boxShadow: `0 4px 12px ${module.color}44` }}>
              <module.icon className="h-5 w-5" />
            </span>
            <div>
              <p className="text-[11px] font-bold uppercase tracking-widest" style={{ color: module.color }}>
                Step {current + 1} of {TEST_MODULES.length}
              </p>
              <h3 className="text-lg font-extrabold tracking-tight text-darkgreen">{module.label}</h3>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {session.status === 'approved' && (
              <Link to={`/sessions/${id}/report`} className="btn-primary btn-sm">
                <FileBarChart2 className="h-4 w-4" /> View report
              </Link>
            )}
            <PassBadge verdict={moduleVerdict} size="md" />
            {saveState === 'saving' && <span className="inline-flex items-center gap-1.5 text-xs font-bold text-forestsage/70"><Loader2 className="h-3.5 w-3.5 animate-spin" /> Saving…</span>}
            {saveState === 'saved' && <span className="inline-flex items-center gap-1.5 text-xs font-bold text-forestsage"><CheckCircle2 className="h-3.5 w-3.5" /> Saved</span>}
            {saveState === 'error' && <span className="inline-flex items-center gap-1.5 text-xs font-bold text-errormocha"><X className="h-3.5 w-3.5" /> {submitError || 'Save failed'}</span>}
            {editable && (
              <button
                onClick={() => persist(module.key, data, completedMap[module.key] || false)}
                className="btn-secondary btn-sm"
              >
                <Save className="h-4 w-4" /> Save
              </button>
            )}
          </div>
        </div>

        <div className="overflow-x-auto p-6">
          <ModuleForms moduleKey={module.key} data={data} update={setData} loadPoints={loadPoints} instrument={instrument} />

          {/* Stacked on phones so the three actions never crowd or overlap. */}
          {editable && (
            <div className="mt-6 flex flex-col gap-3 border-t border-softgold/50 pt-5 sm:flex-row sm:items-center sm:justify-between">
              <button className="btn-secondary w-full sm:w-auto" disabled={current === 0} onClick={() => switchStep(current - 1)}>
                <ArrowLeft className="h-4 w-4" /> Previous
              </button>

              <div className="flex w-full flex-wrap items-center justify-center gap-2 sm:w-auto">
                {allDone && evaluation?.overall === 'pass' && (
                  <Link to={`/sessions/${id}/report`} className="btn-primary btn-sm">
                    <FileBarChart2 className="h-4 w-4" /> Report
                  </Link>
                )}
                <button
                  onClick={handleMarkComplete}
                  disabled={completedMap[module.key]}
                  className={completedMap[module.key] ? 'btn-secondary btn-sm' : 'btn-primary btn-sm'}
                >
                  <CheckCircle2 className="h-4 w-4" />
                  {completedMap[module.key] ? 'Step completed ✓' : 'Mark step complete'}
                </button>
                <button onClick={handleSaveAndExit} className="btn-secondary btn-sm">
                  <FileText className="h-4 w-4" /> Save draft & exit
                </button>
                {allDone && (
                  <button onClick={handleSubmit} disabled={submitting} className="btn-orange btn-sm">
                    {submitting ? <span className="btn-spinner" /> : <Send className="h-4 w-4" />}
                    Submit for approval
                  </button>
                )}
              </div>

              <button className="btn-primary w-full sm:w-auto" disabled={current === TEST_MODULES.length - 1} onClick={() => switchStep(current + 1)}>
                Next <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          )}

          {!editable && (
            <p className="mt-6 border-t border-softgold/50 pt-5 text-center text-xs font-semibold text-forestsage/80">
              This session has been {session.status} — data entry is locked.
            </p>
          )}
        </div>
      </div>

      <p className="text-center text-xs font-medium text-forestsage/80">
        {completedCount} of {TEST_MODULES.length} modules completed · data saves per step so you can resume anytime
      </p>
    </div>
  );
}
