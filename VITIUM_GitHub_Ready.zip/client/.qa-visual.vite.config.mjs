import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    port: 5180,
    strictPort: true,
    allowedHosts: true,
    proxy: { '/api': { target: 'http://localhost:4100', changeOrigin: true } },
  },
});
