import express, { Router } from 'express';
import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';
import { signToken, requireAuth, authorize } from './auth.js';
import { initDb } from './db.js';
import { suggestLoadPoints, parseIntervalKg, MODULE_KEYS } from './loadPoints.js';
import { ensureMpeRules, getMpeRuleMeta, mpeInEFromDb } from './mpeEngine.js';
import { evaluateSession } from './evaluate.js';
import { smtpConfigured, sendMail, otpEmailHtml, otpEmailText } from './mailer.js';
import { evaluateMeasurement, instrumentCode, certificateNumber, certificateValidity, certStatus } from './calc.js';
import { audit } from './audit.js';

const db = initDb();
ensureMpeRules(db);
const r = Router();

const ROLES = ['engineer', 'approver', 'admin', 'business'];

const publicUser = (u) => ({
  id: u.id,
  fullName: u.full_name,
  email: u.email,
  role: u.role,
  active: !!u.active,
  emailVerified: u.email_verified === undefined ? true : !!u.email_verified,
  ownerOf: u.owner_of || '',
});

// Business/owner users may only see instruments linked to them (owner_of codes
// assigned by an admin, or a matching owner contact on the instrument).
function businessScopeSql(user) {
  // Tokens carry both `name` (legacy) and `fullName`; use whichever is present
  // so sessions signed before the claim fix never bind NULL to SQLite.
  const displayName = user.fullName || user.name || '';
  const codes = String(user.ownerOf || '').split(',').map((s) => s.trim()).filter(Boolean);
  const clauses = ['i.owner_contact = ?', 'i.owner_name = ?'];
  const vals = [user.email, displayName];
  if (codes.length) {
    clauses.push(`i.instrument_code IN (${codes.map(() => '?').join(',')})`);
    vals.push(...codes);
  }
  return { clause: `(${clauses.join(' OR ')})`, vals };
}

function canAccessInstrument(user, inst) {
  if (user.role !== 'business') return true;
  if (!inst) return false;
  if (String(inst.owner_contact || '') === user.email) return true;
  if (String(inst.owner_name || '') === (user.fullName || user.name || '')) return true;
  const codes = String(user.ownerOf || '').split(',').map((s) => s.trim()).filter(Boolean);
  return codes.includes(inst.instrument_code);
}

/* -------- Signup + email OTP verification helpers -------- */
const OTP_TTL_MINUTES = 10;
const OTP_MAX_ATTEMPTS = 5;
const OTP_RESEND_COOLDOWN_SECONDS = 45;

function generateOtp() {
  // Cryptographically random 6-digit code (100000–999999)
  return String(100000 + crypto.randomInt(900000));
}

function nowSql() {
  return new Date().toISOString().slice(0, 19).replace('T', ' ');
}

function expirySql(minutes) {
  return new Date(Date.now() + minutes * 60000).toISOString().slice(0, 19).replace('T', ' ');
}

function otpDebugDemoCode(code) {
  // In demo mode (no SMTP configured) the code is surfaced to the client so the
  // signup flow can be tested end-to-end. Never exposed when SMTP is live.
  return smtpConfigured() ? undefined : code;
}
function invalidateOtps(email, purpose) {
  db.prepare('UPDATE email_otps SET consumed_at = ? WHERE email = ? AND purpose = ? AND consumed_at IS NULL')
    .run(nowSql(), email, purpose);
}

async function issueSignupOtp(user) {
  const email = String(user.email).trim().toLowerCase();
  invalidateOtps(email, 'signup');
  const code = generateOtp();
  db.prepare(
    'INSERT INTO email_otps (email, code_hash, purpose, expires_at) VALUES (?, ?, ?, ?)'
  ).run(email, bcrypt.hashSync(code, 8), 'signup', expirySql(OTP_TTL_MINUTES));

  const result = await sendMail({
    to: email,
    subject: `Your VITIUM verification code: ${code}`,
    html: otpEmailHtml(user.full_name, code),
    text: otpEmailText(user.full_name, code),
  });
  if (result.delivered) console.log(`[auth] OTP email sent to ${email}`);
  else if (result.demo) console.log(`[auth][demo] OTP for ${email}: ${code}`);
  else console.warn(`[auth] OTP delivery FAILED for ${email} — code ${code} is valid but was NOT emailed. User cannot receive it by email until sending works.`);
  return { mailResult: result, demoCode: otpDebugDemoCode(code) };
}

/* ================= Auth ================= */
r.post('/auth/login', async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Email and password are required' });
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(String(email).trim().toLowerCase());
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }
  if (!user.active) return res.status(403).json({ error: 'Account disabled. Contact your administrator.' });
  // Unverified signups may sign in, but only to complete email verification.
  if (!user.email_verified) {
    const { demoCode } = await issueSignupOtp(user);
    return res.status(403).json({
      error: 'Email not verified. We have sent you a fresh verification code.',
      code: 'EMAIL_NOT_VERIFIED',
      email: user.email,
      cooldownSeconds: OTP_RESEND_COOLDOWN_SECONDS,
      demoCode,
    });
  }
  res.json({ token: signToken(user), user: publicUser(user) });
});

// Create an account: user is stored unverified and a 6-digit OTP is emailed.
r.post('/auth/register', async (req, res) => {
  const { fullName, email, password, role } = req.body || {};
  if (!fullName || !email || !password) {
    return res.status(400).json({ error: 'Full name, email and password are required' });
  }
  const chosenRole = role || 'engineer';
  if (!['engineer', 'approver', 'business'].includes(chosenRole)) {
    return res.status(400).json({ error: 'Self sign-up is available for the Engineer, Approver or Business Owner roles only' });
  }
  const name = String(fullName).trim();
  const mail = String(email).trim().toLowerCase();
  if (name.length < 2 || name.length > 80) return res.status(400).json({ error: 'Please enter your full name' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mail)) return res.status(400).json({ error: 'Please enter a valid email address' });
  if (String(password).length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });

  const existing = db.prepare('SELECT * FROM users WHERE email = ?').get(mail);
  if (existing && existing.email_verified) {
    return res.status(409).json({ error: 'An account with this email already exists. Try signing in instead.' });
  }

  const hash = bcrypt.hashSync(String(password), 10);
  let user;
  if (existing) {
    // An unverified signup with this email exists — refresh its details and
    // re-issue a code rather than allowing duplicate accounts.
    db.prepare('UPDATE users SET full_name = ?, password_hash = ?, role = ? WHERE id = ?')
      .run(name, hash, chosenRole, existing.id);
    user = db.prepare('SELECT * FROM users WHERE id = ?').get(existing.id);
  } else {
    try {
      const out = db.prepare(
        'INSERT INTO users (full_name, email, password_hash, role, email_verified) VALUES (?, ?, ?, ?, 0)'
      ).run(name, mail, hash, chosenRole);
      user = db.prepare('SELECT * FROM users WHERE id = ?').get(Number(out.lastInsertRowid));
    } catch (e) {
      if (String(e).includes('UNIQUE')) return res.status(409).json({ error: 'An account with this email already exists. Try signing in instead.' });
      throw e;
    }
  }

  const { mailResult, demoCode } = await issueSignupOtp(user);
  const message = mailResult.delivered
    ? `Account created. A 6-digit verification code was emailed to ${mail}.`
    : mailResult.demo
      ? 'Account created. SMTP is not configured on this server, so demo verification codes are shown on screen.'
      : 'Account created, but the verification email could not be sent. Check the server logs — ask an administrator to fix SMTP settings, then request a new code.';
  res.status(201).json({
    message,
    email: user.email,
    fullName: user.full_name,
    emailDelivery: mailResult,
    cooldownSeconds: OTP_RESEND_COOLDOWN_SECONDS,
    demoCode,
  });
});

// Verify a signup OTP. On success the account is activated and signed in.
r.post('/auth/verify-otp', (req, res) => {
  const { email, code } = req.body || {};
  if (!email || !code) return res.status(400).json({ error: 'Email and verification code are required' });
  const mail = String(email).trim().toLowerCase();
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(mail);
  if (!user) return res.status(404).json({ error: 'No pending account for this email' });
  if (user.email_verified) return res.status(409).json({ error: 'This email is already verified. Please sign in.' });

  const otp = db.prepare(
    'SELECT * FROM email_otps WHERE email = ? AND purpose = ? AND consumed_at IS NULL ORDER BY id DESC LIMIT 1'
  ).get(mail, 'signup');
  if (!otp) return res.status(400).json({ error: 'No active code. Request a new one.' });
  if (otp.expires_at <= nowSql()) {
    return res.status(400).json({ error: 'This code has expired. Request a new one.' });
  }
  if (otp.attempts >= OTP_MAX_ATTEMPTS) {
    invalidateOtps(mail, 'signup');
    return res.status(429).json({ error: 'Too many incorrect attempts. Request a new code.' });
  }
  if (!bcrypt.compareSync(String(code).trim(), otp.code_hash)) {
    db.prepare('UPDATE email_otps SET attempts = attempts + 1 WHERE id = ?').run(otp.id);
    const left = OTP_MAX_ATTEMPTS - otp.attempts - 1;
    return res.status(400).json({ error: `Incorrect code. ${left > 0 ? `${left} attempt${left === 1 ? '' : 's'} remaining.` : 'Request a new code.'}` });
  }

  invalidateOtps(mail, 'signup');
  db.prepare('UPDATE users SET email_verified = 1 WHERE id = ?').run(user.id);
  const fresh = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id);
  res.json({ message: 'Email verified. Welcome to VITIUM!', token: signToken(fresh), user: publicUser(fresh) });
});

// Re-send the verification code (rate-limited by a cooldown).
r.post('/auth/resend-otp', async (req, res) => {
  const { email } = req.body || {};
  if (!email) return res.status(400).json({ error: 'Email is required' });
  const mail = String(email).trim().toLowerCase();
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(mail);
  if (!user) return res.status(404).json({ error: 'No account found for this email' });
  if (user.email_verified) return res.status(409).json({ error: 'This email is already verified. Please sign in.' });

  const last = db.prepare(
    "SELECT created_at FROM email_otps WHERE email = ? AND purpose = 'signup' ORDER BY id DESC LIMIT 1"
  ).get(mail);
  if (last) {
    const elapsed = (Date.now() - new Date(last.created_at.replace(' ', 'T') + 'Z').getTime()) / 1000;
    if (elapsed < OTP_RESEND_COOLDOWN_SECONDS) {
      const wait = Math.ceil(OTP_RESEND_COOLDOWN_SECONDS - elapsed);
      return res.status(429).json({ error: `Please wait ${wait}s before requesting a new code.`, retryAfter: wait });
    }
  }

  const { mailResult, demoCode } = await issueSignupOtp(user);
  res.json({
    message: mailResult.delivered
      ? `A new verification code was emailed to ${mail}.`
      : mailResult.demo
        ? 'A new demo code was generated (SMTP not configured).'
        : 'A new code was generated, but emailing it failed. Check the server logs.',
    emailDelivery: mailResult,
    cooldownSeconds: OTP_RESEND_COOLDOWN_SECONDS,
    demoCode,
  });
});

r.get('/auth/me', requireAuth, (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.sub);
  if (!u || !u.active) return res.status(401).json({ error: 'Account no longer active' });
  res.json({ user: publicUser(u) });
});

/* ================= Dashboard ================= */
r.get('/dashboard', requireAuth, (req, res) => {
  // Business owners only see their own instruments
  let scopedInstIds = null;
  if (req.user.role === 'business') {
    scopedInstIds = db.prepare('SELECT id FROM instruments').all()
      .map((r) => r.id)
      .filter((id) => canAccessInstrument(req.user, db.prepare('SELECT * FROM instruments WHERE id = ?').get(id)));
  }
  const instFilter = scopedInstIds ? (scopedInstIds.length ? `s.instrument_id IN (${scopedInstIds.join(',')})` : '0=1') : '1=1';
  const instFilterI = instFilter.replace(/s\.instrument_id/g, 'i.id');
  const count = (sql, v = []) => db.prepare(sql).get(...v).n;

  const instrumentsTested = count(`SELECT COUNT(DISTINCT s.instrument_id) AS n FROM test_sessions s WHERE s.status != 'draft' AND ${instFilter}`);
  const pendingApprovals = count(`SELECT COUNT(*) AS n FROM test_sessions s WHERE s.status = 'submitted' AND ${instFilter}`);
  const approved = count(`SELECT COUNT(*) AS n FROM test_sessions s WHERE s.status = 'approved' AND ${instFilter}`);
  const rejected = count(`SELECT COUNT(*) AS n FROM test_sessions s WHERE s.status = 'rejected' AND ${instFilter}`);
  const passRate = approved + rejected > 0 ? Math.round((approved / (approved + rejected)) * 100) : null;
  const monthStart = new Date();
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);
  const reportsThisMonth = count(
    `SELECT COUNT(*) AS n FROM test_sessions s WHERE s.submitted_at IS NOT NULL AND s.submitted_at >= ? AND ${instFilter}`,
    [monthStart.toISOString().slice(0, 19).replace('T', ' ')]
  );
  const today = new Date().toISOString().slice(0, 10);
  const weekAgo = new Date(Date.now() - 7 * 86400000).toISOString().slice(0, 19).replace('T', ' ');
  const testsToday = count(`SELECT COUNT(*) AS n FROM test_sessions s WHERE date(COALESCE(s.submitted_at, s.started_at)) = ? AND ${instFilter}`, [today]);
  const testsThisWeek = count(`SELECT COUNT(*) AS n FROM test_sessions s WHERE COALESCE(s.submitted_at, s.started_at) >= ? AND ${instFilter}`, [weekAgo]);
  const isBusiness = req.user.role === 'business';
  const myPending = isBusiness ? 0 : count("SELECT COUNT(*) AS n FROM test_sessions s WHERE s.engineer_id = ? AND s.status IN ('draft','in_progress')", [req.user.sub]);
  const myRejected = isBusiness ? 0 : count("SELECT COUNT(*) AS n FROM test_sessions s WHERE s.engineer_id = ? AND s.status = 'rejected'", [req.user.sub]);
  const expiring30 = count(`SELECT COUNT(*) AS n FROM instruments i WHERE i.certificate_expiry IS NOT NULL AND date(i.certificate_expiry) BETWEEN date('now') AND date('now','+30 days') AND ${instFilterI}`);
  const expiring7 = count(`SELECT COUNT(*) AS n FROM instruments i WHERE i.certificate_expiry IS NOT NULL AND date(i.certificate_expiry) BETWEEN date('now') AND date('now','+7 days') AND ${instFilterI}`);
  const expired = count(`SELECT COUNT(*) AS n FROM instruments i WHERE i.certificate_expiry IS NOT NULL AND date(i.certificate_expiry) < date('now') AND ${instFilterI}`);

  const recent = db.prepare(`
    SELECT s.id, s.status, s.started_at, s.submitted_at, s.reference_standard,
           i.name AS instrument_name, i.serial_number, i.instrument_code, i.instrument_type, u.full_name AS engineer_name
    FROM test_sessions s
    JOIN instruments i ON i.id = s.instrument_id
    JOIN users u ON u.id = s.engineer_id
    WHERE ${instFilter}
    ORDER BY COALESCE(s.submitted_at, s.started_at) DESC, s.id DESC
    LIMIT 8
  `).all();

  const expiringCerts = db.prepare(`
    SELECT i.id, i.name, i.instrument_code, i.serial_number, i.certificate_number, i.certificate_expiry
    FROM instruments i
    WHERE i.certificate_expiry IS NOT NULL AND date(i.certificate_expiry) <= date('now','+30 days') AND ${instFilterI}
    ORDER BY i.certificate_expiry ASC LIMIT 6
  `).all().map((c) => ({ ...c, ...certStatus(c.certificate_expiry) }));

  res.json({
    kpis: { instrumentsTested, pendingApprovals, passRate, reportsThisMonth, testsToday, testsThisWeek, myPending, myRejected, expiring30, expiring7, expired },
    recentSessions: recent,
    expiringCertificates: expiringCerts,
  });
});

/* ================= Instruments ================= */
const INSTRUMENT_TEST_STATUS_SQL = `(
  SELECT CASE
    WHEN COUNT(*) = 0 THEN 'not_tested'
    WHEN SUM(CASE WHEN s.status IN ('draft','in_progress','submitted') THEN 1 ELSE 0 END) > 0 THEN 'in_progress'
    WHEN (SELECT s2.status FROM test_sessions s2 WHERE s2.instrument_id = i.id ORDER BY s2.id DESC LIMIT 1) = 'approved'
      THEN 'passed'
    ELSE 'failed'
  END
  FROM test_sessions s WHERE s.instrument_id = i.id
)`;

r.get('/instruments', requireAuth, (req, res) => {
  const { q, type, status, manufacturer, certStatus: certF } = req.query;
  let sql = `
    SELECT i.*,
      (SELECT COUNT(*) FROM test_sessions s WHERE s.instrument_id = i.id) AS test_count,
      (SELECT COUNT(*) FROM test_sessions s WHERE s.instrument_id = i.id AND s.status = 'rejected') AS fail_count,
      (SELECT COUNT(*) FROM certificates c WHERE c.instrument_id = i.id) AS cert_count,
      (SELECT MAX(s2.approved_at) FROM test_sessions s2 WHERE s2.instrument_id = i.id AND s2.status = 'approved') AS last_tested_at,
      ${INSTRUMENT_TEST_STATUS_SQL} AS test_status
    FROM instruments i WHERE 1=1`;
  const vals = [];
  if (req.user.role === 'business') {
    const scope = businessScopeSql(req.user);
    sql += ` AND ${scope.clause}`;
    vals.push(...scope.vals);
  }
  if (q) {
    sql += ` AND (i.name LIKE ? OR i.serial_number LIKE ? OR i.manufacturer LIKE ? OR i.model LIKE ?
      OR i.instrument_code LIKE ? OR i.owner_name LIKE ? OR i.location LIKE ? OR i.certificate_number LIKE ?)`;
    const like = `%${String(q)}%`;
    vals.push(like, like, like, like, like, like, like, like);
  }
  if (type) { sql += ' AND i.instrument_type = ?'; vals.push(String(type)); }
  if (status) { sql += ' AND i.status = ?'; vals.push(String(status)); }
  if (manufacturer) { sql += ' AND i.manufacturer = ?'; vals.push(String(manufacturer)); }
  if (certF === 'expiring') {
    sql += " AND i.certificate_expiry IS NOT NULL AND date(i.certificate_expiry) BETWEEN date('now') AND date('now', '+30 days')";
  } else if (certF === 'expired') {
    sql += " AND i.certificate_expiry IS NOT NULL AND date(i.certificate_expiry) < date('now')";
  }
  sql += ' ORDER BY i.name';
  res.json({ instruments: db.prepare(sql).all(...vals) });
});

function validateInstrumentBody(b) {
  const errors = [];
  for (const [k, v] of Object.entries({
    name: b.name, manufacturer: b.manufacturer, model: b.model, serialNumber: b.serialNumber,
    maxCapacityKg: b.maxCapacityKg, verificationScaleInterval: b.verificationScaleInterval,
    accuracyClass: b.accuracyClass, location: b.location,
  })) {
    if (v === undefined || v === null || v === '') errors.push(k);
  }
  if (errors.length) return `Missing field(s): ${errors.join(', ')}`;
  if (!['I', 'II', 'III', 'IIII'].includes(b.accuracyClass)) return 'accuracyClass must be I, II, III or IIII';
  if (!(Number(b.maxCapacityKg) > 0)) return 'maxCapacityKg must be a positive number';
  if (b.minCapacityKg !== undefined && b.minCapacityKg !== '' && Number(b.minCapacityKg) < 0) return 'minCapacityKg cannot be negative';
  if (Number(b.minCapacityKg || 0) >= Number(b.maxCapacityKg)) return 'Min capacity must be lower than Max capacity';
  if (!parseIntervalKg(b.verificationScaleInterval)) return 'Verification scale interval could not be parsed (e.g. "e = 100 g")';
  if (b.actualScaleInterval && !parseIntervalKg(b.actualScaleInterval)) return 'Actual scale interval could not be parsed (e.g. "d = 10 g")';
  return null;
}

function instrumentColumnsFromBody(b) {
  return {
    name: b.name,
    manufacturer: b.manufacturer,
    model: b.model,
    serial_number: b.serialNumber,
    max_capacity_kg: b.maxCapacityKg !== undefined ? Number(b.maxCapacityKg) : undefined,
    min_capacity_kg: b.minCapacityKg !== undefined && b.minCapacityKg !== '' ? Number(b.minCapacityKg) : undefined,
    verification_scale_interval: b.verificationScaleInterval,
    actual_scale_interval: b.actualScaleInterval,
    tare_range: b.tareRange,
    accuracy_class: b.accuracyClass,
    location: b.location,
    applicant_name: b.applicantName,
    test_lab: b.testLab,
    test_date: b.testDate,
    status: b.status,
    // --- VITIUM registration fields ---
    instrument_type: b.instrumentType,
    division: b.division,
    unit: b.unit,
    owner_name: b.ownerName,
    owner_contact: b.ownerContact,
    address: b.address,
    city: b.city,
    state: b.state,
    pin_code: b.pinCode,
    installation_date: b.installationDate,
    last_verification_date: b.lastVerificationDate,
    certificate_number: b.certificateNumber,
    certificate_expiry: b.certificateExpiry,
    notes: b.notes,
  };
}

const INSTRUMENT_TYPES = ['Platform Scale', 'Bench Scale', 'Retail Scale', 'Jewellery Balance', 'Truck Weighbridge', 'Other Measuring Instrument'];

r.post('/instruments', requireAuth, authorize('admin'), (req, res) => {
  const b = req.body || {};
  const err = validateInstrumentBody(b);
  if (err) return res.status(400).json({ error: err });
  if (b.instrumentType && !INSTRUMENT_TYPES.includes(b.instrumentType)) {
    return res.status(400).json({ error: 'Unknown instrument type' });
  }
  if (b.certificateExpiry && b.lastVerificationDate && String(b.certificateExpiry) <= String(b.lastVerificationDate)) {
    return res.status(400).json({ error: 'Certificate expiry cannot be before the last verification date' });
  }
  const c = instrumentColumnsFromBody(b);
  try {
    const out = db.prepare(`
      INSERT INTO instruments (name, manufacturer, model, serial_number, max_capacity_kg, min_capacity_kg,
        verification_scale_interval, actual_scale_interval, tare_range, accuracy_class, location,
        applicant_name, test_lab, test_date, instrument_type, division, unit, owner_name, owner_contact,
        address, city, state, pin_code, installation_date, last_verification_date, certificate_number,
        certificate_expiry, notes)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      c.name, c.manufacturer, c.model, String(c.serial_number), c.max_capacity_kg,
      c.min_capacity_kg ?? 0, c.verification_scale_interval, c.actual_scale_interval || c.verification_scale_interval,
      c.tare_range || '-10% Max to 0', c.accuracy_class, c.location,
      c.applicant_name || '', c.test_lab || '', c.test_date || '',
      c.instrument_type || 'Platform Scale', c.division || '', c.unit || 'kg',
      c.owner_name || '', c.owner_contact || '', c.address || '', c.city || '', c.state || '',
      c.pin_code || '', c.installation_date || null, c.last_verification_date || null,
      c.certificate_number || '', c.certificate_expiry || null, c.notes || ''
    );
    const inst = db.prepare('SELECT * FROM instruments WHERE id = ?').get(Number(out.lastInsertRowid));
    // Unique public code, e.g. VTM-INS-000007
    db.prepare('UPDATE instruments SET instrument_code = ? WHERE id = ?').run(instrumentCode(inst.id), inst.id);
    audit(db, req, 'created', 'instrument', inst.id, `${inst.name} (${inst.serial_number})`, { next: { code: instrumentCode(inst.id), type: inst.instrument_type } });
    res.status(201).json({ instrument: { ...inst, instrument_code: instrumentCode(inst.id) } });
  } catch (e) {
    if (String(e).includes('UNIQUE')) return res.status(409).json({ error: 'Serial number already exists' });
    throw e;
  }
});

r.patch('/instruments/:id', requireAuth, authorize('admin'), (req, res) => {
  const inst = db.prepare('SELECT * FROM instruments WHERE id = ?').get(req.params.id);
  if (!inst) return res.status(404).json({ error: 'Instrument not found' });
  const merged = { ...inst, serialNumber: inst.serial_number, ...req.body };
  const err = validateInstrumentBody(merged);
  if (err) return res.status(400).json({ error: err });
  const c = instrumentColumnsFromBody(merged);
  const allowed = Object.entries(c).filter(([, v]) => v !== undefined);
  const sets = allowed.map(([k]) => `${k} = ?`);
  const vals = allowed.map(([, v]) => v);
  if (!sets.length) return res.status(400).json({ error: 'No valid fields to update' });
  vals.push(inst.id);
  db.prepare(`UPDATE instruments SET ${sets.join(', ')} WHERE id = ?`).run(...vals);
  const fresh = db.prepare('SELECT * FROM instruments WHERE id = ?').get(inst.id);
  audit(db, req, 'updated', 'instrument', inst.id, `${fresh.name} (${fresh.serial_number})`, { prev: inst, next: fresh });
  res.json({ instrument: fresh });
});

/* ================= Test Sessions ================= */
const SESSION_SELECT = `
  SELECT s.*, i.name AS instrument_name, i.serial_number, i.accuracy_class, i.max_capacity_kg,
         u.full_name AS engineer_name,
         (SELECT COUNT(*) FROM session_tests st WHERE st.session_id = s.id AND st.completed = 1) AS completed_tests,
         (SELECT COUNT(*) FROM session_tests st WHERE st.session_id = s.id) AS started_tests
  FROM test_sessions s
  JOIN instruments i ON i.id = s.instrument_id
  JOIN users u ON u.id = s.engineer_id
`;

// (SESSION_SELECT must be defined before sessionPayload uses it)

r.get('/sessions', requireAuth, (req, res) => {
  const { status } = req.query;
  let sql = `${SESSION_SELECT}`;
  const vals = [];
  const where = [];
  if (status) { where.push('s.status = ?'); vals.push(String(status)); }
  // Business/owner accounts only ever see sessions on instruments they own
  // (same rule as /instruments and /reports — /sessions had no scope at all).
  if (req.user.role === 'business') {
    const scope = businessScopeSql(req.user);
    where.push(scope.clause);
    vals.push(...scope.vals);
  }
  if (where.length) sql += ` WHERE ${where.join(' AND ')}`;
  sql += ` ORDER BY s.started_at DESC, s.id DESC`;
  res.json({ sessions: db.prepare(sql).all(...vals) });
});

r.post('/sessions', requireAuth, authorize('engineer', 'admin'), (req, res) => {
  const b = req.body || {};
  if (!b.instrumentId) return res.status(400).json({ error: 'instrumentId is required' });
  const inst = db.prepare('SELECT * FROM instruments WHERE id = ?').get(b.instrumentId);
  if (!inst) return res.status(404).json({ error: 'Instrument not found' });
  const existingActive = db.prepare(
    "SELECT id FROM test_sessions WHERE instrument_id = ? AND status IN ('draft','in_progress')"
  ).get(inst.id);
  if (existingActive) {
    return res.status(409).json({ error: `This instrument already has an open session (#${existingActive.id}). Resume it instead.`, sessionId: existingActive.id });
  }
  if (!b.referenceStandard) return res.status(400).json({ error: 'referenceStandard is required' });

  const out = db.prepare(`
    INSERT INTO test_sessions (instrument_id, engineer_id, reference_standard, ambient_temp_c, ambient_humidity_pct, status)
    VALUES (?, ?, ?, ?, ?, 'draft')
  `).run(inst.id, req.user.sub, String(b.referenceStandard), b.ambientTempC ?? null, b.ambientHumidityPct ?? null);
  const id = Number(out.lastInsertRowid);
  audit(db, req, 'test started', 'session', id, `Session #${String(id).padStart(4, '0')} · ${inst.name}`, { next: { instrumentId: inst.id } });
  res.status(201).json({ session: db.prepare(`${SESSION_SELECT} WHERE s.id = ?`).get(id) });
});

// Full instrument profile: details + stats + QR target + cert status
r.get('/instruments/:id/profile', requireAuth, (req, res) => {
  const inst = db.prepare('SELECT * FROM instruments WHERE id = ?').get(req.params.id);
  if (!inst) return res.status(404).json({ error: 'Instrument not found' });
  if (!canAccessInstrument(req.user, inst)) return res.status(403).json({ error: 'Forbidden — instrument belongs to another owner' });
  const meta = instrumentMeta(inst);
  const sessions = db.prepare(`
    SELECT s.id, s.status, s.started_at, s.submitted_at, s.approved_at, u.full_name AS engineer_name,
      (SELECT decision FROM approvals a WHERE a.session_id = s.id ORDER BY a.signed_at DESC, a.id DESC LIMIT 1) AS decision
    FROM test_sessions s JOIN users u ON u.id = s.engineer_id
    WHERE s.instrument_id = ? ORDER BY s.id DESC
  `).all(inst.id);
  const certs = db.prepare(`
    SELECT c.*, u.full_name AS verifier_name FROM certificates c
    LEFT JOIN users u ON u.id = c.verifier_id
    WHERE c.instrument_id = ? ORDER BY c.issued_at DESC
  `).all(inst.id);
  const files = db.prepare(
    'SELECT id, kind, doc_type, file_name, mime_type, size_bytes, created_at FROM files WHERE instrument_id = ? OR id IN (SELECT f.id FROM files f JOIN test_sessions s ON s.id = f.session_id WHERE s.instrument_id = ?) ORDER BY created_at DESC'
  ).all(inst.id, inst.id);
  const lastApproved = sessions.find((s) => s.status === 'approved');
  const lastVerification = meta.last_verification_date || lastApproved?.approved_at?.slice(0, 10) || null;
  const validity = certificateValidity(lastVerification, 12);
  const expiry = meta.certificate_expiry || validity.validUntil;
  res.json({
    instrument: meta,
    stats: {
      tests: sessions.length,
      failures: sessions.filter((s) => s.status === 'rejected' || s.decision === 'rejected').length,
      certificates: certs.length,
      lastTestedAt: lastApproved?.approved_at || sessions.find((s) => s.submitted_at)?.submitted_at || null,
      lastResult: lastApproved ? 'pass' : sessions[0] ? (sessions[0].status === 'rejected' ? 'fail' : null) : null,
    },
    certificate: { number: meta.certificate_number || certs[0]?.cert_number || null, expiry, ...certStatus(expiry), validityMonths: 12 },
    sessions,
    certificates: certs.map((c) => ({ ...c, ...certStatus(c.valid_until) })),
    files,
  });
});

// Resolve an instrument by its public code (VTM-INS-XXXXXX) — used by QR scans
r.get('/instruments/code/:code', requireAuth, (req, res) => {
  const code = String(req.params.code || '').trim().toUpperCase();
  const inst = db.prepare('SELECT id FROM instruments WHERE UPPER(instrument_code) = ?').get(code);
  if (!inst) return res.status(404).json({ error: `No instrument found for code ${code}` });
  res.json({ instrumentId: inst.id });
});

// Checklist modules for an instrument type (configurable by admin)
r.get('/instrument-types', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT * FROM instrument_types ORDER BY name').all();
  res.json({ types: rows.map((t) => ({ ...t, modules: JSON.parse(t.modules || '[]') })) });
});

r.put('/instrument-types/:id', requireAuth, authorize('admin'), (req, res) => {
  const t = db.prepare('SELECT * FROM instrument_types WHERE id = ?').get(req.params.id);
  if (!t) return res.status(404).json({ error: 'Instrument type not found' });
  const b = req.body || {};
  if (b.modules !== undefined) {
    if (!Array.isArray(b.modules)) return res.status(400).json({ error: 'modules must be an array of module keys' });
    const valid = b.modules.every((m) => MODULE_KEYS.includes(m));
    if (!valid) return res.status(400).json({ error: 'Unknown module key in list' });
  }
  const fields = { description: b.description, purpose: b.purpose, how_it_works: b.howItWorks, specs: b.specs, test_methods: b.testMethods, failure_modes: b.failureModes, safety_notes: b.safetyNotes, modules: b.modules !== undefined ? JSON.stringify(b.modules) : undefined };
  const sets = Object.entries(fields).filter(([, v]) => v !== undefined);
  if (!sets.length) return res.status(400).json({ error: 'No fields to update' });
  db.prepare(`UPDATE instrument_types SET ${sets.map(([k]) => `${k} = ?`).join(', ')} WHERE id = ?`).run(...sets.map(([, v]) => v), t.id);
  audit(db, req, 'updated', 'instrument_type', t.id, t.name, { prev: t, next: b });
  const fresh = db.prepare('SELECT * FROM instrument_types WHERE id = ?').get(t.id);
  res.json({ type: { ...fresh, modules: JSON.parse(fresh.modules || '[]') } });
});

function instrumentMeta(inst) {
  const eKg = parseIntervalKg(inst.verification_scale_interval) ?? inst.max_capacity_kg / 1000;
  const dKg = parseIntervalKg(inst.actual_scale_interval) ?? eKg;
  return { ...inst, e_kg: eKg, d_kg: dKg };
}

function getLoadPointsForSession(session) {
  const inst = db.prepare('SELECT * FROM instruments WHERE id = ?').get(session.instrument_id);
  const meta = instrumentMeta(inst);
  return suggestLoadPoints(db, {
    maxCapacityKg: meta.max_capacity_kg,
    minCapacityKg: meta.min_capacity_kg ?? 0,
    eKg: meta.e_kg,
    dKg: meta.d_kg,
    accuracyClass: meta.accuracy_class,
  });
}

function sessionPayload(id) {
  const session = db.prepare(`${SESSION_SELECT} WHERE s.id = ?`).get(id);
  if (!session) return null;
  const inst = instrumentMeta(db.prepare('SELECT * FROM instruments WHERE id = ?').get(session.instrument_id));
  const tests = db.prepare('SELECT * FROM session_tests WHERE session_id = ?').all(session.id);
  const testMap = {};
  for (const t of tests) {
    let data = {};
    try { data = JSON.parse(t.data); } catch { /* keep {} */ }
    testMap[t.module_key] = { completed: !!t.completed, data, updated_at: t.updated_at };
  }
  const approval = db.prepare(`
    SELECT a.*, u.full_name AS approver_name
    FROM approvals a JOIN users u ON u.id = a.approver_id
    WHERE a.session_id = ? ORDER BY a.signed_at DESC, a.id DESC LIMIT 1
  `).get(session.id);
  const files = db.prepare('SELECT id, kind, doc_type, file_name, mime_type, size_bytes, module_key, created_at FROM files WHERE session_id = ? ORDER BY created_at DESC').all(session.id);
  const typeRow = db.prepare('SELECT * FROM instrument_types WHERE name = ?').get(inst.instrument_type || '');
  const checklist = typeRow?.modules ? JSON.parse(typeRow.modules) : null;
  const evaluation = evaluateSession(db, inst, testMap, checklist);
  return { session, instrument: inst, tests: testMap, loadPoints: getLoadPointsForSession(session), evaluation, approval: approval || null, files, checklist: checklist || [...MODULE_KEYS] };
}

// Session reads are shared workspace data for lab roles, but business/owner
// accounts may only follow sessions on instruments they own.
function sessionVisibleTo(user, payload) {
  if (user.role !== 'business') return true;
  return canAccessInstrument(user, payload.instrument);
}

r.get('/sessions/:id', requireAuth, (req, res) => {
  const payload = sessionPayload(req.params.id);
  if (!payload || !sessionVisibleTo(req.user, payload)) return res.status(404).json({ error: 'Session not found' });
  res.json(payload);
});

// Full report payload for the R-76-2 style report (on-screen + PDF)
r.get('/sessions/:id/report', requireAuth, (req, res) => {
  const payload = sessionPayload(req.params.id);
  if (!payload || !sessionVisibleTo(req.user, payload)) return res.status(404).json({ error: 'Session not found' });
  const settings = db.prepare('SELECT * FROM org_settings WHERE id = 1').get()
    || { org_name: 'VITIUM', certificate_footer: 'Issued in accordance with OIML R-76' };
  res.json({ ...payload, org: settings, mpeSource: getMpeRuleMeta(db).source });
});

// Only the engineer who owns a session may modify it (admins may assist on
// any session). Approvers never reach here — authorize() already excludes them.
function assertSessionOwnership(req, res, session) {
  if (req.user.role === 'admin') return true;
  if (Number(session.engineer_id) !== Number(req.user.sub)) {
    res.status(403).json({ error: 'You can only work on your own test sessions' });
    return false;
  }
  return true;
}

r.put('/sessions/:id/tests/:moduleKey', requireAuth, authorize('engineer', 'admin'), (req, res) => {
  const session = db.prepare('SELECT * FROM test_sessions WHERE id = ?').get(req.params.id);
  if (!session) return res.status(404).json({ error: 'Session not found' });
  if (!assertSessionOwnership(req, res, session)) return;
  if (!['draft', 'in_progress'].includes(session.status)) {
    return res.status(409).json({ error: `Session is ${session.status} and can no longer be edited` });
  }
  const { moduleKey } = req.params;
  if (!MODULE_KEYS.includes(moduleKey)) return res.status(400).json({ error: 'Unknown test module' });
  const completed = req.body?.completed ? 1 : 0;
  const prev = db.prepare('SELECT * FROM session_tests WHERE session_id = ? AND module_key = ?').get(session.id, moduleKey);
  const data = JSON.stringify(req.body?.data ?? {});

  db.prepare(`
    INSERT INTO session_tests (session_id, module_key, completed, data, updated_at)
    VALUES (?, ?, ?, ?, datetime('now'))
    ON CONFLICT(session_id, module_key)
    DO UPDATE SET completed = excluded.completed, data = excluded.data, updated_at = datetime('now')
  `).run(session.id, moduleKey, completed, data);

  if (prev) {
    const prevData = (() => { try { return JSON.parse(prev.data); } catch { return {}; } })();
    if (JSON.stringify(prevData) !== JSON.stringify(req.body?.data ?? {})) {
      audit(db, req, prev.completed ? 'measurement modified' : 'measurement entered', 'session', session.id,
        `Session #${String(session.id).padStart(4, '0')} · ${moduleKey}`, { prev: prevData, next: req.body?.data });
    }
  }

  if (session.status === 'draft') {
    db.prepare("UPDATE test_sessions SET status = 'in_progress' WHERE id = ?").run(session.id);
  }
  const updated = db.prepare('SELECT * FROM session_tests WHERE session_id = ? AND module_key = ?').get(session.id, moduleKey);
  let dataOut = {};
  try { dataOut = JSON.parse(updated.data); } catch { /* keep {} */ }
  res.json({ test: { moduleKey, completed: !!updated.completed, data: dataOut, updated_at: updated.updated_at } });
});

r.put('/sessions/:id/status', requireAuth, authorize('engineer', 'admin'), (req, res) => {
  const session = db.prepare('SELECT * FROM test_sessions WHERE id = ?').get(req.params.id);
  if (!session) return res.status(404).json({ error: 'Session not found' });
  if (!assertSessionOwnership(req, res, session)) return;
  const { status } = req.body || {};

  if (status === 'in_progress') {
    if (!['draft', 'in_progress'].includes(session.status)) {
      return res.status(409).json({ error: `Cannot restart a ${session.status} session` });
    }
    db.prepare("UPDATE test_sessions SET status = 'in_progress' WHERE id = ?").run(session.id);
  } else if (status === 'draft') {
    if (session.status !== 'in_progress') {
      return res.status(409).json({ error: `Cannot move a ${session.status} session back to draft` });
    }
    db.prepare("UPDATE test_sessions SET status = 'draft' WHERE id = ?").run(session.id);
  } else if (status === 'submitted') {
    if (session.status !== 'in_progress' && session.status !== 'draft') {
      return res.status(409).json({ error: `Cannot submit a ${session.status} session` });
    }
    const done = db.prepare('SELECT COUNT(*) AS n FROM session_tests WHERE session_id = ? AND completed = 1').get(session.id).n;
    const inst = db.prepare('SELECT * FROM instruments WHERE id = ?').get(session.instrument_id);
    const typeRow = db.prepare('SELECT * FROM instrument_types WHERE name = ?').get(inst.instrument_type || '');
    const required = typeRow?.modules ? JSON.parse(typeRow.modules) : MODULE_KEYS;
    if (done < required.length) {
      return res.status(400).json({ error: `All ${required.length} mandatory tests must be completed before submitting (${done} done)` });
    }
    db.prepare("UPDATE test_sessions SET status = 'submitted', submitted_at = datetime('now') WHERE id = ?").run(session.id);
    audit(db, req, 'submitted', 'session', session.id, `Session #${String(session.id).padStart(4, '0')} · ${inst.name}`);
    notifyRole(db, 'approver', 'approval_required', 'info', `Session #${String(session.id).padStart(4, '0')} awaiting review`, `${inst.name} (${inst.serial_number}) submitted for verification`, `/sessions/${session.id}`);
  } else {
    return res.status(400).json({ error: 'Unsupported status transition' });
  }
  res.json({ session: db.prepare(`${SESSION_SELECT} WHERE s.id = ?`).get(session.id) });
});

/* ================= Public verification (no auth) ================= */
r.get('/verify/:reportUid', (req, res) => {
  const row = db.prepare(`
    SELECT s.id, s.report_uid, s.status, s.approved_at, s.started_at,
           i.name AS instrument_name, i.manufacturer, i.model, i.serial_number,
           i.accuracy_class, u.full_name AS engineer_name,
           a.decision, a.approver_id, a.signed_at,
           (SELECT full_name FROM users WHERE id = a.approver_id) AS approver_name,
           (SELECT org_name FROM org_settings WHERE id = 1) AS org_name
    FROM test_sessions s
    JOIN instruments i ON i.id = s.instrument_id
    JOIN users u ON u.id = s.engineer_id
    LEFT JOIN approvals a ON a.id = (
      SELECT a2.id FROM approvals a2 WHERE a2.session_id = s.id
      ORDER BY a2.signed_at DESC, a2.id DESC LIMIT 1
    )
    WHERE s.report_uid = ?
  `).get(req.params.reportUid);
  if (!row) return res.status(404).json({ error: 'Report not found — this QR code may be invalid' });
  if (row.status !== 'approved') {
    return res.status(404).json({ error: 'This report is not approved yet' });
  }
  res.json({
    verified: true,
    reportId: `RPT-${String(row.id).padStart(4, '0')}`,
    reportUid: row.report_uid,
    instrument: {
      name: row.instrument_name,
      manufacturer: row.manufacturer,
      model: row.model,
      serialNumber: row.serial_number,
      accuracyClass: row.accuracy_class,
    },
    engineerName: row.engineer_name,
    approverName: row.approver_name,
    verdict: row.decision === 'approved' ? 'pass' : 'fail',
    approvedAt: row.approved_at,
    orgName: row.org_name,
  });
});

/* ================= Instrument history & analytics ================= */
r.get('/instruments/:id/history', requireAuth, (req, res) => {
  const inst = db.prepare('SELECT * FROM instruments WHERE id = ?').get(req.params.id);
  if (!inst) return res.status(404).json({ error: 'Instrument not found' });
  const meta = instrumentMeta(inst);
  const sessions = db.prepare(`
    SELECT s.id, s.status, s.started_at, s.submitted_at, s.approved_at, s.report_uid,
           u.full_name AS engineer_name, s.reference_standard,
           (SELECT decision FROM approvals a WHERE a.session_id = s.id ORDER BY a.signed_at DESC, a.id DESC LIMIT 1) AS decision,
           (SELECT full_name FROM users WHERE id = (SELECT approver_id FROM approvals a WHERE a.session_id = s.id ORDER BY a.signed_at DESC, a.id DESC LIMIT 1)) AS approver_name,
           (SELECT data FROM session_tests st WHERE st.session_id = s.id AND st.module_key = 'weighing') AS weighing_data
    FROM test_sessions s
    JOIN users u ON u.id = s.engineer_id
    WHERE s.instrument_id = ?
    ORDER BY COALESCE(s.approved_at, s.submitted_at, s.started_at) DESC
  `).all(inst.id);

  // Max |error| from the weighing module per session, for the drift chart
  const eKg = meta.e_kg;
  const history = sessions.map((s) => {
    let maxAbsError = null;
    let verdict = null;
    if (s.weighing_data) {
      try {
        const wd = JSON.parse(s.weighing_data);
        const errs = [];
        for (const dir of ['increasing', 'decreasing']) {
          for (const row of wd[dir] || []) {
            const e = Number(row.error);
            if (Number.isFinite(e)) errs.push(Math.abs(e));
          }
        }
        if (errs.length) maxAbsError = Math.max(...errs);
      } catch { /* ignore */ }
    }
    if (s.status === 'approved' || s.decision === 'approved') verdict = 'pass';
    else if (s.status === 'rejected' || s.decision === 'rejected') verdict = 'fail';
    return {
      id: s.id,
      date: s.approved_at || s.submitted_at || s.started_at,
      status: s.status,
      decision: s.decision,
      verdict,
      engineer: s.engineer_name,
      approver: s.approver_name,
      referenceStandard: s.reference_standard,
      reportUid: s.report_uid,
      maxAbsError,
      mpeKg: Math.round((mpeInEFromDb(db, inst.accuracy_class, inst.max_capacity_kg, eKg) ?? 1.5) * eKg * 1e6) / 1e6,
    };
  });
  res.json({ instrument: meta, history });
});

// Org-wide analytics — the client only offers this to lab roles; business
// owners must not see other owners' workload, failure reasons or totals.
r.get('/analytics', requireAuth, authorize('engineer', 'approver', 'admin'), (req, res) => {
  const passByClass = db.prepare(`
    SELECT i.accuracy_class AS cls,
           SUM(CASE WHEN s.status = 'approved' THEN 1 ELSE 0 END) AS approved,
           SUM(CASE WHEN s.status = 'rejected' THEN 1 ELSE 0 END) AS rejected
    FROM test_sessions s JOIN instruments i ON i.id = s.instrument_id
    GROUP BY i.accuracy_class
  `).all();

  const perMonth = db.prepare(`
    SELECT substr(COALESCE(s.submitted_at, s.started_at), 1, 7) AS ym, COUNT(*) AS n,
           SUM(CASE WHEN s.status = 'approved' THEN 1 ELSE 0 END) AS approved,
           SUM(CASE WHEN s.status = 'rejected' THEN 1 ELSE 0 END) AS rejected
    FROM test_sessions s
    GROUP BY ym ORDER BY ym
  `).all();

  const byManufacturer = db.prepare(`
    SELECT i.manufacturer AS name, COUNT(*) AS tests,
           SUM(CASE WHEN s.status = 'approved' THEN 1 ELSE 0 END) AS approved,
           SUM(CASE WHEN s.status = 'rejected' THEN 1 ELSE 0 END) AS rejected
    FROM test_sessions s JOIN instruments i ON i.id = s.instrument_id
    GROUP BY i.manufacturer ORDER BY tests DESC LIMIT 8
  `).all();

  // --- VITIUM analytics additions ---
  const byType = db.prepare(`
    SELECT COALESCE(NULLIF(i.instrument_type, ''), 'Other') AS name, COUNT(*) AS tests,
           SUM(CASE WHEN s.status = 'approved' THEN 1 ELSE 0 END) AS approved,
           SUM(CASE WHEN s.status = 'rejected' THEN 1 ELSE 0 END) AS rejected
    FROM test_sessions s JOIN instruments i ON i.id = s.instrument_id
    GROUP BY name ORDER BY tests DESC
  `).all();

  const engineerWorkload = db.prepare(`
    SELECT u.full_name AS name,
           COUNT(*) AS tests,
           SUM(CASE WHEN s.status = 'approved' THEN 1 ELSE 0 END) AS approved,
           SUM(CASE WHEN s.status = 'rejected' THEN 1 ELSE 0 END) AS rejected,
           SUM(CASE WHEN s.status IN ('draft','in_progress') THEN 1 ELSE 0 END) AS open
    FROM test_sessions s JOIN users u ON u.id = s.engineer_id
    GROUP BY s.engineer_id ORDER BY tests DESC LIMIT 10
  `).all();

  // Failure reasons from rejection comments (approver text) — top 5
  const failureReasons = db.prepare(`
    SELECT COALESCE(NULLIF(TRIM(a.comment), ''), 'Unspecified reason') AS reason, COUNT(*) AS count
    FROM approvals a
    WHERE a.decision = 'rejected'
    GROUP BY reason ORDER BY count DESC LIMIT 5
  `).all();

  // Overall counts
  const totals = db.prepare(`
    SELECT COUNT(*) AS totalTests,
           SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS approved,
           SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) AS rejected,
           SUM(CASE WHEN status = 'submitted' THEN 1 ELSE 0 END) AS pending,
           SUM(CASE WHEN status IN ('draft','in_progress') THEN 1 ELSE 0 END) AS open
    FROM test_sessions WHERE status != 'draft' OR 1=1
  `).get();

  // Trend alerts: instruments repeatedly failing (statistical alert, not a verdict)
  const failRows = db.prepare(`
    SELECT s.instrument_id, i.name, i.instrument_code, i.serial_number,
           COUNT(*) AS recentTests,
           SUM(CASE WHEN s.status = 'rejected' THEN 1 ELSE 0 END) AS rejections
    FROM test_sessions s JOIN instruments i ON i.id = s.instrument_id
    WHERE s.id IN (SELECT id FROM test_sessions ORDER BY id DESC LIMIT 50)
    GROUP BY s.instrument_id
    HAVING rejections >= 2 AND rejections * 2 >= recentTests
    ORDER BY rejections DESC LIMIT 5
  `).all();
  const trendAlerts = failRows.map((r) => {
    const lastRejection = db.prepare(`
      SELECT a.comment FROM approvals a
      JOIN test_sessions s ON s.id = a.session_id
      WHERE s.instrument_id = ? AND a.decision = 'rejected' AND a.comment IS NOT NULL AND TRIM(a.comment) != ''
      ORDER BY a.signed_at DESC LIMIT 1
    `).get(r.instrument_id);
    return {
      instrumentId: r.instrument_id,
      name: r.name,
      code: r.instrument_code,
      serialNumber: r.serial_number,
      recentTests: r.recentTests,
      rejections: r.rejections,
      reason: lastRejection?.comment || 'Repeated rejection pattern',
    };
  });

  // Certificate expiry trend (next 6 months)
  const expiryTrend = db.prepare(`
    SELECT substr(certificate_expiry, 1, 7) AS ym, COUNT(*) AS n
    FROM instruments
    WHERE certificate_expiry IS NOT NULL AND certificate_expiry >= date('now')
      AND certificate_expiry < date('now', '+6 months')
    GROUP BY ym ORDER BY ym
  `).all();

  res.json({ passByClass, perMonth, byManufacturer, byType, engineerWorkload, failureReasons, totals, trendAlerts, expiryTrend });
});

/* ================= Notifications ================= */
function notifyRole(db, role, type, severity, title, detail, link) {
  db.prepare('INSERT INTO notifications (role_scope, type, severity, title, detail, link) VALUES (?, ?, ?, ?, ?, ?)')
    .run(role, type, severity, title, detail || null, link || null);
}

function notifyUser(db, userId, type, severity, title, detail, link) {
  db.prepare('INSERT INTO notifications (user_id, type, severity, title, detail, link) VALUES (?, ?, ?, ?, ?, ?)')
    .run(userId, type, severity, title, detail || null, link || null);
}

r.get('/notifications', requireAuth, (req, res) => {
  const items = [];

  // Persistent notifications targeted at this user or their role
  // NOTE: parenthesized compound SELECT is a syntax error in SQLite — keep the flat OR form
  const rows = db.prepare('SELECT * FROM notifications WHERE user_id = ? OR (role_scope = ? AND user_id IS NULL) ORDER BY created_at DESC, id DESC LIMIT 100')
    .all(req.user.sub, req.user.role);
  for (const n of rows) {
    items.push({ id: `ntf-${n.id}`, dbId: n.id, type: n.type, severity: n.severity, title: n.title, detail: n.detail, link: n.link, read: !!n.read, createdAt: n.created_at, dismissible: true });
  }

  // Derived: pending approvals (approver/admin)
  if (req.user.role === 'approver' || req.user.role === 'admin') {
    const pending = db.prepare(`
      SELECT s.id, s.submitted_at, i.name AS instrument_name, i.serial_number, u.full_name AS engineer_name
      FROM test_sessions s
      JOIN instruments i ON i.id = s.instrument_id
      JOIN users u ON u.id = s.engineer_id
      WHERE s.status = 'submitted'
      ORDER BY s.submitted_at ASC
    `).all();
    for (const p of pending) {
      items.push({
        type: 'pending_approval', severity: 'info',
        title: `Session #${String(p.id).padStart(4, '0')} awaiting review`,
        detail: `${p.instrument_name} (${p.serial_number}) · ${p.engineer_name} · ${p.submitted_at?.slice(0, 16).replace('T', ' ')}`,
        link: `/sessions/${p.id}`,
      });
    }
  }

  // Derived: certificate expiry + re-verification reminders
  const today = new Date();
  let instRows;
  if (req.user.role === 'business') {
    instRows = db.prepare('SELECT * FROM instruments').all().filter((i) => canAccessInstrument(req.user, i));
  } else {
    instRows = db.prepare('SELECT * FROM instruments').all();
  }
  const dismissed = req.user.role === 'admin'
    ? db.prepare('SELECT instrument_id, type FROM notification_backlog WHERE dismissed = 1').all().map((r) => `${r.instrument_id}:${r.type}`)
    : [];
  for (const inst of instRows) {
    if (inst.certificate_expiry) {
      const days = Math.ceil((new Date(inst.certificate_expiry + 'T00:00:00') - today) / 86400000);
      if (days <= 90 && (req.user.role !== 'admin' || !dismissed.includes(`${inst.id}:cert_expiry`))) {
        items.push({
          type: 'cert_expiry', severity: days < 0 ? 'danger' : days <= 30 ? 'warning' : 'info',
          title: days < 0 ? `Certificate expired for ${inst.name}` : `Certificate expires in ${days} day${days === 1 ? '' : 's'}`,
          detail: `${inst.instrument_code || inst.name} (${inst.serial_number}) · valid until ${inst.certificate_expiry}`,
          link: `/instruments/${inst.id}`, instrumentId: inst.id,
        });
      }
    }
    if (inst.last_passed_at && req.user.role !== 'business') {
      const passed = new Date(String(inst.last_passed_at).slice(0, 10) + 'T00:00:00');
      const due = new Date(passed);
      due.setMonth(due.getMonth() + (inst.reverify_due_months || 12));
      const days = Math.ceil((due - today) / 86400000);
      if (days <= 60 && (req.user.role !== 'admin' || !dismissed.includes(`${inst.id}:reverify`))) {
        items.push({
          type: 'reverify', severity: days < 0 ? 'danger' : days <= 30 ? 'warning' : 'info',
          title: days < 0 ? `Re-verification overdue for ${inst.name}` : `Re-verification due in ${days} day${days === 1 ? '' : 's'}`,
          detail: `${inst.name} (${inst.serial_number}) · last passed ${inst.last_passed_at.slice(0, 10)} · ${inst.reverify_due_months}-month cycle`,
          link: `/instruments/${inst.id}`, instrumentId: inst.id,
        });
      }
    }
  }

  const order = { danger: 0, warning: 1, info: 2 };
  items.sort((a, b) => (order[a.severity] - order[b.severity]) || String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
  res.json({ notifications: items, unread: items.filter((i) => i.read === false).length });
});

r.post('/notifications/:dbId/read', requireAuth, (req, res) => {
  db.prepare('UPDATE notifications SET read = 1 WHERE id = ? AND (user_id = ? OR role_scope = ?)')
    .run(req.params.dbId, req.user.sub, req.user.role);
  res.json({ ok: true });
});

r.post('/notifications/read-all', requireAuth, (req, res) => {
  db.prepare('UPDATE notifications SET read = 1 WHERE user_id = ? OR role_scope = ?').run(req.user.sub, req.user.role);
  res.json({ ok: true });
});

r.post('/notifications/dismiss', requireAuth, authorize('admin'), (req, res) => {
  const { instrumentId, type } = req.body || {};
  if (!instrumentId || !type) return res.status(400).json({ error: 'instrumentId and type are required' });
  db.prepare('INSERT INTO notification_backlog (instrument_id, type, due_at, dismissed) VALUES (?, ?, datetime("now"), 1)')
    .run(instrumentId, type);
  res.json({ ok: true });
});

/* ================= Session location (explicit capture only) ================= */
r.put('/sessions/:id/location', requireAuth, authorize('engineer', 'admin'), (req, res) => {
  const session = db.prepare('SELECT * FROM test_sessions WHERE id = ?').get(req.params.id);
  if (!session) return res.status(404).json({ error: 'Session not found' });
  if (!assertSessionOwnership(req, res, session)) return;
  if (!['draft', 'in_progress'].includes(session.status)) {
    return res.status(409).json({ error: `Session is ${session.status} and can no longer be edited` });
  }
  const b = req.body || {};
  const lat = b.latitude != null ? Number(b.latitude) : null;
  const lng = b.longitude != null ? Number(b.longitude) : null;
  if (b.manual && !b.locationText?.trim()) {
    return res.status(400).json({ error: 'Please enter the inspection location manually' });
  }
  if (lat !== null && (lat < -90 || lat > 90)) return res.status(400).json({ error: 'Latitude must be between -90 and 90' });
  if (lng !== null && (lng < -180 || lng > 180)) return res.status(400).json({ error: 'Longitude must be between -180 and 180' });
  db.prepare(`
    UPDATE test_sessions SET latitude = ?, longitude = ?, location_accuracy = ?,
      location_captured_at = datetime('now'), location_text = ? WHERE id = ?
  `).run(lat, lng, b.accuracy != null ? Number(b.accuracy) : null, String(b.locationText || '').trim(), session.id);
  audit(db, req, 'location captured', 'session', session.id, `Session #${String(session.id).padStart(4, '0')}`, { next: { lat, lng, manual: !!b.manual } });
  res.json({ session: db.prepare(`${SESSION_SELECT} WHERE s.id = ?`).get(session.id) });
});

/* ================= Files (photos & documents) ================= */
const ALLOWED_MIME = [
  'image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/heic',
  'application/pdf', 'text/plain', 'text/csv',
  'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
];
const MAX_FILE_BYTES = 10 * 1024 * 1024;

const DOC_TYPES = ['instrument_photo', 'nameplate_photo', 'seal_photo', 'test_setup_photo', 'test_result_photo', 'calibration_document', 'previous_certificate', 'supporting_document', 'other'];

function rawBody(req, res, next) {
  // Raw bytes for any content type — the handler stores req.body as a Buffer.
  // (This previously used express.json, which neither parsed binary nor ever
  // produced a Buffer, so every upload failed.)
  express.raw({ limit: MAX_FILE_BYTES + 256 * 1024, type: () => true })(req, res, next);
}

r.post('/sessions/:id/files', requireAuth, authorize('engineer', 'admin'), rawBody, (req, res) => {
  const session = db.prepare('SELECT * FROM test_sessions WHERE id = ?').get(req.params.id);
  if (!session) return res.status(404).json({ error: 'Session not found' });
  if (!assertSessionOwnership(req, res, session)) return;
  if (!['draft', 'in_progress'].includes(session.status)) {
    return res.status(409).json({ error: `Session is ${session.status} and can no longer be edited` });
  }
  const fileName = String(req.headers['x-file-name'] || 'upload.bin').slice(0, 200);
  const mime = String(req.headers['content-type'] || 'application/octet-stream');
  const docType = DOC_TYPES.includes(String(req.headers['x-doc-type'])) ? String(req.headers['x-doc-type']) : 'other';
  const kind = mime.startsWith('image/') ? 'photo' : 'document';
  const buf = req.body && Buffer.isBuffer(req.body) ? req.body : Buffer.concat([]);
  if (!buf.length) return res.status(400).json({ error: 'Empty file' });
  if (buf.length > MAX_FILE_BYTES) return res.status(413).json({ error: 'File exceeds the 10 MB limit' });
  if (!ALLOWED_MIME.includes(mime)) {
    return res.status(415).json({ error: `File type ${mime} is not allowed. Images, PDF, text and Office documents only.` });
  }
  const out = db.prepare(`
    INSERT INTO files (instrument_id, session_id, module_key, kind, doc_type, file_name, mime_type, size_bytes, data, uploaded_by)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(session.instrument_id, session.id, String(req.headers['x-module-key'] || '').slice(0, 40) || null, kind, docType, fileName, mime, buf.length, buf, req.user.sub);
  audit(db, req, kind === 'photo' ? 'photo uploaded' : 'document uploaded', 'session', session.id, `Session #${String(session.id).padStart(4, '0')} · ${fileName}`, { next: { fileId: Number(out.lastInsertRowid), docType } });
  res.status(201).json({ file: { id: Number(out.lastInsertRowid), kind, docType, fileName, mime, size: buf.length } });
});

r.post('/instruments/:id/files', requireAuth, authorize('admin', 'engineer'), rawBody, (req, res) => {
  const inst = db.prepare('SELECT * FROM instruments WHERE id = ?').get(req.params.id);
  if (!inst) return res.status(404).json({ error: 'Instrument not found' });
  const fileName = String(req.headers['x-file-name'] || 'upload.bin').slice(0, 200);
  const mime = String(req.headers['content-type'] || 'application/octet-stream');
  const docType = DOC_TYPES.includes(String(req.headers['x-doc-type'])) ? String(req.headers['x-doc-type']) : 'other';
  const kind = mime.startsWith('image/') ? 'photo' : 'document';
  const buf = req.body && Buffer.isBuffer(req.body) ? req.body : Buffer.concat([]);
  if (!buf.length) return res.status(400).json({ error: 'Empty file' });
  if (buf.length > MAX_FILE_BYTES) return res.status(413).json({ error: 'File exceeds the 10 MB limit' });
  if (!ALLOWED_MIME.includes(mime)) {
    return res.status(415).json({ error: `File type ${mime} is not allowed. Images, PDF, text and Office documents only.` });
  }
  const out = db.prepare(`
    INSERT INTO files (instrument_id, kind, doc_type, file_name, mime_type, size_bytes, data, uploaded_by)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(inst.id, kind, docType, fileName, mime, buf.length, buf, req.user.sub);
  audit(db, req, 'document uploaded', 'instrument', inst.id, `${inst.name} · ${fileName}`, { next: { fileId: Number(out.lastInsertRowid), docType } });
  res.status(201).json({ file: { id: Number(out.lastInsertRowid), kind, docType, fileName, mime, size: buf.length } });
});

r.get('/files/:id', requireAuth, (req, res) => {
  const f = db.prepare('SELECT * FROM files WHERE id = ?').get(req.params.id);
  if (!f) return res.status(404).json({ error: 'File not found' });
  if (req.user.role === 'business') {
    const inst = db.prepare('SELECT * FROM instruments WHERE id = ?').get(f.instrument_id);
    if (!inst || !canAccessInstrument(req.user, inst)) return res.status(403).json({ error: 'Forbidden' });
  }
  res.setHeader('Content-Type', f.mime_type);
  res.setHeader('Content-Disposition', `inline; filename="${f.file_name.replace(/"/g, '')}"`);
  res.setHeader('Content-Length', f.data.length);
  res.end(f.data);
});

r.delete('/files/:id', requireAuth, authorize('admin', 'engineer'), (req, res) => {
  const f = db.prepare('SELECT id, file_name, session_id, instrument_id, uploaded_by FROM files WHERE id = ?').get(req.params.id);
  if (!f) return res.status(404).json({ error: 'File not found' });
  if (req.user.role === 'engineer' && f.uploaded_by !== req.user.sub) {
    return res.status(403).json({ error: 'You can only delete files you uploaded' });
  }
  db.prepare('DELETE FROM files WHERE id = ?').run(f.id);
  audit(db, req, 'document deleted', f.session_id ? 'session' : 'instrument', f.session_id || f.instrument_id, f.file_name, { prev: { fileId: f.id } });
  res.json({ ok: true });
});

/* ================= MPE rules (admin view) ================= */
r.get('/mpe-rules', requireAuth, (req, res) => {
  res.json(getMpeRuleMeta(db));
});

/* ================= Approval workflow ================= */
r.put('/sessions/:id/approval', requireAuth, authorize('approver', 'admin'), (req, res) => {
  const session = db.prepare('SELECT * FROM test_sessions WHERE id = ?').get(req.params.id);
  if (!session) return res.status(404).json({ error: 'Session not found' });
  if (session.status !== 'submitted') {
    return res.status(409).json({ error: `Only submitted sessions can be reviewed (current: ${session.status})` });
  }
  if (req.user.role === 'admin' && session.engineer_id === req.user.sub) {
    return res.status(403).json({ error: 'You cannot verify your own test — independent review is required' });
  }
  const { decision, comment, signature, signatureType, correctionRequest } = req.body || {};
  if (correctionRequest) {
    // Request correction: back to engineer as in_progress with the comment
    if (!comment?.trim()) return res.status(400).json({ error: 'Please describe the correction requested' });
    db.prepare("UPDATE test_sessions SET status = 'in_progress' WHERE id = ?").run(session.id);
    db.prepare('INSERT INTO approvals (session_id, approver_id, decision, comment, signature, signed_at) VALUES (?, ?, ?, ?, NULL, ?)')
      .run(session.id, req.user.sub, 'rejected', `[Correction requested] ${comment.trim()}`, new Date().toISOString().slice(0, 19).replace('T', ' '));
    audit(db, req, 'correction requested', 'session', session.id, `Session #${String(session.id).padStart(4, '0')}`, { next: { comment } });
    notifyUser(db, session.engineer_id, 'correction_requested', 'warning', `Correction requested on Session #${String(session.id).padStart(4, '0')}`, comment.trim(), `/sessions/${session.id}`);
    const payload = sessionPayload(session.id);
    return res.json({ session: payload.session, approval: payload.approval, evaluation: payload.evaluation });
  }
  if (!['approved', 'rejected'].includes(decision)) {
    return res.status(400).json({ error: 'decision must be "approved" or "rejected"' });
  }
  if (decision === 'rejected' && !comment?.trim()) {
    return res.status(400).json({ error: 'A rejection reason is required' });
  }
  if (decision === 'approved' && !signature?.trim()) {
    return res.status(400).json({ error: 'Approval requires a digital signature' });
  }
  const stamp = new Date().toISOString().slice(0, 19).replace('T', ' ');
  const payloadPre = sessionPayload(session.id);
  const snapshot = JSON.stringify({
    evaluation: payloadPre.evaluation,
    tests: payloadPre.tests,
    instrument: { code: payloadPre.instrument.instrument_code, class: payloadPre.instrument.accuracy_class, e: payloadPre.instrument.verification_scale_interval, max: payloadPre.instrument.max_capacity_kg },
    standard: getMpeRuleMeta(db).source,
    signedAt: stamp,
    signer: { id: req.user.sub, name: req.user.name, role: req.user.role, signatureType: signatureType || 'stored' },
  });
  db.prepare('INSERT INTO approvals (session_id, approver_id, decision, comment, signature, signed_at, evaluation_snapshot) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .run(session.id, req.user.sub, decision, comment || null, signature || null, stamp, snapshot);
  const newStatus = decision === 'approved' ? 'approved' : 'rejected';
  db.prepare('UPDATE test_sessions SET status = ?, approved_at = ? WHERE id = ?').run(newStatus, stamp, session.id);
  // Assign the public verification id now so the certificate's QR/verify link
  // works immediately (the boot backfill only covers pre-existing rows).
  if (newStatus === 'approved' && !session.report_uid) {
    db.prepare("UPDATE test_sessions SET report_uid = lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-a' || substr(hex(randomblob(3)),2) || '-' || hex(randomblob(6))) WHERE id = ? AND report_uid IS NULL")
      .run(session.id);
  }

  let certificate = null;
  if (decision === 'approved') {
    db.prepare(`
      UPDATE instruments SET last_passed_at = (
        SELECT MAX(approved_at) FROM test_sessions WHERE instrument_id = ? AND status = 'approved'
      ), last_verification_date = ? WHERE id = ?
    `).run(session.instrument_id, stamp.slice(0, 10), session.instrument_id);
    // Auto-generate the verification certificate (idempotent per session)
    const existing = db.prepare('SELECT * FROM certificates WHERE session_id = ?').get(session.id);
    if (!existing) {
      const inst = db.prepare('SELECT * FROM instruments WHERE id = ?').get(session.instrument_id);
      const number = certificateNumber(db);
      const { validUntil } = certificateValidity(stamp.slice(0, 10), 12);
      db.prepare('INSERT INTO certificates (cert_number, session_id, instrument_id, issued_at, valid_until, verifier_id) VALUES (?, ?, ?, ?, ?, ?)')
        .run(number, session.id, session.instrument_id, stamp, validUntil, req.user.sub);
      db.prepare('UPDATE instruments SET certificate_number = ?, certificate_expiry = ? WHERE id = ?')
        .run(number, validUntil, session.instrument_id);
      certificate = db.prepare('SELECT * FROM certificates WHERE session_id = ?').get(session.id);
      audit(db, req, 'certificate generated', 'certificate', certificate.id, number, { next: { sessionId: session.id, validUntil } });
      notifyUser(db, session.engineer_id, 'certificate_generated', 'info', `Certificate ${number} issued`, `Session #${String(session.id).padStart(4, '0')} approved — valid until ${validUntil}`, `/sessions/${session.id}/report`);
    }
  } else {
    audit(db, req, 'rejected', 'session', session.id, `Session #${String(session.id).padStart(4, '0')}`, { next: { reason: comment } });
    notifyUser(db, session.engineer_id, 'test_rejected', 'danger', `Session #${String(session.id).padStart(4, '0')} rejected`, comment.trim(), `/sessions/${session.id}`);
  }
  audit(db, req, decision === 'approved' ? 'approved' : 'rejected', 'session', session.id, `Session #${String(session.id).padStart(4, '0')}`, { next: { decision, signatureType: signatureType || 'stored' } });
  audit(db, req, 'signed', 'session', session.id, `Session #${String(session.id).padStart(4, '0')}`, { next: { signer: req.user.name, role: req.user.role, type: signatureType || 'stored', at: stamp } });
  const payload = sessionPayload(session.id);
  res.json({ session: payload.session, approval: payload.approval, evaluation: payload.evaluation, certificate });
});

// Tester action on a rejected session: back to work
r.put('/sessions/:id/reopen', requireAuth, authorize('engineer', 'admin'), (req, res) => {
  const session = db.prepare('SELECT * FROM test_sessions WHERE id = ?').get(req.params.id);
  if (!session) return res.status(404).json({ error: 'Session not found' });
  if (session.status !== 'rejected') {
    return res.status(409).json({ error: `Only rejected sessions can be reopened (current: ${session.status})` });
  }
  db.prepare("UPDATE test_sessions SET status = 'in_progress' WHERE id = ?").run(session.id);
  res.json({ session: db.prepare(`${SESSION_SELECT} WHERE s.id = ?`).get(session.id) });
});

/* ================= Certificates ================= */
r.get('/certificates', requireAuth, (req, res) => {
  let sql = `SELECT c.*, u.full_name AS verifier_name, i.name AS instrument_name, i.instrument_code,
    i.serial_number, i.manufacturer, i.model, i.instrument_type, i.accuracy_class, i.owner_name
    FROM certificates c
    JOIN instruments i ON i.id = c.instrument_id
    LEFT JOIN users u ON u.id = c.verifier_id`;
  const vals = [];
  if (req.user.role === 'business') {
    sql += ' WHERE ' + businessScopeSql(req.user).clause.replace(/i\./g, 'i.');
    vals.push(...businessScopeSql(req.user).vals);
  }
  sql += ' ORDER BY c.issued_at DESC';
  const rows = db.prepare(sql).all(...vals).map((c) => ({ ...c, ...certStatus(c.valid_until) }));
  res.json({ certificates: rows });
});

// One certificate + full payload for the printable/PDF view (public via UID too)
r.get('/certificates/:id', requireAuth, (req, res) => {
  const c = db.prepare(`SELECT c.*, u.full_name AS verifier_name FROM certificates c LEFT JOIN users u ON u.id = c.verifier_id WHERE c.id = ?`).get(req.params.id);
  if (!c) return res.status(404).json({ error: 'Certificate not found' });
  const payload = sessionPayload(c.session_id);
  if (!payload) return res.status(404).json({ error: 'Session not found' });
  if (!canAccessInstrument(req.user, payload.instrument)) return res.status(403).json({ error: 'Forbidden' });
  res.json({ certificate: { ...c, ...certStatus(c.valid_until) }, ...payload });
});

// Audit trail: admins see everything; other roles see their own actions
r.get('/audit', requireAuth, authorize('admin'), (req, res) => {
  const { q, action, limit } = req.query;
  let sql = `SELECT a.*, u.full_name AS user_name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id WHERE 1=1`;
  const vals = [];
  if (q) { sql += ' AND (a.object_label LIKE ? OR a.detail LIKE ? OR u.full_name LIKE ?)'; const like = `%${q}%`; vals.push(like, like, like); }
  if (action) { sql += ' AND a.action = ?'; vals.push(String(action)); }
  sql += ' ORDER BY a.id DESC LIMIT ?';
  vals.push(Number(limit) > 0 ? Math.min(Number(limit), 500) : 200);
  res.json({ logs: db.prepare(sql).all(...vals) });
});

/* ================= Reports ================= */
r.get('/reports', requireAuth, (req, res) => {
  let sql = `SELECT s.id, s.status, s.submitted_at, s.approved_at, i.name AS instrument_name,
           i.instrument_code, i.serial_number, i.instrument_type, i.manufacturer, i.accuracy_class,
           u.full_name AS engineer_name, s.report_uid,
           a.decision, a.comment, a.signature, a.signed_at,
           c.id AS cert_id, c.cert_number, c.valid_until
    FROM test_sessions s
    JOIN instruments i ON i.id = s.instrument_id
    JOIN users u ON u.id = s.engineer_id
    LEFT JOIN approvals a ON a.id = (
      SELECT a2.id FROM approvals a2 WHERE a2.session_id = s.id
      ORDER BY a2.signed_at DESC, a2.id DESC LIMIT 1
    )
    LEFT JOIN certificates c ON c.session_id = s.id
    WHERE s.status IN ('approved','rejected')`;
  const vals = [];
  if (req.user.role === 'business') {
    const scope = businessScopeSql(req.user);
    sql += ` AND ${scope.clause}`;
    vals.push(...scope.vals);
  }
  const { q, status: st, decision, from, to } = req.query;
  if (q) {
    sql += ` AND (i.name LIKE ? OR i.serial_number LIKE ? OR i.instrument_code LIKE ? OR u.full_name LIKE ? OR i.manufacturer LIKE ? OR c.cert_number LIKE ?)`;
    const like = `%${q}%`;
    vals.push(like, like, like, like, like, like);
  }
  if (st) { sql += ' AND s.status = ?'; vals.push(String(st)); }
  if (decision) { sql += ' AND a.decision = ?'; vals.push(String(decision)); }
  if (from) { sql += " AND COALESCE(s.approved_at, s.submitted_at) >= ?"; vals.push(String(from)); }
  if (to) { sql += " AND COALESCE(s.approved_at, s.submitted_at) <= ?"; vals.push(String(to) + (String(to).length === 10 ? ' 23:59:59' : '')); }
  sql += ' ORDER BY COALESCE(s.approved_at, s.submitted_at) DESC';
  res.json({ reports: db.prepare(sql).all(...vals) });
});

/* ================= Users (admin only) ================= */
r.get('/users', requireAuth, authorize('admin'), (req, res) => {
  const rows = db.prepare('SELECT * FROM users ORDER BY full_name').all();
  res.json({ users: rows.map(publicUser) });
});

r.post('/users', requireAuth, authorize('admin'), (req, res) => {
  const { fullName, email, password, role } = req.body || {};
  if (!fullName || !email || !password || !role) return res.status(400).json({ error: 'fullName, email, password and role are required' });
  if (!ROLES.includes(role)) return res.status(400).json({ error: 'Invalid role' });
  if (String(password).length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
  try {
    const hash = bcrypt.hashSync(String(password), 10);
    const out = db.prepare('INSERT INTO users (full_name, email, password_hash, role, email_verified) VALUES (?, ?, ?, ?, 1)')
      .run(String(fullName).trim(), String(email).trim().toLowerCase(), hash, role);
    const u = db.prepare('SELECT * FROM users WHERE id = ?').get(Number(out.lastInsertRowid));
    res.status(201).json({ user: publicUser(u) });
  } catch (e) {
    if (String(e).includes('UNIQUE')) return res.status(409).json({ error: 'A user with this email already exists' });
    throw e;
  }
});

r.patch('/users/:id', requireAuth, authorize('admin'), (req, res) => {
  const target = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!target) return res.status(404).json({ error: 'User not found' });
  const updates = [];
  const vals = [];
  if (req.body) {
    if (req.body.fullName !== undefined) { updates.push('full_name = ?'); vals.push(String(req.body.fullName).trim()); }
    if (req.body.role !== undefined) {
      if (!ROLES.includes(req.body.role)) return res.status(400).json({ error: 'Invalid role' });
      updates.push('role = ?'); vals.push(req.body.role);
    }
    if (req.body.ownerOf !== undefined) {
      updates.push('owner_of = ?'); vals.push(String(req.body.ownerOf));
    }
    if (req.body.active !== undefined) {
      if (target.id === req.user.sub && req.body.active === 0) return res.status(400).json({ error: 'You cannot disable your own account' });
      updates.push('active = ?'); vals.push(req.body.active ? 1 : 0);
    }
  }
  if (!updates.length) return res.status(400).json({ error: 'No valid fields to update' });
  vals.push(target.id);
  db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`).run(...vals);
  res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(target.id)) });
});

/* ================= Settings (admin) ================= */
r.get('/settings', requireAuth, authorize('admin'), (req, res) => {
  let row = db.prepare('SELECT * FROM org_settings WHERE id = 1').get();
  if (!row) {
    db.prepare(`INSERT INTO org_settings (id) VALUES (1)`).run();
    row = db.prepare('SELECT * FROM org_settings WHERE id = 1').get();
  }
  res.json({ settings: row });
});

r.put('/settings', requireAuth, authorize('admin'), (req, res) => {
  const b = req.body || {};
  const fields = {
    org_name: b.orgName,
    certificate_footer: b.certificateFooter,
    default_pass_rate_target: b.defaultPassRateTarget,
  };
  const sets = [];
  const vals = [];
  for (const [col, v] of Object.entries(fields)) {
    if (v !== undefined) { sets.push(`${col} = ?`); vals.push(v); }
  }
  if (!sets.length) return res.status(400).json({ error: 'No settings provided' });
  db.prepare('INSERT OR IGNORE INTO org_settings (id) VALUES (1)').run();
  db.prepare(`UPDATE org_settings SET ${sets.join(', ')} WHERE id = 1`).run(...vals);
  res.json({ settings: db.prepare('SELECT * FROM org_settings WHERE id = 1').get() });
});

export default r;
