// ============================================================
// MPE (Maximum Permissible Error) Engine — OIML R 76-1
// Rules live in the database (mpe_rules + mpe_params) so they
// can be updated/extended later without code changes.
//
// Layout mirrors R 76-1 tables T.1–T.4:
//   class I    : ±0.5e  < 50,000e ; ±1e ≥ 50,000e
//   class II   : ±0.5e  < 5,000e ; ±1e < 20,000e ; ±1.5e ≥ 20,000e
//   class III  : ±0.5e  < 500e  ; ±1e < 2,000e  ; ±1.5e ≥ 2,000e
//   class IIII : ±0.5e  < 50e   ; ±1e < 200e    ; ±1.5e ≥ 200e
// "mpe less than" means "not less than" in the standard, hence >=
// at the upper boundary of each band.
// ============================================================

import { openDb, migrate } from './db.js';

export const MPE_DEFAULT_RULES = [
  { class: 'I',    fromE: 0,     toE: 50000,  mpeE: 0.5 },
  { class: 'I',    fromE: 50000, toE: null,   mpeE: 1 },
  { class: 'II',   fromE: 0,     toE: 5000,   mpeE: 0.5 },
  { class: 'II',   fromE: 5000,  toE: 20000,  mpeE: 1 },
  { class: 'II',   fromE: 20000, toE: null,   mpeE: 1.5 },
  { class: 'III',  fromE: 0,     toE: 500,    mpeE: 0.5 },
  { class: 'III',  fromE: 500,   toE: 2000,   mpeE: 1 },
  { class: 'III',  fromE: 2000,  toE: null,   mpeE: 1.5 },
  { class: 'IIII', fromE: 0,     toE: 50,     mpeE: 0.5 },
  { class: 'IIII', fromE: 50,    toE: 200,    mpeE: 1 },
  { class: 'IIII', fromE: 200,   toE: null,   mpeE: 1.5 },
];

export const MPE_DEFAULT_PARAMS = [
  { key: 'eccentricity_fraction', value: 1 / 3 },
  { key: 'repeatability_load_fractions', value: '0.5,0.9' },
  { key: 'repeatability_i_readings', value: 6 },
  { key: 'repeatability_ii_readings', value: 6 },
  { key: 'repeatability_iii_readings', value: 3 },
  { key: 'repeatability_iiii_readings', value: 3 },
  { key: 'discrimination_extra_low', value: 1.4 },
  { key: 'discrimination_extra_high', value: 2 },
  { key: 'eccentricity_mpe_factor', value: 1 },
];

export function ensureMpeRules(db) {
  const n = db.prepare('SELECT COUNT(*) AS n FROM mpe_rules').get().n;
  if (n === 0) {
    const ins = db.prepare('INSERT INTO mpe_rules (class, from_e, to_e, mpe_e) VALUES (?, ?, ?, ?)');
    for (const r of MPE_DEFAULT_RULES) ins.run(r.class, r.fromE, r.toE, r.mpeE);
  }
  const p = db.prepare('SELECT COUNT(*) AS n FROM mpe_params').get().n;
  if (p === 0) {
    const ins = db.prepare('INSERT INTO mpe_params (key, value) VALUES (?, ?)');
    for (const r of MPE_DEFAULT_PARAMS) ins.run(r.key, String(r.value));
  }
}

export function getMpeParams(db) {
  const rows = db.prepare('SELECT key, value FROM mpe_params').all();
  const out = {};
  for (const r of rows) {
    const v = r.value;
    const num = Number(v);
    out[r.key] = !isNaN(num) && String(num) === String(v).trim() ? num : v;
  }
  return out;
}

export function getMpeBands(db) {
  return db.prepare('SELECT class, from_e AS fromE, to_e AS toE, mpe_e AS mpeE FROM mpe_rules ORDER BY class, from_e').all();
}

// Return MPE (in units of e) for a load, reading bands from the given DB.
export function mpeInEFromDb(db, accuracyClass, loadKg, eKg) {
  const n = eKg > 0 ? loadKg / eKg : 0;
  const bands = db.prepare(
    'SELECT from_e, to_e, mpe_e FROM mpe_rules WHERE class = ? ORDER BY from_e'
  ).all(accuracyClass);
  let m = null;
  for (const b of bands) {
    const to = b.to_e === null ? Infinity : b.to_e;
    if (n >= b.from_e && n < to) { m = b.mpe_e; break; }
  }
  return m;
}

export function getMpeRuleMeta(db) {
  return {
    source: 'OIML R 76-1 (2012 edition) Annex B — MPE in verification scale intervals (e)',
    bands: getMpeBands(db),
    params: getMpeParams(db),
  };
}

export { openDb, migrate };
