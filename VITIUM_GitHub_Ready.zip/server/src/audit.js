// Append-only audit trail. Never edited by normal users; the API does not
// expose any update/delete path for these rows.

export function audit(db, req, action, objectType, objectId, objectLabel, extra = {}) {
  try {
    db.prepare(`
      INSERT INTO audit_logs (user_id, role, action, object_type, object_id, object_label, detail, prev_value, new_value)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      req?.user?.sub ?? null,
      req?.user?.role ?? null,
      action,
      objectType,
      objectId != null ? String(objectId) : null,
      objectLabel ?? null,
      extra.detail ?? null,
      extra.prev != null ? JSON.stringify(extra.prev).slice(0, 2000) : null,
      extra.next != null ? JSON.stringify(extra.next).slice(0, 2000) : null,
    );
  } catch (e) {
    // Auditing must never break the primary operation.
    console.error('[audit] failed to record', action, e.message);
  }
}

export function latestAudit(db, objectType, objectId, action) {
  const rows = db.prepare(
    'SELECT * FROM audit_logs WHERE object_type = ? AND object_id = ? AND action = ? ORDER BY id DESC LIMIT 1'
  ).all(objectType, String(objectId), action);
  return rows[0] || null;
}
