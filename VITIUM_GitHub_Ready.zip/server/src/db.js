import { DatabaseSync } from 'node:sqlite';
import bcrypt from 'bcryptjs';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

// Optional override so tests/staging can run against a scratch database
// without touching the real one (reset-seed.js and production never set it).
export const DB_PATH = process.env.VITIUM_DB_PATH
  ? path.resolve(process.env.VITIUM_DB_PATH)
  : path.join(dataDir, 'nawi.db');

export function openDb() {
  const db = new DatabaseSync(DB_PATH);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;');
  return db;
}

function columns(db, table) {
  return db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name);
}

function addColumnIfMissing(db, table, columnDef) {
  const colName = columnDef.trim().split(/\s+/)[0];
  if (!columns(db, table).includes(colName)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${columnDef}`);
  }
}

export function migrate(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      full_name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK (role IN ('engineer','approver','admin','business')),
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      email_verified INTEGER NOT NULL DEFAULT 0,
      owner_of TEXT DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS instruments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      manufacturer TEXT NOT NULL,
      model TEXT NOT NULL,
      serial_number TEXT NOT NULL UNIQUE,
      max_capacity_kg REAL NOT NULL,
      verification_scale_interval TEXT NOT NULL,
      accuracy_class TEXT NOT NULL CHECK (accuracy_class IN ('I','II','III','IIII')),
      location TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','maintenance','retired')),
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS test_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      instrument_id INTEGER NOT NULL REFERENCES instruments(id),
      engineer_id INTEGER NOT NULL REFERENCES users(id),
      reference_standard TEXT NOT NULL,
      ambient_temp_c REAL,
      ambient_humidity_pct REAL,
      status TEXT NOT NULL DEFAULT 'draft'
        CHECK (status IN ('draft','in_progress','submitted','approved','rejected')),
      started_at TEXT NOT NULL DEFAULT (datetime('now')),
      submitted_at TEXT,
      approved_at TEXT
    );

    CREATE TABLE IF NOT EXISTS approvals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id INTEGER NOT NULL REFERENCES test_sessions(id),
      approver_id INTEGER NOT NULL REFERENCES users(id),
      decision TEXT NOT NULL CHECK (decision IN ('approved','rejected')),
      comment TEXT,
      signature TEXT,
      signed_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS org_settings (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      org_name TEXT NOT NULL DEFAULT 'VITIUM',
      certificate_footer TEXT NOT NULL DEFAULT 'Issued in accordance with OIML R-76',
      default_pass_rate_target REAL NOT NULL DEFAULT 95
    );

    CREATE TABLE IF NOT EXISTS session_tests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id INTEGER NOT NULL REFERENCES test_sessions(id),
      module_key TEXT NOT NULL,
      completed INTEGER NOT NULL DEFAULT 0,
      data TEXT NOT NULL DEFAULT '{}',
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (session_id, module_key)
    );

    CREATE TABLE IF NOT EXISTS mpe_rules (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      class TEXT NOT NULL CHECK (class IN ('I','II','III','IIII')),
      from_e REAL NOT NULL,
      to_e REAL,
      mpe_e REAL NOT NULL
    );

    CREATE TABLE IF NOT EXISTS mpe_params (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
  `);

  // --- Phase 2 instrument master-data columns ---
  addColumnIfMissing(db, 'instruments', `min_capacity_kg REAL`);
  addColumnIfMissing(db, 'instruments', `actual_scale_interval TEXT DEFAULT ''`);
  addColumnIfMissing(db, 'instruments', `tare_range TEXT DEFAULT ''`);
  addColumnIfMissing(db, 'instruments', `applicant_name TEXT DEFAULT ''`);
  addColumnIfMissing(db, 'instruments', `test_lab TEXT DEFAULT ''`);
  addColumnIfMissing(db, 'instruments', `test_date TEXT DEFAULT ''`);
  addColumnIfMissing(db, 'instruments', `certificate_expiry TEXT`);
  addColumnIfMissing(db, 'instruments', `reverify_due_months INTEGER DEFAULT 12`);
  addColumnIfMissing(db, 'instruments', `last_passed_at TEXT`);

  // --- Phase 4: unique public verification id per session ---
  addColumnIfMissing(db, 'test_sessions', `report_uid TEXT`);

  // --- Phase 5: email verification (signup with OTP) ---
  if (!columns(db, 'users').includes('email_verified')) {
    db.exec('ALTER TABLE users ADD COLUMN email_verified INTEGER NOT NULL DEFAULT 0;');
    // Accounts that predate email verification are grandfathered in as verified,
    // so existing sign-ins keep working. This runs only when the column is added.
    db.exec('UPDATE users SET email_verified = 1;');
  }
  db.exec(`
    CREATE TABLE IF NOT EXISTS email_otps (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL,
      code_hash TEXT NOT NULL,
      purpose TEXT NOT NULL DEFAULT 'signup',
      expires_at TEXT NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0,
      consumed_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_email_otps_email ON email_otps(email, purpose);
  `);

  // --- Notifications backlog (calibration/re-verification reminders) ---
  db.exec(`
    CREATE TABLE IF NOT EXISTS notification_backlog (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      instrument_id INTEGER NOT NULL REFERENCES instruments(id),
      type TEXT NOT NULL,
      due_at TEXT NOT NULL,
      dismissed INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  // Derived re-verification date from real approval history (safe for all DBs)
  db.exec(`
    UPDATE instruments SET last_passed_at = (
      SELECT MAX(s.approved_at) FROM test_sessions s
      WHERE s.instrument_id = instruments.id AND s.status = 'approved'
    ) WHERE last_passed_at IS NULL;
  `);

  // Demo-only data (fake certificate expiries, an aging pass for the reminder
  // UI). Applied only when SEED_DEMO=1, i.e. `npm run seed:reset` — a normal
  // boot never fabricates dates on real instruments.
  if (seedDemoEnabled()) {
    db.exec(`
      UPDATE instruments SET certificate_expiry = date('now', '+20 days')  WHERE id = 1 AND certificate_expiry IS NULL;
      UPDATE instruments SET certificate_expiry = date('now', '+75 days')  WHERE id = 2 AND certificate_expiry IS NULL;
      UPDATE instruments SET certificate_expiry = date('now', '+200 days') WHERE id = 3 AND certificate_expiry IS NULL;
      UPDATE instruments SET certificate_expiry = date('now', '+5 days')   WHERE id = 4 AND certificate_expiry IS NULL;
      UPDATE instruments SET certificate_expiry = date('now', '+340 days') WHERE id = 5 AND certificate_expiry IS NULL;
      -- One instrument with an aging pass so a re-verification reminder fires
      UPDATE instruments SET last_passed_at = datetime('now', '-11 months', '-15 days')
        WHERE id = 4 AND last_passed_at IS NOT NULL AND last_passed_at > datetime('now', '-11 months', '-15 days');
    `);
  }

  // --- VITIUM upgrade: instrument identity (code, type, owner, geo, cert tracking) ---
  addColumnIfMissing(db, 'instruments', `instrument_code TEXT`);
  addColumnIfMissing(db, 'instruments', `instrument_type TEXT DEFAULT 'Platform Scale'`);
  addColumnIfMissing(db, 'instruments', `division TEXT DEFAULT ''`);
  addColumnIfMissing(db, 'instruments', `unit TEXT DEFAULT 'kg'`);
  addColumnIfMissing(db, 'instruments', `owner_name TEXT DEFAULT ''`);
  addColumnIfMissing(db, 'instruments', `owner_contact TEXT DEFAULT ''`);
  addColumnIfMissing(db, 'instruments', `address TEXT DEFAULT ''`);
  addColumnIfMissing(db, 'instruments', `city TEXT DEFAULT ''`);
  addColumnIfMissing(db, 'instruments', `state TEXT DEFAULT ''`);
  addColumnIfMissing(db, 'instruments', `pin_code TEXT DEFAULT ''`);
  addColumnIfMissing(db, 'instruments', `installation_date TEXT`);
  addColumnIfMissing(db, 'instruments', `last_verification_date TEXT`);
  addColumnIfMissing(db, 'instruments', `certificate_number TEXT DEFAULT ''`);
  addColumnIfMissing(db, 'instruments', `notes TEXT DEFAULT ''`);

  // Unique instrument codes (VTM-INS-000001 style) for all rows
  db.exec("UPDATE instruments SET instrument_code = 'VTM-INS-' || substr('000000' || id, -6) WHERE instrument_code IS NULL OR instrument_code = '';");
  db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_instruments_code ON instruments(instrument_code);');

  // --- VITIUM: certificates (generated on approval) ---
  db.exec(`
    CREATE TABLE IF NOT EXISTS certificates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      cert_number TEXT NOT NULL UNIQUE,
      session_id INTEGER NOT NULL REFERENCES test_sessions(id),
      instrument_id INTEGER NOT NULL REFERENCES instruments(id),
      issued_at TEXT NOT NULL DEFAULT (datetime('now')),
      valid_until TEXT,
      verifier_id INTEGER REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  // --- VITIUM: documents/photos attached to instruments or sessions ---
  db.exec(`
    CREATE TABLE IF NOT EXISTS files (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      instrument_id INTEGER REFERENCES instruments(id),
      session_id INTEGER REFERENCES test_sessions(id),
      module_key TEXT,
      kind TEXT NOT NULL DEFAULT 'document' CHECK (kind IN ('photo','document')),
      doc_type TEXT NOT NULL DEFAULT 'other',
      file_name TEXT NOT NULL,
      mime_type TEXT NOT NULL DEFAULT 'application/octet-stream',
      size_bytes INTEGER NOT NULL DEFAULT 0,
      data BLOB NOT NULL,
      uploaded_by INTEGER REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  // --- VITIUM: GPS/inspection location on sessions ---
  addColumnIfMissing(db, 'test_sessions', `latitude REAL`);
  addColumnIfMissing(db, 'test_sessions', `longitude REAL`);
  addColumnIfMissing(db, 'test_sessions', `location_accuracy REAL`);
  addColumnIfMissing(db, 'test_sessions', `location_captured_at TEXT`);
  addColumnIfMissing(db, 'test_sessions', `location_text TEXT DEFAULT ''`);

  // --- VITIUM: audit trail (append-only) ---
  db.exec(`
    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER REFERENCES users(id),
      role TEXT,
      action TEXT NOT NULL,
      object_type TEXT NOT NULL,
      object_id TEXT,
      object_label TEXT,
      detail TEXT,
      prev_value TEXT,
      new_value TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at DESC);
  `);

  // --- VITIUM: persistent notifications with read state ---
  db.exec(`
    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER REFERENCES users(id),
      role_scope TEXT,
      type TEXT NOT NULL,
      severity TEXT NOT NULL DEFAULT 'info' CHECK (severity IN ('info','warning','danger')),
      title TEXT NOT NULL,
      detail TEXT,
      link TEXT,
      read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  // --- VITIUM: configurable checklists per instrument type ---
  db.exec(`
    CREATE TABLE IF NOT EXISTS instrument_types (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      description TEXT DEFAULT '',
      purpose TEXT DEFAULT '',
      how_it_works TEXT DEFAULT '',
      specs TEXT DEFAULT '',
      test_methods TEXT DEFAULT '',
      failure_modes TEXT DEFAULT '',
      safety_notes TEXT DEFAULT '',
      modules TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  // --- VITIUM: rebrand org settings + evaluation snapshots for reproducibility ---
  db.exec("UPDATE org_settings SET org_name = 'VITIUM' WHERE org_name IN ('NAWI TestPro', 'nawitestpro');");
  addColumnIfMissing(db, 'approvals', `evaluation_snapshot TEXT`);

  // --- VITIUM: business-owner role (view-only access to own instruments) ---
  if (!columns(db, 'users').includes('owner_of')) {
    db.exec("ALTER TABLE users ADD COLUMN owner_of TEXT DEFAULT '';");
  }
  // The original users table CHECK only allows engineer/approver/admin. SQLite
  // cannot alter a CHECK constraint, so rebuild the table once, preserving all
  // rows (and any FK references, which SQLite rewrites on RENAME).
  const usersCreateSql = db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='users'").get()?.sql || '';
  if (!usersCreateSql.includes("'business'")) {
    db.exec('PRAGMA foreign_keys = OFF;');
    db.exec('BEGIN;');
    try {
      db.exec(`
        ALTER TABLE users RENAME TO users_old;
        CREATE TABLE users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          full_name TEXT NOT NULL,
          email TEXT NOT NULL UNIQUE,
          password_hash TEXT NOT NULL,
          role TEXT NOT NULL CHECK (role IN ('engineer','approver','admin','business')),
          active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL DEFAULT (datetime('now')),
          email_verified INTEGER NOT NULL DEFAULT 0,
          owner_of TEXT DEFAULT ''
        );
        INSERT INTO users (id, full_name, email, password_hash, role, active, created_at, email_verified, owner_of)
          SELECT id, full_name, email, password_hash, role, active, created_at, email_verified, owner_of FROM users_old;
        DROP TABLE users_old;
      `);
      db.exec('COMMIT;');
    } catch (e) {
      db.exec('ROLLBACK;');
      throw e;
    } finally {
      db.exec('PRAGMA foreign_keys = ON;');
    }
  }

  // --- VITIUM: repair FK references dangled by the one-time users rebuild ---
  // Renaming users → users_old made SQLite rewrite "REFERENCES users(id)" to
  // "REFERENCES users_old(id)" in every dependent table; dropping users_old
  // then left them pointing at a missing table ("no such table:
  // main.users_old" on inserts). Rebuild each affected table from its stored
  // schema with the reference corrected. Idempotent: after repair no table's
  // SQL mentions users_old, so this loop finds nothing on later boots.
  const fkBroken = db.prepare(
    "SELECT name, sql FROM sqlite_master WHERE type = 'table' AND sql LIKE '%users_old%'"
  ).all();
  for (const t of fkBroken) {
    const fixedName = `${t.name}__fkfix`;
    const indexSqls = db.prepare(
      "SELECT sql FROM sqlite_master WHERE type = 'index' AND tbl_name = ? AND sql IS NOT NULL"
    ).all(t.name);
    const createFixed = t.sql
      .replace(/^CREATE TABLE\s+("|`)?(\w+)\1/i, `CREATE TABLE ${fixedName}`)
      .replace(/users_old/g, 'users');
    db.exec('PRAGMA foreign_keys = OFF;');
    db.exec('BEGIN IMMEDIATE;');
    try {
      db.exec(createFixed);
      db.exec(`INSERT INTO ${fixedName} SELECT * FROM ${t.name};`);
      db.exec(`DROP TABLE ${t.name};`);
      db.exec(`ALTER TABLE ${fixedName} RENAME TO ${t.name};`);
      for (const idx of indexSqls) db.exec(idx.sql);
      db.exec('COMMIT;');
      console.log(`[db] repaired users FK references in table ${t.name}`);
    } catch (e) {
      db.exec('ROLLBACK;');
      throw e;
    } finally {
      db.exec('PRAGMA foreign_keys = ON;');
    }
  }

  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_version (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
  `);

  // --- Demo dataset enrichment (SEED_DEMO=1 only) ---
  // These UPDATEs used to run on every boot and would overwrite real
  // administrator edits to instruments 1-5, plus insert a demo business user
  // with a published password. Demo rows now exist only via seed(); a normal
  // boot never touches user-specific instrument identity fields.
  if (seedDemoEnabled()) {
  db.exec(`
    UPDATE instruments SET instrument_type = 'Truck Weighbridge', division = 'e = 20 kg',
      owner_name = 'Metrology Authority Demo', owner_contact = '+91 98200 11223', address = 'Plot 14, Industrial Estate',
      city = 'Chennai', state = 'Tamil Nadu', pin_code = '600001'
      WHERE id = 5 AND (instrument_type = 'Platform Scale' OR instrument_type IS NULL);
    UPDATE instruments SET instrument_type = 'Jewellery Balance', division = 'e = 1 mg',
      owner_name = 'Glow Jewellers', owner_contact = '+91 98200 44556', address = 'Shop 3, Zaveri Bazaar',
      city = 'Mumbai', state = 'Maharashtra', pin_code = '400002'
      WHERE id = 3 AND (instrument_type = 'Platform Scale' OR instrument_type IS NULL);
    UPDATE instruments SET instrument_type = 'Retail Scale', division = 'e = 5 g',
      owner_name = 'Essae Retail Mart', owner_contact = '+91 98111 77889', address = 'Store 7, Connaught Place',
      city = 'Delhi', state = 'Delhi', pin_code = '110001'
      WHERE id = 4 AND (instrument_type = 'Platform Scale' OR instrument_type IS NULL);
    UPDATE instruments SET instrument_type = 'Platform Scale', division = 'e = 100 g',
      owner_name = 'Metrology Authority Demo', owner_contact = '+91 98200 11223', address = 'Warehouse 1, MbPT Road',
      city = 'Mumbai', state = 'Maharashtra', pin_code = '400010'
      WHERE id = 1 AND (owner_name = '' OR owner_name IS NULL);
    UPDATE instruments SET instrument_type = 'Bench Scale', division = 'e = 10 g',
      owner_name = 'Ohaus Lab Supplies', owner_contact = '+91 98220 33445', address = 'Lab 2, MIDC Bhosari',
      city = 'Pune', state = 'Maharashtra', pin_code = '411026'
      WHERE id = 2 AND (owner_name = '' OR owner_name IS NULL);
    UPDATE instruments SET installation_date = date('now', '-400 days') WHERE installation_date IS NULL;
    UPDATE instruments SET certificate_number = 'VTM-CERT-' || (2025 + (id % 2)) || '-' || substr('000000' || (id * 7), -6)
      WHERE certificate_number IS NULL OR certificate_number = '';
  `);
  }

  // Derived from real approval history — safe on every boot
  db.exec(`
    UPDATE instruments SET last_verification_date = substr(last_passed_at, 1, 10)
      WHERE last_verification_date IS NULL AND last_passed_at IS NOT NULL;
  `);

  // --- VITIUM: instrument-type knowledge + checklist configuration ---
  const typeCount = db.prepare('SELECT COUNT(*) AS n FROM instrument_types').get().n;
  if (typeCount === 0) {
    const insType = db.prepare(`
      INSERT INTO instrument_types (name, description, purpose, how_it_works, specs, test_methods, failure_modes, safety_notes, modules)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    // Full checklist (truck weighbridge + platform/bench/retail): 9 modules
    const FULL = ['visual', 'zero', 'repeatability', 'eccentricity', 'weighing', 'tare', 'price', 'influence', 'discrimination'];
    const NO_PRICE = FULL.filter((k) => k !== 'price');
    // Jewellery balance: precision checklist — skip price computation;
    // discrimination & influence matter most for class I balances.
    const JEWELLERY = ['visual', 'zero', 'repeatability', 'eccentricity', 'weighing', 'discrimination', 'influence'];
    insType.run(
      'Platform Scale',
      'Medium-to-large industrial platform scale for pallets, drums and bulk goods.',
      'Legal-for-trade weighing of goods in warehouses, factories and logistics hubs.',
      'Load applied to the platform is transmitted through load cells or lever system to an indicating element; the indication is compared against certified reference masses.',
      'Capacity range 60–3000 kg · accuracy class III · e = 10 g to 10 kg',
      JSON.stringify(FULL),
      'Corner loading errors, zero drift, tare interaction, damaged load cell',
      'Keep platform clear during tests; use certified test masses with safe lifting equipment.',
      JSON.stringify(NO_PRICE)
    );
    insType.run(
      'Bench Scale',
      'Compact bench/bench-floor scale for portioning, counting and check-weighing.',
      'Trade and internal weighing of small-to-medium loads on a worktop.',
      'Electromagnetic force compensation or strain-gauge load cell converts load to a digital indication.',
      'Capacity range 3–60 kg · accuracy class III · e = 1 g to 20 g',
      JSON.stringify(NO_PRICE),
      'Zero drift with temperature, overload damage, corner errors',
      'Do not exceed Max; level the bench before testing.',
      JSON.stringify(NO_PRICE)
    );
    insType.run(
      'Retail Scale',
      'Price-computing retail scale used at point of sale.',
      'Direct sales of goods by weight where price must be computed from weight.',
      'Load cell signal is digitised; weight, unit price and computed price are displayed for the customer.',
      'Capacity range 6–30 kg · accuracy class III · e = 1 g to 10 g · price-computing',
      JSON.stringify(FULL),
      'Price computation errors, span drift, customer/customer-side display mismatch',
      'Test with vendor and customer displays visible; verify price-per-kg accuracy.',
      JSON.stringify(FULL)
    );
    insType.run(
      'Jewellery Balance',
      'High-resolution precision balance for gold, gems and precious metals.',
      'Precise mass determination for valuation and trade of precious items.',
      'Electromagnetic force restoration converts mass to force; extremely fine resolution (d = e typically).',
      'Capacity range 20 g–2 kg · accuracy class I or II · e = 1 mg to 10 mg',
      JSON.stringify(JEWELLERY),
      'Air currents & vibration influence, magnetism of samples, creep',
      'Use anti-vibration table, draft shield closed, allow full warm-up before testing.',
      JSON.stringify(JEWELLERY)
    );
    insType.run(
      'Truck Weighbridge',
      'Heavy-duty road vehicle weighbridge, pit or pitless.',
      'Legal-for-trade weighing of trucks and bulk cargo for trade and compliance.',
      'Multiple load cells under the deck sum the load; indicator shows total weight.',
      'Capacity range 30–100 t · accuracy class III · e = 5 kg to 50 kg',
      JSON.stringify(FULL),
      'Load cell failure, deck binding, water ingress in junction boxes, side-loading errors',
      'Traffic control during testing; certified test trucks or heavy masses with crane.',
      JSON.stringify(FULL)
    );
    insType.run(
      'Other Measuring Instrument',
      'Any other legal-metrology instrument configured by the administrator.',
      'Defined by the administrator.',
      'Defined by the administrator.',
      '',
      JSON.stringify(FULL),
      '',
      '',
      JSON.stringify(FULL)
    );
  }

  // Backfill sensible defaults so the calculator never sees NULLs
  db.exec(`
    UPDATE instruments SET min_capacity_kg = 0 WHERE min_capacity_kg IS NULL;
    UPDATE instruments
      SET actual_scale_interval = verification_scale_interval
      WHERE actual_scale_interval IS NULL OR actual_scale_interval = '';
    UPDATE instruments SET tare_range = '-10% Max to 0' WHERE tare_range IS NULL OR tare_range = '';
    UPDATE instruments SET reverify_due_months = 12 WHERE reverify_due_months IS NULL;
    UPDATE test_sessions SET report_uid = lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-a' || substr(hex(randomblob(3)),2) || '-' || hex(randomblob(6)))
      WHERE report_uid IS NULL;
  `);

}

export function seed(db) {
  const count = db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
  if (count > 0) return;

  const hash = (pw) => bcrypt.hashSync(pw, 10);
  const insertUser = db.prepare(
    'INSERT INTO users (full_name, email, password_hash, role, email_verified) VALUES (?, ?, ?, ?, 1)'
  );
  insertUser.run('Arun Mehta', 'engineer@nawitestpro.com', hash('engineer123'), 'engineer');
  insertUser.run('Priya Nair', 'approver@nawitestpro.com', hash('approver123'), 'approver');
  insertUser.run('Sara Khan', 'admin@nawitestpro.com', hash('admin123'), 'admin');
  insertUser.run('Dev Patel', 'dev.patel@nawitestpro.com', hash('engineer123'), 'engineer');
  insertUser.run('Rita Verma', 'rita.verma@nawitestpro.com', hash('approver123'), 'approver');
  insertUser.run('Metrology Authority Demo', 'owner@nawitestpro.com', hash('owner12345'), 'business');

  const insertInstrument = db.prepare(`
    INSERT INTO instruments
      (name, manufacturer, model, serial_number, max_capacity_kg,
       verification_scale_interval, accuracy_class, location, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  insertInstrument.run('Platform Scale A', 'Mettler Toledo', 'PTH-300', 'MT-PTH-0091', 300, 'e = 100 g', 'III', 'Warehouse 1, Mumbai', 'active');
  insertInstrument.run('Bench Scale B', 'Ohaus', 'Defender 5000', 'OH-D52-0455', 60, 'e = 10 g', 'III', 'Lab 2, Pune', 'active');
  insertInstrument.run('Jewellery Balance', 'Sartorius', 'Entris II', 'SA-EN2-1201', 0.22, 'e = 1 mg', 'I', 'Vault Lab, Mumbai', 'active');
  insertInstrument.run('Retail Scale C', 'Essae', 'DS-415', 'ES-DS415-0788', 15, 'e = 5 g', 'III', 'Store 7, Delhi', 'maintenance');
  insertInstrument.run('Truck Weighbridge', 'Avery', 'WC-60T', 'AV-WC60-0034', 60000, 'e = 20 kg', 'IIII', 'Yard 3, Chennai', 'active');

  const users = db.prepare('SELECT id, role FROM users').all();
  const engineers = users.filter((u) => u.role === 'engineer');
  const approvers = users.filter((u) => u.role === 'approver');
  const instruments = db.prepare('SELECT id FROM instruments').all();

  const insertSession = db.prepare(`
    INSERT INTO test_sessions
      (instrument_id, engineer_id, reference_standard, ambient_temp_c, ambient_humidity_pct, status,
       started_at, submitted_at, approved_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const insertApproval = db.prepare(`
    INSERT INTO approvals (session_id, approver_id, decision, comment, signature, signed_at)
    VALUES (?, ?, ?, ?, ?, ?)
  `);

  const daysAgo = (d) => {
    const t = new Date(Date.now() - d * 86400000);
    return t.toISOString().slice(0, 19).replace('T', ' ');
  };
  const REF = ['E2-1kg Certified Set', 'M1-20kg Certified Block', 'F1-500g Certified Set'];

  // History: mix of approved / rejected / submitted, spread over recent weeks
  const plan = [
    { d: 32, status: 'approved' }, { d: 28, status: 'approved' }, { d: 25, status: 'rejected' },
    { d: 21, status: 'approved' }, { d: 18, status: 'submitted' }, { d: 14, status: 'approved' },
    { d: 11, status: 'submitted' }, { d: 9, status: 'approved' }, { d: 7, status: 'rejected' },
    { d: 5, status: 'submitted' }, { d: 3, status: 'approved' }, { d: 2, status: 'submitted' },
    { d: 1, status: 'approved' }, { d: 1, status: 'in_progress' }, { d: 0, status: 'draft' },
  ];
  plan.forEach((p, i) => {
    const inst = instruments[i % instruments.length];
    const eng = engineers[i % engineers.length];
    const appr = approvers[i % approvers.length];
    const started = daysAgo(p.d);
    const submitted = p.status === 'draft' || p.status === 'in_progress' ? null : daysAgo(Math.max(0, p.d - 1));
    const approved = p.status === 'approved' || p.status === 'rejected' ? daysAgo(Math.max(0, p.d - 2)) : null;
    const s = insertSession.run(
      inst.id, eng.id, REF[i % REF.length], 22 + (i % 4), 45 + (i % 10), p.status,
      started, submitted, approved
    );
    if (approved) {
      const ok = p.status === 'approved';
      insertApproval.run(
        Number(s.lastInsertRowid), appr.id, ok ? 'approved' : 'rejected',
        ok ? 'All R-76 checks within MPE. Cleared for certificate.' : 'Eccentricity test exceeded tolerance; resubmit after adjustment.',
        ok ? `DigiSigned:${appr.id}-${p.d}` : null, approved
      );
      if (ok) {
        // last_passed_at drives the re-verification due reminder
        db.prepare('UPDATE instruments SET last_passed_at = ? WHERE id = ? AND (last_passed_at IS NULL OR last_passed_at < ?)')
          .run(approved, inst.id, approved);
      }
    }
  });
}

// Demo data (fake users, instruments, sessions) is opt-in: only
// `npm run seed:reset` sets SEED_DEMO=1. Regular boots never create or
// overwrite user-specific records.
function seedDemoEnabled() {
  return process.env.SEED_DEMO === '1';
}

// First-run bootstrap for a genuinely empty database: create the initial
// administrator from the environment. No demo accounts, no invented names —
// without these variables the app starts with zero accounts and self-signup.
function bootstrapAdmin(db) {
  const count = db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
  if (count > 0) return;
  const email = String(process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  const password = String(process.env.ADMIN_PASSWORD || '');
  if (!email || !password) {
    console.log('[db] empty database and no ADMIN_EMAIL/ADMIN_PASSWORD set — starting with no accounts (use self sign-up, or set both variables and restart)');
    return;
  }
  if (password.length < 8) {
    console.warn('[db] ADMIN_PASSWORD must be at least 8 characters — bootstrap skipped');
    return;
  }
  const name = String(process.env.ADMIN_NAME || '').trim() || 'Administrator';
  db.prepare('INSERT INTO users (full_name, email, password_hash, role, email_verified) VALUES (?, ?, ?, ?, 1)')
    .run(name, email, bcrypt.hashSync(password, 10), 'admin');
  console.log(`[db] bootstrap administrator created: ${email}`);
}

export function initDb() {
  const db = openDb();
  migrate(db);
  if (seedDemoEnabled()) seed(db);
  else bootstrapAdmin(db);
  return db;
}
