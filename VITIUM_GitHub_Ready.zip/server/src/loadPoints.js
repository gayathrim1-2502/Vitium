// OIML R-76 suggested test load points, computed from instrument master data.
// MPE bands are read from the database (configurable) via mpeEngine.

import { mpeInEFromDb } from './mpeEngine.js';

const UNIT_TO_KG = { mg: 1e-6, g: 1e-3, kg: 1, t: 1000 };

// Parse interval strings like "e = 100 g", "1 mg", "20 kg", "d=10g" -> kg number (or null)
export function parseIntervalKg(str) {
  if (str === null || str === undefined) return null;
  if (typeof str === 'number' && isFinite(str)) return str > 0 ? str : null;
  const m = String(str).trim().match(/^(?:[ed]\s*=\s*)?([0-9]*\.?[0-9]+)\s*(mg|g|kg|t)\s*$/i);
  if (!m) return null;
  const value = Number.parseFloat(m[1]);
  const unit = UNIT_TO_KG[m[2].toLowerCase()];
  const kg = value * unit;
  return kg > 0 ? kg : null;
}

const CLASS_RULES = {
  I: { breakpoints: [50000], multipliers: [0.5, 1] },
  II: { breakpoints: [5000, 20000], multipliers: [0.5, 1, 1.5] },
  III: { breakpoints: [500, 2000], multipliers: [0.5, 1, 1.5] },
  IIII: { breakpoints: [50, 200], multipliers: [0.5, 1, 1.5] },
};

// Fallback only when no DB is supplied (used by unit checks / tooling).
export function mpeInE(accuracyClass, loadKg, eKg) {
  const rule = CLASS_RULES[accuracyClass] || CLASS_RULES.III;
  const n = eKg > 0 ? loadKg / eKg : 0;
  let m = rule.multipliers[rule.multipliers.length - 1];
  for (let i = 0; i < rule.breakpoints.length; i++) {
    if (n < rule.breakpoints[i]) { m = rule.multipliers[i]; break; }
  }
  return m;
}

export const MODULE_KEYS = [
  'visual',
  'repeatability',
  'eccentricity',
  'discrimination',
  'weighing',
  'zero',
  'tare',
  'price',
  'influence',
];

const fmt = (kg) => Number.parseFloat(kg.toFixed(6));

function roundToE(value, e) {
  if (!(e > 0)) return value;
  return fmt(Math.round(value / e) * e);
}

const clamp = (v, lo, hi) => Math.min(Math.max(v, lo), hi);

export function suggestLoadPoints(db, { maxCapacityKg, minCapacityKg, eKg, dKg, accuracyClass }) {
  const max = Number(maxCapacityKg) || 0;
  const min = Math.max(0, Number(minCapacityKg) || 0);
  const e = Number(eKg) > 0 ? Number(eKg) : max / 1000; // sane fallback
  const d = Number(dKg) > 0 ? Number(dKg) : e;
  const cls = accuracyClass || 'III';
  const mpeFor = (load) => mpeInEFromDb(db, cls, load, e) ?? mpeInE(cls, load, e);

  const uniqSorted = (arr) => [...new Set(arr)].sort((a, b) => a - b);

  // --- Weighing test: Min, 500e, 2000e, 50% Max, Max (deduped, clamped to range)
  const rawPoints = [min, 500 * e, 2000 * e, roundToE(max * 0.5, e), max]
    .map((v) => clamp(roundToE(v, e), min, max));
  const increasing = uniqSorted(rawPoints);
  const weighing = {
    increasing: increasing.map((load) => ({ load, mpeE: mpeFor(load) })),
    decreasing: [...increasing].reverse().map((load) => ({ load, mpeE: mpeFor(load) })),
  };

  // --- Repeatability: ~50% Max and ~90% Max, 3 readings each
  const repeatability = {
    readings: 3,
    loads: uniqSorted([roundToE(max * 0.5, e), roundToE(max * 0.9, e)]),
  };

  // --- Eccentricity: 1/3 of Max at 5 positions
  const eccentricity = {
    load: roundToE(max / 3, e),
    positions: ['Center', 'Front-Left', 'Front-Right', 'Back-Left', 'Back-Right'],
  };

  // --- Discrimination: low + high point, extra load 1.4d (mpe<=1e) or 2d above
  const discLow = clamp(roundToE(min > 0 ? min : 20 * e, e), min, max);
  const discPoints = uniqSorted([discLow, max]).map((load) => ({
    load,
    extraLoad: fmt(mpeFor(load) <= 1 ? 1.4 * d : 2 * d),
  }));

  // --- Zero setting & zero tracking
  const zero = {
    points: [0, fmt(0.5 * e), fmt(1 * e)],
  };

  // --- Tare: set tare near 1/3 Max, weigh net loads
  const tare = {
    suggestedTareLoad: roundToE(max / 3, e),
    netLoads: uniqSorted([roundToE(max * 0.1, e), roundToE(max * 0.5, e), max])
      .map((v) => clamp(v, 0, max)),
  };

  // --- Price computation
  const price = {
    suggestedUnitPrice: 1,
    loads: uniqSorted([roundToE(max * 0.1, e), roundToE(max * 0.5, e), max])
      .map((v) => clamp(v, 0, max)),
  };

  // --- Influence factors: temperature steps + warm-up drift checks
  const influence = {
    temperaturesC: [10, 20, 30],
    loadsPerTemp: increasing.slice(0, 3).concat(increasing.includes(max) ? [max] : []),
    warmUpMinutes: [30, 60],
  };

  return {
    meta: { maxCapacityKg: max, minCapacityKg: min, eKg: e, dKg: d, accuracyClass: cls },
    weighing,
    repeatability,
    eccentricity,
    discrimination: discPoints,
    zero,
    tare,
    price,
    influence,
  };
}
