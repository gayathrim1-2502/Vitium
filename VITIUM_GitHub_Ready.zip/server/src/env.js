// Loads server/.env into process.env at boot — zero dependencies (Node has no
// built-in auto-loader for .env, and adding dotenv is unnecessary).
// Rules:
//   - File path is resolved relative to this file, so it works no matter the cwd
//     (`node src/index.js`, `npm start`, watchdog, Render, …).
//   - Existing real environment variables always win over .env values, matching
//     dotenv semantics — so platform env vars (e.g. Render dashboard) override.
//   - Lines: KEY=VALUE; supports `export KEY=VALUE`, surrounding quotes,
//     inline comments after whitespace+#, blank lines and # comments.
// This module must be imported BEFORE anything reads process.env at startup.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const envPath = path.resolve(here, '..', '.env');

export function loadEnvFile() {
  let raw;
  try {
    raw = fs.readFileSync(envPath, 'utf8');
  } catch {
    return { loaded: false, path: envPath, keys: [] };
  }

  const keys = [];
  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const withoutExport = trimmed.replace(/^export\s+/, '');
    const eq = withoutExport.indexOf('=');
    if (eq <= 0) continue;
    const key = withoutExport.slice(0, eq).trim();
    let value = withoutExport.slice(eq + 1).trim();
    // Strip inline comments (only when preceded by whitespace) and wrapping quotes.
    const hashMatch = value.match(/\s+#/);
    if (hashMatch && !/^["']/.test(value)) value = value.slice(0, hashMatch.index).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    if (!key) continue;
    if (process.env[key] === undefined || process.env[key] === '') {
      process.env[key] = value;
      keys.push(key);
    }
  }
  return { loaded: true, path: envPath, keys };
}

const result = loadEnvFile();
if (result.loaded) {
  console.log(`[env] loaded server/.env (${result.keys.length} variable${result.keys.length === 1 ? '' : 's'}: ${result.keys.join(', ') || 'none applied'})`);
} else {
  console.log(`[env] no server/.env found at ${result.path} — using process environment only`);
}
