// ============================================================
// Session evaluation — compares captured readings against the
// configurable MPE rules and produces per-module verdicts plus
// an overall session verdict (used by reports and approvals).
// ============================================================

import { mpeInEFromDb, getMpeParams } from './mpeEngine.js';

const has = (v) => v !== null && v !== undefined && v !== '';
const num = (v) => (has(v) ? Number(v) : null);
const allPass = (checks) => checks.length > 0 && checks.every((c) => c.pass);

function evalVisual(data) {
  const keys = ['nameplateLegible', 'classMarking', 'levelIndicator', 'stampArea', 'dashProof', 'noDirtDamage'];
  const checks = keys.map((k) => ({
    label: k.replace(/([A-Z])/g, ' $1').replace(/^./, (s) => s.toUpperCase()),
    observed: data[k] ? 'Yes' : 'No',
    limit: 'Yes',
    pass: !!data[k],
  }));
  return { checks, verdict: allPass(checks) ? 'pass' : 'fail', requirement: 'All administrative/visual requirements satisfied' };
}

function evalEccentricity(db, cls, eKg, data, params) {
  const positions = ['Center', 'Front-Left', 'Front-Right', 'Back-Left', 'Back-Right'];
  const factor = Number(params.eccentricity_mpe_factor ?? 1);
  const checks = [];
  for (const p of positions) {
    const err = num(data[p]?.error);
    if (!has(err)) continue;
    const limit = (mpeInEFromDb(db, cls, 1, eKg) ?? 1) * factor; // load is in the low band
    checks.push({ label: p, observed: `${err} kg`, limit: `≤ ${(limit * eKg).toFixed(4)} kg (${limit * factor}e)`, pass: Math.abs(err) <= limit * eKg + 1e-9 });
  }
  return { checks, verdict: allPass(checks) ? 'pass' : 'fail', requirement: `Error at each position within ${factor}× MPE` };
}

function evalRepeatability(db, cls, eKg, data, params) {
  const key = `repeatability_${String(cls).toLowerCase()}_readings`;
  const minReadings = Number(params[key] ?? 3);
  const checks = [];
  let maxSpread = 0;
  for (const [i, row] of (data.readings || []).entries()) {
    const vals = [num(row.r1), num(row.r2), num(row.r3)].filter(has);
    if (vals.length < 2) continue;
    const spread = Math.max(...vals) - Math.min(...vals);
    maxSpread = Math.max(maxSpread, spread);
    const limitE = mpeInEFromDb(db, cls, Number(row.load) || 0, eKg) ?? 1;
    checks.push({
      label: `Load ${i + 1} (${row.load ?? '—'} kg)`,
      observed: `spread ${spread.toFixed(4)} kg`,
      limit: `≤ ${(limitE * eKg).toFixed(4)} kg (${limitE}e, R 76-1 3.5.2)`,
      pass: spread <= limitE * eKg + 1e-9,
    });
  }
  const enoughReadings = (data.readings || []).every((r) => [r.r1, r.r2, r.r3].filter(has).length >= minReadings);
  return { checks, verdict: allPass(checks) && enoughReadings && checks.length > 0 ? 'pass' : 'fail', requirement: `Difference between multiple weighings of the same load ≤ MPE` };
}

function evalDiscrimination(db, cls, eKg, dKg, data, params) {
  const checks = [];
  for (const [i, row] of (data.points || []).entries()) {
    if (!has(row.load) && !has(row.extraLoad)) continue;
    checks.push({
      label: `Point ${i + 1} (${row.load ?? '—'} kg + ${row.extraLoad ?? '—'} kg extra)`,
      observed: row.changed ? 'indication changed' : 'no change / not recorded',
      limit: `must change at +${Number(params.discrimination_extra_low ?? 1.4)}d (≤1e band) or +${Number(params.discrimination_extra_high ?? 2)}d`,
      pass: !!row.changed,
    });
  }
  return { checks, verdict: allPass(checks) ? 'pass' : 'fail', requirement: 'Indication must change visibly when extra load is applied' };
}

function evalWeighing(db, cls, eKg, data) {
  const checks = [];
  for (const dir of ['increasing', 'decreasing']) {
    (data[dir] || []).forEach((row) => {
      const load = num(row.load);
      const err = num(row.error);
      if (!has(err)) return;
      const limitE = mpeInEFromDb(db, cls, has(load) ? load : 0, eKg) ?? 1.5;
      checks.push({
        label: `${dir === 'increasing' ? '↑' : '↓'} ${has(load) ? `${load} kg` : 'point'}`,
        observed: `${err} kg`,
        limit: `≤ ±${(limitE * eKg).toFixed(4)} kg (${limitE}e)`,
        pass: Math.abs(err) <= limitE * eKg + 1e-9,
      });
    });
  }
  return { checks, verdict: allPass(checks) ? 'pass' : 'fail', requirement: 'Error of indication within MPE at each load, increasing & decreasing' };
}

function evalZero(db, cls, eKg, data) {
  const checks = [];
  for (const [i, row] of Object.entries(data.rows || {})) {
    if (!has(row.value) && !row.ok) continue;
    checks.push({
      label: ['Initial zero', 'After 0.5e correction', 'After 1e correction', 'Zero-tracking 15 min'][i] || `Check ${i}`,
      observed: has(row.value) ? `${row.value} kg` : 'not recorded',
      limit: 'returns to zero',
      pass: !!row.ok,
    });
  }
  return { checks, verdict: allPass(checks) ? 'pass' : 'fail', requirement: 'Zero-setting and zero-tracking restore zero correctly' };
}

function evalTare(db, cls, eKg, data) {
  const checks = [];
  (data.netRows || []).forEach((row, i) => {
    const err = num(row.error);
    if (!has(err)) return;
    const indication = num(row.indication);
    const load = has(indication) ? indication : 0;
    const limitE = mpeInEFromDb(db, cls, load, eKg) ?? 1.5;
    checks.push({
      label: `Net load row ${i + 1}${has(indication) ? ` (${indication} kg)` : ''}`,
      observed: `${err} kg`,
      limit: `≤ ±${(limitE * eKg).toFixed(4)} kg (${limitE}e)`,
      pass: Math.abs(err) <= limitE * eKg + 1e-9,
    });
  });
  return { checks, verdict: allPass(checks) ? 'pass' : 'fail', requirement: 'Tare setting accurate; net indications within MPE' };
}

function evalPrice(db, cls, eKg, data) {
  if (data.applicable === 'no') {
    return { checks: [{ label: 'Price computation', observed: 'not applicable (non price-indicating)', limit: '—', pass: true }], verdict: 'pass', requirement: 'Applies to price-indicating instruments only' };
  }
  const checks = [];
  for (const [i, row] of (data.rows || []).entries()) {
    const disp = num(row.displayed);
    const exp = num(row.expected);
    if (!has(disp) && !has(exp)) continue;
    const tol = (mpeInEFromDb(db, cls, 1, eKg) ?? 1) * eKg;
    checks.push({
      label: `Load row ${i + 1}`,
      observed: `displayed ${disp ?? '—'} vs expected ${exp ?? '—'}`,
      limit: `≤ ±${tol.toFixed(4)} kg-equivalent (1e)`,
      pass: has(disp) && has(exp) && Math.abs(disp - exp) <= tol + 1e-9,
    });
  }
  return { checks, verdict: allPass(checks) ? 'pass' : 'fail', requirement: 'Indicated price = unit price × weight within 1e' };
}

function evalInfluence(db, cls, eKg, data) {
  const checks = [];
  (data.temps || []).forEach((row, i) => {
    const err = num(row.error);
    if (!has(err)) return;
    const indication = num(row.indication);
    const load = has(indication) ? indication : 0;
    const limitE = mpeInEFromDb(db, cls, load, eKg) ?? 1.5; // R-76: MPE applies at test load
    checks.push({
      label: `Temp point ${i + 1} (${row.actual ?? '—'}°C)`,
      observed: `${err} kg`,
      limit: `≤ ±${(limitE * eKg).toFixed(4)} kg (${limitE}e)`,
      pass: Math.abs(err) <= limitE * eKg + 1e-9,
    });
  });
  const w30 = num(data.warmUp30);
  const w60 = num(data.warmUp60);
  if (has(w30) || has(w60)) {
    const load = has(w60) ? w60 : w30;
    const limitE = mpeInEFromDb(db, cls, has(load) ? load : 0, eKg) ?? 1.5;
    checks.push({
      label: 'Warm-up drift (30→60 min)',
      observed: has(w30) && has(w60) ? `${Math.abs(w60 - w30).toFixed(4)} kg drift` : 'not fully recorded',
      limit: `≤ ${(limitE * eKg).toFixed(4)} kg (${limitE}e)`,
      pass: has(w30) && has(w60) && Math.abs(w60 - w30) <= limitE * eKg + 1e-9,
    });
  }
  return { checks, verdict: allPass(checks) ? 'pass' : 'fail', requirement: 'Results within MPE across temperature range and after warm-up' };
}

// Evaluate the modules of a session. `checklist` limits evaluation to the
// instrument type's configured modules (VITIUM type-based checklists); when
// omitted, all 9 standard modules are evaluated.
// Returns { modules: { key: { verdict, checks, requirement } }, overall, completedCount, requiredCount, checklist }
export function evaluateSession(db, instrument, tests, checklist = null) {
  const cls = instrument.accuracy_class;
  const eKg = Number(instrument.e_kg || 0);
  const dKg = Number(instrument.d_kg || eKg);
  const params = getMpeParams(db);

  const evaluators = {
    visual: () => evalVisual(tests.visual?.data || {}),
    repeatability: () => evalRepeatability(db, cls, eKg, tests.repeatability?.data || {}, params),
    eccentricity: () => evalEccentricity(db, cls, eKg, tests.eccentricity?.data || {}, params),
    discrimination: () => evalDiscrimination(db, cls, eKg, dKg, tests.discrimination?.data || {}, params),
    weighing: () => evalWeighing(db, cls, eKg, tests.weighing?.data || {}),
    zero: () => evalZero(db, cls, eKg, tests.zero?.data || {}),
    tare: () => evalTare(db, cls, eKg, tests.tare?.data || {}),
    price: () => evalPrice(db, cls, eKg, tests.price?.data || {}),
    influence: () => evalInfluence(db, cls, eKg, tests.influence?.data || {}),
  };

  const requiredKeys = Array.isArray(checklist) && checklist.length ? checklist.filter((k) => evaluators[k]) : Object.keys(evaluators);

  const modules = {};
  for (const key of requiredKeys) {
    modules[key] = evaluators[key]();
  }

  const completedCount = requiredKeys.filter((k) => tests?.[k]?.completed).length;
  const requiredCount = requiredKeys.length;
  const allCompleted = completedCount >= requiredCount;
  const allPassing = Object.values(modules).every((m) => m.verdict === 'pass');

  return {
    modules,
    completedCount,
    requiredCount,
    checklist: requiredKeys,
    allCompleted,
    overall: !allCompleted ? 'incomplete' : allPassing ? 'pass' : 'fail',
  };
}
