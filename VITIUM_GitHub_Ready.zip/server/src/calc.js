// ============================================================
// VITIUM calculation engine — pure functions, no UI, no DB.
// Everything here is deterministic and unit-testable.
// Stored snapshots reference the standard text below so any
// historical result remains reproducible.
// ============================================================

export const STANDARD_REF = 'OIML R 76-1 (2012) — MPE bands from mpe_rules table (snapshot stored per test result)';

/** ERROR = INDICATED − REFERENCE (signed). */
export function calculateError(referenceValue, indicationValue) {
  const r = Number(referenceValue);
  const i = Number(indicationValue);
  if (!Number.isFinite(r) || !Number.isFinite(i)) return null;
  return round6(i - r);
}

/** PASS when |error| ≤ MPE, FAIL otherwise; null when either input is missing. */
export function calculateResult(error, mpeKg) {
  const e = Number(error);
  const m = Number(mpeKg);
  if (!Number.isFinite(e) || !Number.isFinite(m)) return null;
  return Math.abs(e) <= m + 1e-9 ? 'pass' : 'fail';
}

/** MPE in kg for a load: looks up the class bands (in units of e) and scales by e. */
export function calculateMPE(db, accuracyClass, loadKg, eKg) {
  const n = eKg > 0 ? Number(loadKg) / eKg : 0;
  const bands = db.prepare('SELECT from_e, to_e, mpe_e FROM mpe_rules WHERE class = ? ORDER BY from_e').all(accuracyClass);
  for (const b of bands) {
    const to = b.to_e === null ? Infinity : b.to_e;
    if (n >= b.from_e && n < to) {
      return { mpeKg: round6(b.mpe_e * eKg), mpeE: b.mpe_e, bandFromE: b.from_e, bandToE: b.to_e };
    }
  }
  return null;
}

/**
 * Evaluate a measurement row: error, MPE, result, plus the exact standard
 * snapshot so the stored value is reproducible later.
 */
export function evaluateMeasurement(db, { accuracyClass, loadKg, referenceValue, indicationValue, eKg, toleranceKg }) {
  const error = calculateError(referenceValue, indicationValue);
  let mpe = null;
  if (Number.isFinite(toleranceKg)) {
    mpe = { mpeKg: round6(Number(toleranceKg)), mpeE: null, source: 'custom tolerance' };
  } else {
    const lookedUp = calculateMPE(db, accuracyClass, loadKg ?? referenceValue ?? 0, eKg);
    if (lookedUp) mpe = { ...lookedUp, source: STANDARD_REF };
  }
  const result = error !== null && mpe ? calculateResult(error, mpe.mpeKg) : null;
  return {
    error,
    mpeKg: mpe?.mpeKg ?? null,
    mpeE: mpe?.mpeE ?? null,
    result, // 'pass' | 'fail' | null (pending)
    standard: mpe ? `${mpe.source}${mpe.mpeE != null ? ` · ${mpe.mpeE}e at ≥${mpe.bandFromE ?? 0}e` : ''}` : null,
  };
}

/** VTM-INS-000001 style codes. */
export function instrumentCode(id) {
  return `VTM-INS-${String(id).padStart(6, '0')}`;
}

/** VTM-CERT-2026-000001 style numbers. */
export function certificateNumber(db) {
  const year = new Date().getFullYear();
  const prefix = `VTM-CERT-${year}-`;
  const row = db.prepare("SELECT cert_number FROM certificates WHERE cert_number LIKE ? ORDER BY cert_number DESC LIMIT 1").get(`${prefix}%`);
  const lastSeq = row ? Number(row.cert_number.slice(prefix.length)) : 0;
  return `${prefix}${String((Number.isFinite(lastSeq) ? lastSeq : 0) + 1).padStart(6, '0')}`;
}

/** Certificate validity: expiry = verification + validityMonths (default 12). */
export function certificateValidity(verificationDate, validityMonths = 12) {
  const d = verificationDate ? new Date(String(verificationDate).slice(0, 10) + 'T00:00:00') : new Date();
  if (Number.isNaN(d.getTime())) return { validUntil: null, validityMonths };
  const until = new Date(d);
  until.setMonth(until.getMonth() + Number(validityMonths) || 12);
  until.setDate(until.getDate() - 1);
  return { validUntil: until.toISOString().slice(0, 10), validityMonths: Number(validityMonths) || 12 };
}

/** VALID / EXPIRING SOON / EXPIRED badge state. */
export function certStatus(validUntil, warnDays = 30) {
  if (!validUntil) return { status: 'VALID', days: null };
  const days = Math.ceil((new Date(validUntil + 'T00:00:00') - new Date(new Date().toDateString())) / 86400000);
  if (days < 0) return { status: 'EXPIRED', days };
  if (days <= warnDays) return { status: 'EXPIRING SOON', days };
  return { status: 'VALID', days };
}

export function round6(x) {
  return Math.round(Number(x) * 1e6) / 1e6;
}
