// Resets server/data/nawi.db and re-seeds demo data.
// Demo users/instruments/sessions are opt-in (SEED_DEMO=1) so regular boots
// never fabricate records; this script is the one place that asks for them.
import fs from 'node:fs';
process.env.SEED_DEMO = '1';
const { DB_PATH, initDb } = await import('./db.js');

for (const suffix of ['', '-wal', '-shm']) {
  const p = DB_PATH + suffix;
  if (fs.existsSync(p)) fs.rmSync(p);
}
initDb();
console.log('Database reset and seeded at', DB_PATH);
