// Minimal SMTP email sender built on Node's built-in net/tls modules — no extra
// dependencies. Configure with environment variables:
//   SMTP_HOST, SMTP_PORT (587 default, 465 for implicit TLS), SMTP_USER,
//   SMTP_PASS, SMTP_SECURE ("true" for implicit TLS), MAIL_FROM, SMTP_EHLO
// When SMTP is not configured the app runs in demo mode: verification codes are
// printed to the server console (and returned to the client as demo codes) so
// the signup flow stays fully testable without a mail provider.
import net from 'node:net';
import tls from 'node:tls';
import crypto from 'node:crypto';

export function smtpConfigured() {
  return Boolean(
    String(process.env.SMTP_HOST || '').trim() &&
    String(process.env.SMTP_USER || '').trim() &&
    String(process.env.SMTP_PASS || '').trim()
  );
}

// Log the effective SMTP configuration once at boot so misconfiguration is
// obvious from the console without exposing the password.
export function logSmtpStatus() {
  if (!smtpConfigured()) {
    console.log('[mailer] SMTP not configured — running in DEMO mode (verification codes are printed to the console and shown on screen).');
    console.log('[mailer] To send real emails set SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS (and optionally SMTP_SECURE, MAIL_FROM) in server/.env.');
    return;
  }
  const host = String(process.env.SMTP_HOST).trim();
  const port = Number(process.env.SMTP_PORT) || (process.env.SMTP_SECURE === 'true' ? 465 : 587);
  const secure = process.env.SMTP_SECURE === 'true' || port === 465;
  const from = String(process.env.MAIL_FROM || process.env.SMTP_USER).trim();
  console.log(`[mailer] SMTP enabled → ${host}:${port} (${secure ? 'implicit TLS' : 'STARTTLS'}) · from: ${from} · user: ${String(process.env.SMTP_USER).trim()}`);
}

// Turn low-level SMTP/socket failures into actionable console diagnostics.
function logSmtpFailure(to, e) {
  const msg = String(e && e.message ? e.message : e);
  const lines = [`[mailer] ✗ Failed to send email to ${to}: ${msg}`];
  if (/530|535|authentication|AUTH/i.test(msg)) {
    lines.push('[mailer]   ↳ Authentication rejected by the server. For Gmail, SMTP_PASS must be a 16-character App Password (not your login password), with 2-Step Verification enabled.');
  }
  if (/timeout|timed out|ETIMEDOUT|ECONNREFUSED|EHOSTUNREACH|ENOTFOUND|getaddrinfo/i.test(msg)) {
    lines.push('[mailer]   ↳ Could not reach the SMTP server. Check SMTP_HOST/SMTP_PORT, your firewall, and outbound access on that port.');
  }
  if (/certificate|TLS|SSL|handshake/i.test(msg)) {
    lines.push('[mailer]   ↳ TLS problem. Use SMTP_SECURE=false with port 587 (STARTTLS) or SMTP_SECURE=true with port 465 (implicit TLS).');
  }
  if (/550|551|553|554|recipient|rejected/i.test(msg)) {
    lines.push('[mailer]   ↳ Message or recipient rejected by the server. Verify MAIL_FROM is an address allowed by the provider.');
  }
  console.error(lines.join('\n'));
}

function readReply(sock) {
  return new Promise((resolve, reject) => {
    let buf = '';
    const lines = [];
    function onData(chunk) {
      buf += chunk.toString('utf8');
      let idx;
      while ((idx = buf.indexOf('\r\n')) !== -1) {
        const line = buf.slice(0, idx);
        buf = buf.slice(idx + 2);
        lines.push(line);
        // A reply is complete when a line is "NNN <text>" (space after the code).
        if (/^\d{3} /.test(line)) {
          cleanup();
          resolve({ code: Number(line.slice(0, 3)), lines });
        }
      }
    }
    function onErr(e) { cleanup(); reject(e); }
    function onClose() { cleanup(); reject(new Error('SMTP connection closed unexpectedly')); }
    function cleanup() {
      sock.off('data', onData);
      sock.off('error', onErr);
      sock.off('close', onClose);
    }
    sock.on('data', onData);
    sock.once('error', onErr);
    sock.once('close', onClose);
  });
}

async function smtpExchange({ to, subject, html, text }) {
  const host = String(process.env.SMTP_HOST).trim();
  const port = Number(process.env.SMTP_PORT) || (process.env.SMTP_SECURE === 'true' ? 465 : 587);
  const secure = process.env.SMTP_SECURE === 'true' || port === 465;
  const user = String(process.env.SMTP_USER).trim();
  const pass = String(process.env.SMTP_PASS);
  const from = String(process.env.MAIL_FROM || process.env.SMTP_USER).trim();
  const ehloName = String(process.env.SMTP_EHLO || 'nawitestpro.local').trim();

  let sock = secure
    ? tls.connect({ host, port, servername: host })
    : net.connect({ host, port });

  await new Promise((resolve, reject) => {
    const t = setTimeout(() => { sock.destroy(); reject(new Error('SMTP connection timeout')); }, 15000);
    const onUp = () => { clearTimeout(t); sock.removeListener('error', onFail); resolve(); };
    const onFail = (e) => { clearTimeout(t); reject(e); };
    sock.once(secure ? 'secureConnect' : 'connect', onUp);
    sock.once('error', onFail);
  });

  const reply = () => readReply(sock);
  const cmd = async (line) => {
    sock.write(line + '\r\n');
    const r = await reply();
    if (r.code >= 400) throw new Error(`SMTP ${r.code}: ${r.lines.join(' | ')}`);
    return r;
  };

  try {
    const greeting = await reply();
    if (greeting.code >= 400) throw new Error(`SMTP greeting refused (${greeting.code})`);

    await cmd(`EHLO ${ehloName}`);

    if (!secure) {
      // Opportunistic STARTTLS when the server advertises it.
      const caps = await cmd('EHLO ' + ehloName); // re-read capabilities cleanly
      if (caps.lines.some((l) => l.toUpperCase().includes('STARTTLS'))) {
        await cmd('STARTTLS');
        const tlsSock = tls.connect({ socket: sock, servername: host });
        await new Promise((resolve, reject) => {
          tlsSock.once('error', reject);
          tlsSock.once('secureConnect', resolve);
        });
        sock = tlsSock;
        await cmd(`EHLO ${ehloName}`);
      }
    }

    // AUTH PLAIN first, fall back to AUTH LOGIN for servers that refuse PLAIN.
    const plain = Buffer.from(`\u0000${user}\u0000${pass}`).toString('base64');
    try {
      await cmd(`AUTH PLAIN ${plain}`);
    } catch {
      await cmd('AUTH LOGIN');
      await cmd(Buffer.from(user).toString('base64'));
      await cmd(Buffer.from(pass).toString('base64'));
    }

    await cmd(`MAIL FROM:<${from}>`);
    await cmd(`RCPT TO:<${to}>`);
    await cmd('DATA');

    const boundary = 'nawi-' + crypto.randomBytes(12).toString('hex');
    const body = [
      `--${boundary}`,
      'Content-Type: text/plain; charset=UTF-8',
      '',
      text,
      `--${boundary}`,
      'Content-Type: text/html; charset=UTF-8',
      '',
      html,
      `--${boundary}--`,
      '',
    ].join('\r\n').replace(/(^|\r\n)\./g, '$1..'); // dot-stuffing per RFC 5321

    sock.write(
      [
        `From: VITIUM <${from}>`,
        `To: ${to}`,
        `Subject: ${subject}`,
        'MIME-Version: 1.0',
        `Content-Type: multipart/alternative; boundary="${boundary}"`,
        '',
      ].join('\r\n') + '\r\n' + body + '\r\n.\r\n'
    );
    const sent = await reply();
    if (sent.code >= 400) throw new Error(`SMTP ${sent.code}: message rejected`);
    await cmd('QUIT');
    return { delivered: true, demo: false };
  } finally {
    sock.destroy();
  }
}

export async function sendMail({ to, subject, html, text }) {
  if (!smtpConfigured()) return { delivered: false, demo: true, error: 'SMTP not configured' };
  try {
    await Promise.race([
      smtpExchange({ to, subject, html, text }),
      new Promise((_res, rej) => setTimeout(() => rej(new Error('SMTP exchange timed out')), 25000)),
    ]);
    return { delivered: true, demo: false };
  } catch (e) {
    logSmtpFailure(to, e);
    return { delivered: false, demo: false, error: e.message };
  }
}

export function otpEmailHtml(name, code) {
  const safeName = String(name || 'there').replace(/[<>&]/g, '');
  return `<!doctype html>
<html>
  <body style="margin:0;padding:0;background:#F5E6D3;font-family:'Segoe UI',Arial,Helvetica,sans-serif;">
    <div style="max-width:520px;margin:0 auto;padding:32px 20px;">
      <div style="background:linear-gradient(135deg,#C88A5A,#8B5E3C);border-radius:20px 20px 0 0;padding:26px 28px;">
        <p style="margin:0;font-size:20px;font-weight:800;color:#F5E6D3;">⚖️ VITIUM</p>
        <p style="margin:4px 0 0;font-size:12px;font-weight:600;color:#D9B77A;">OIML R-76 Compliance Suite</p>
      </div>
      <div style="background:#E9E4D4;border:1px solid #D9B77A;border-top:none;border-radius:0 0 20px 20px;padding:30px 28px;">
        <p style="margin:0 0 6px;font-size:18px;font-weight:800;color:#30382F;">Hi ${safeName},</p>
        <p style="margin:0 0 20px;font-size:14px;line-height:1.6;color:#65745D;">
          Use this one-time code to verify your email address and activate your VITIUM account.
        </p>
        <div style="background:#F5E6D3;border:1px solid #D9B77A;border-radius:14px;text-align:center;padding:20px;margin:0 0 18px;">
          <p style="margin:0;font-size:34px;letter-spacing:10px;font-weight:800;color:#3B2720;">${code}</p>
        </div>
        <p style="margin:0 0 6px;font-size:13px;color:#65745D;">This code expires in <strong style="color:#3B2720;">10 minutes</strong>.</p>
        <p style="margin:0;font-size:13px;color:#65745D;">Didn't request it? You can safely ignore this email — no account will be created without verification.</p>
      </div>
      <p style="margin:16px 0 0;text-align:center;font-size:11px;color:#65745D;">
        Non-Automatic Weighing Instruments · Legal Metrology
      </p>
    </div>
  </body>
</html>`;
}

export function otpEmailText(name, code) {
  return `Hi ${name || 'there'},

Your VITIUM email verification code is: ${code}

It expires in 10 minutes. If you didn't request it, you can safely ignore this email.

— VITIUM (OIML R-76 Compliance Suite)`;
}
