// Must be the first import: loads server/.env into process.env before any
// module reads configuration (SMTP settings, JWT_SECRET, PORT, …).
import './env.js';
import express from 'express';
import cors from 'cors';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import api from './routes.js';
import { logSmtpStatus } from './mailer.js';

const app = express();
app.use(cors());
app.use(express.json());

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'VITIUM API' }));

app.use('/api', api);

// 404 for unknown API routes
app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found' }));

// Serve the built client when it is present, so the whole app (SPA + API) can be
// hosted as one process on one origin. In development the Vite dev server owns
// the frontend and proxies /api here, so this stays dormant.
const here = path.dirname(fileURLToPath(import.meta.url));
const clientDist = process.env.CLIENT_DIST
  ? path.resolve(process.env.CLIENT_DIST)
  : path.resolve(here, '../../client/dist');
const clientIndex = path.join(clientDist, 'index.html');

if (fs.existsSync(clientIndex)) {
  app.use(express.static(clientDist));
  // SPA fallback: deep links like /verify/<reportUid> must render the app, not 404.
  app.get(/^(?!\/api\/).*/, (_req, res) => res.sendFile(clientIndex));
  console.log(`VITIUM serving client build from ${clientDist}`);
}

// centralized error handler
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

const PORT = Number(process.env.PORT) > 0 ? Number(process.env.PORT) : 4000;
app.listen(PORT, () => {
  console.log(`VITIUM API listening on http://localhost:${PORT}`);
  logSmtpStatus();
});
