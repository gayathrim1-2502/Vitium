import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-nawi-testpro';
const TOKEN_TTL = '12h';

export function signToken(user) {
  // fullName/ownerOf mirror the DB columns the scoping helpers read
  // (businessScopeSql / canAccessInstrument); `name` is kept for the approval
  // snapshot signer. Tokens issued before this claim set still work because the
  // helpers fall back to `name`.
  return jwt.sign(
    {
      sub: user.id,
      role: user.role,
      name: user.full_name,
      fullName: user.full_name,
      email: user.email,
      ownerOf: user.owner_of || '',
    },
    JWT_SECRET,
    { expiresIn: TOKEN_TTL }
  );
}

export function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Authentication required' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid or expired session' });
  }
}

// authorize('admin', 'approver') -> allows those roles only
export function authorize(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Forbidden — insufficient role' });
    }
    next();
  };
}
