# VITIUM

Legal Metrology **Instrument Verification & Certification Platform** for Non-Automatic Weighing Instruments (NAWI), compliant with **OIML R-76** — instrument registry with QR/barcode IDs, type-based test checklists, MPE evaluation, GPS-stamped evidence, digital approvals and auto-generated certificates of verification.

## Stack

- **Frontend:** React 18 + Vite + Tailwind CSS v4 + React Router + lucide-react icons
- **Backend:** Express (ES modules) REST API
- **Database:** SQLite (real SQL, file-persisted at `server/data/nawi.db`) via Node's built-in `node:sqlite` — no native compilation needed
- **Auth:** JWT (12h expiry) + bcryptjs password hashing + role middleware

## Quick start

```bash
npm install
npm run dev        # runs API (port 4000) + web (port 5173) together
```

Open http://localhost:5173

Other commands:

```bash
npm run build      # production build of the client
npm run seed:reset # wipe + reseed the SQLite database with demo data
npm run dev:server # API only
npm run dev:client # web only
```

## Demo accounts

| Role          | Email                        | Password     | Lands on     |
| ------------- | ---------------------------- | ------------ | ------------ |
| Test Engineer | engineer@nawitestpro.com     | engineer123  | /dashboard   |
| Approver      | approver@nawitestpro.com     | approver123  | /reports     |
| Admin         | admin@nawitestpro.com        | admin123     | /dashboard   |
| Instrument Owner (business) | owner@nawitestpro.com | owner12345 | /instruments |

## Email verification (sign-up OTP)

New users can self-register on the login page (Engineer or Approver). Accounts are created unverified and a 6-digit one-time code must be confirmed before the account is activated.

**Demo mode (default):** if SMTP is not configured, the code is shown on the verification screen and printed in the server console — the flow is fully testable without a mail provider.

**Real emails:** set these environment variables when starting the server and the OTP is emailed instead (no extra npm dependencies — the server speaks SMTP directly):

```bash
SMTP_HOST=smtp.gmail.com   # or your provider's host
SMTP_PORT=587              # 465 for implicit TLS
SMTP_USER=you@gmail.com
SMTP_PASS=your-app-password
MAIL_FROM=you@gmail.com    # optional, defaults to SMTP_USER
SMTP_SECURE=false          # true for port 465
```

## Roles & permissions

| Capability                          | Engineer | Approver | Admin |
| ----------------------------------- | :------: | :------: | :---: |
| View dashboard, instruments, sessions, reports | ✅ | ✅ | ✅ |
| Create/edit test sessions           | ✅       | —        | ✅    |
| Approve/reject + digitally sign (phase 2) | —  | ✅       | —     |
| Manage users                        | —        | —        | ✅    |
| Manage instruments (create/edit)    | —        | —        | ✅    |
| Organisation settings               | —        | —        | ✅    |

## API overview (`/api`)

- `POST /auth/login`, `GET /auth/me`
- `POST /auth/register` — self sign-up (Engineer/Approver roles); creates an unverified account and emails a 6-digit OTP
- `POST /auth/verify-otp` — verify the emailed code; activates the account and returns a JWT
- `POST /auth/resend-otp` — re-send the code (45s cooldown, max 5 attempts per code, 10-min expiry)
- `GET /dashboard` — KPIs + recent sessions
- `GET /instruments`, `POST /instruments` (admin), `PATCH /instruments/:id` (admin) — full master data (manufacturer, model, S/N, class, Max/Min, e, d, tare range, applicant, lab, date) + derived test status (Not Tested / In Progress / Passed / Failed)
- `GET /sessions`, `POST /sessions` — creating a session auto-suggests OIML R-76 load points from Max/Min/e/class
- `GET /sessions/:id` — session + instrument + saved module data + suggested load points
- `PUT /sessions/:id/tests/:moduleKey` — save one of the 9 test modules (visual, repeatability, eccentricity, discrimination, weighing, zero, tare, price, influence)
- `PUT /sessions/:id/status` — draft ⇄ in_progress transitions and submit gate (all 9 modules must be complete)
- `GET /reports` — signed/approved sessions with approval metadata
- `GET|POST /users` (admin), `PATCH /users/:id` (admin)
- `GET|PUT /settings` (admin)
- `GET /mpe-rules` — MPE bands + tunable test parameters (stored in DB, editable via Settings)
- `GET /sessions/:id/report` — full evaluation + approval payload for the R 76-2 report page/PDF
- `PUT /sessions/:id/approval` (approver) — approve & e-sign, or reject with remarks
- `PUT /sessions/:id/reopen` (engineer) — send a rejected session back to editing
- `GET /instruments/:id/history` — session timeline + per-session max error for drift charts
- `GET /analytics` — pass rate by class, tests per month, top manufacturers
- `GET /notifications` — pending approvals (approvers), cert-expiry & re-verification alerts
- `GET /verify/:reportUid` — **public, no auth** — QR-code verification endpoint (read-only)

All endpoints except `/auth/login` and `/verify/:reportUid` require `Authorization: Bearer <token>`.

## Data model

`users` · `instruments` · `test_sessions` · `session_tests` · `approvals` · `org_settings` · `mpe_rules` · `mpe_params` · `notification_dismissals` — see `server/src/db.js` (schema + demo seed).

## Report verification (QR)

Every approved session gets a `report_uid`. The report page and downloaded PDF embed a QR code linking to `/verify/<report_uid>` — a public, login-free page showing report ID, instrument, approver, approval date and a "Verified Authentic" badge.

## Hosting

The API optionally serves the built client, so the whole app can run as **one process on one origin** (no separate web server, no CORS/proxy in production):

```bash
npm run build          # emits client/dist
npm run start -w server # serves the SPA + /api on PORT (default 4000)
```

Static serving activates only when `client/dist/index.html` exists; unknown non-`/api` routes fall back to the SPA so deep links such as `/verify/<reportUid>` resolve. In development the Vite dev server still owns the frontend and proxies `/api` to the API, so this path stays dormant.

The database is a file-backed SQLite DB (`server/data/nawi.db`), so hosting is a matter of running that single process behind whatever ingress you prefer (reverse proxy, tunnel, or container). Point one public URL at the process port and both the app and the API are reachable.

## Deploy (GitHub → Render)

GitHub Pages cannot host VITIUM (the Express + SQLite backend needs a server process), so the recommended free path is **code on GitHub, app on Render** — Render pulls the repo, builds, and gives you a permanent HTTPS URL:

1. **Push this repo to GitHub**
   ```bash
   git init -b main
   git add .
   git commit -m "VITIUM — Legal Metrology Verification & Certification Platform"
   git remote add origin https://github.com/<you>/vitium.git
   git push -u origin main
   ```
2. **On [render.com](https://render.com)** (sign in with GitHub): *New + → Blueprint* → select the repo. Render reads the included `render.yaml`: Node service, `npm install && npm run build`, `npm run start -w server`, auto-generated `JWT_SECRET`.
3. Deploy takes a few minutes; your app lands on `https://vitium-xxxx.onrender.com` (SPA + API on one origin). Demo data seeds itself on first boot.

Notes: free tier sleeps after ~15 min idle (first request takes ~30–60 s to wake) and SQLite resets on redeploys since the filesystem is ephemeral — fine for demos; add a Render Disk mounted at `server/data` (or switch to a hosted Postgres) for persistence.

## Environment

- `PORT` — API port (default 4000)
- `JWT_SECRET` — **must be set to a strong value whenever the app is publicly reachable**; it currently falls back to an in-repo dev secret, which would let anyone forge tokens
- `CLIENT_DIST` — optional override for the client build directory to serve
