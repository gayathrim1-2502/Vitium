# VITIUM — Redesign Regression Audit

**Baseline:** `0fe04b3 — Before VITIUM UI refinement` (the pre-redesign checkpoint)
**Audited state:** uncommitted working tree (the redesign); `HEAD` is still `0fe04b3`
**Date:** 2026-10-20

Scope note: every change in the working tree is inside `client/`. `server/`, root
`package.json`, `client/package.json` and `App.jsx` / routing are **unmodified**, so any
routing/authz behaviour observed below is either identical to baseline or pre-existing.

---

## 1. Files changed

Modified (23):

- `client/index.html`
- `client/src/index.css`
- `client/src/components/AppLayout.jsx`, `EmptyState.jsx`, `NotificationBell.jsx`, `ScanQrModal.jsx`, `charts.jsx`
- `client/src/pages/Analytics.jsx`, `ApprovalPanel.jsx`, `Dashboard.jsx`, `InstrumentDetail.jsx`, `Instruments.jsx`, `Knowledge.jsx`, `Login.jsx`, `Reports.jsx`, `SessionReport.jsx`, `Settings.jsx`, `TestSessionWizard.jsx`, `TestSessions.jsx`, `Users.jsx`, `VerifyPage.jsx`
- `client/src/tests/ModuleForms.jsx`

New (untracked, part of the redesign):

- `client/src/lib/useDialogFocus.js` — shared modal focus/Escape handling

Audit artefacts (untracked, from this audit, safe to delete): `screenshots/`.

No backend file, database, or business rule was touched during the audit.

---

## 2. Build and automated tests

| Check | Result |
| --- | --- |
| `npm run build` (Vite 6.4.3, production) | **PASS** — exit 0, 1910 modules, 43.4 s |
| Bundle output | `dist/index.html` 0.51 kB, `index-*.css` 70.33 kB (11.24 kB gzip), `index-*.js` 427.78 kB (124.57 kB gzip), logo 64.07 kB, jspdf/html2canvas chunks code-split |
| Automated tests | **NOT AVAILABLE** — no test runner in the repo. `client/package.json` scripts are `dev`, `build`, `preview` only; no `vitest`/`jest`/`playwright` dependency and no test config. `client/src/tests/*` are application modules (module forms, `evaluate.js`), not test suites. Nothing was fabricated as a passing test run. |
| Lint | **NOT AVAILABLE** — no ESLint/Prettier config or script exists in the project |
| Dev-mode console (Vite dev server, React 18 development build) | **CLEAN** — 13 routes walked (`/dashboard`, `/instruments`, `/instruments/:id`, `/sessions`, `/sessions/new`, `/sessions/:id`, `/sessions/:id/report`, `/reports`, `/analytics`, `/knowledge`, `/settings`, `/users`, `/verify/:uid`): zero React key / controlled-input / hook-dependency / `act()` warnings |
| Production console | No page errors (previous pass) |

The only console output in dev is react-router v6's own future-flag notices
(`v7_startTransition`, `v7_relativeSplatPath`) — library-level, present before the redesign.

---

## 3. Colour-preservation findings

Method: diff-mined every hex literal added/removed between `0fe04b3` and the working tree,
and diffed the Tailwind `@theme` block.

- Hex literals added: `#6E4A2F` ×4, `#65745D` ×4, `#C88A5A` ×3, `#8B5E3C` ×3, `#3B2720` ×3, `#30382F` ×2.
- Hex literals removed: `#65745D` ×4, `#C88A5A` ×3, `#8B5E3C` ×3, `#6E4A2F` ×3.
- Every one of those values is an existing token in `client/src/index.css`'s `@theme`
  block: `caramel #C88A5A`, `mocha #8B5E3C`, `errormocha #6E4A2F`, `espresso #3B2720`,
  `darkgreen #30382F`, `forestsage #65745D`, plus `cream`, `sagecream`, `softgold`,
  `mutedgold`, `sage` used only through utilities. **No new hue, no foreign colour, and no
  change to the palette definitions themselves** — the `@theme` colour block is byte-identical
  to baseline (the only hunk in that block adds font variables).
- New gradients stay on-brand: `linear-gradient(135deg, #C88A5A, #8B5E3C)` (primary buttons,
  gradient text), modal headers `#C88A5A → #8B5E3C → #6E4A2F`, dangerous/secondary gradients
  `#6E4A2F → #3B2720` and `#3B2720 → #30382F`. SVG chart text/axis fills use `#65745D`
  (forestsage) and palette values only.
- Focus ring / nav-active accent use `softgold #D9B77A` (verified live: keyboard Tab produces
  the soft-gold outline; sidebar active rail is `inset 3px 0 0 #D9B77A`).
- `.btn-danger` / `.link-danger` are new shared classes but resolve to `errormocha`, i.e. the
  existing danger colour, replacing ad-hoc per-page reds.

**Conclusion: colours are preserved; nothing needed reverting.**

One deliberate identity change was found (not a colour): `client/index.html` drops the Google
Fonts link and `index.css` swaps Plus Jakarta Sans for a native system stack, plus
`--font-weight-extrabold: 700` (remaps `font-extrabold` from 800 → 700). It is documented in
the CSS as an intentional typography decision, so it was **not** reverted — but it is a visible
brand change and should be a conscious sign-off. If the original typeface must survive, restore
the `<link>` in `client/index.html` and the `--font-sans` value.

---

## 4. Functional regressions found and fixed

**None.** No verified redesign-caused regression required a code change, so nothing was edited
in this pass. Findings below are either verified working or pre-existing (see §6).

Verified working in this pass (live, against a dev-mode instance and the built bundle):

- **Auth** — login form submits, wrong credentials show "Invalid email or password", demo-account
  "Fill →" helper present, session persists, `RequireAuth` redirects to `/login` without a token.
- **Routing/navigation** — sidebar groups render per role; `NAV_ITEMS` role arrays are identical
  to baseline; `/` redirects to each role's home (`ROLE_HOME`); unknown paths redirect home;
  `/verify/:uid` is public and outside the auth shell.
- **Instruments** — list renders 3 instruments with class/e, S/N, capacity and location; detail
  page renders history/drift sections; filter/status chips render; empty state renders.
- **Test sessions** — status tabs with counts, list table, empty state; New Session dialog
  (instrument select, reference standard, ambient temp/RH) creates a session and opens the wizard.
- **Wizard** — 9 module tabs, per-module guidance, "+ Add load block" row adds, number entry,
  Save enabled only when dirty, save → full reload keeps entered values (30 / 30.01 / 30.02 / 30).
- **Report** — `/sessions/:id/report` renders the OIML R-76 layout with verdict banner
  (INCOMPLETE for an in-progress session), instrument/applicant blocks, per-module tables and
  "Download PDF report" (PDF export produced a 177 KB file in the earlier pass; the artefact was
  deleted afterwards).
- **Public verification** — `/verify/:uid` renders the read-only "Report not found" state for an
  unknown code and is reachable without auth.
- **Role enforcement** — API returns 401 without a token and 403 for admin-only endpoints when
  signed in as an engineer; no page crashes on those 403s.
- **Accessibility basics** — modals move focus in, restore it on close and close on Escape via the
  new `useDialogFocus`; skip link present; focus ring visible.

---

## 5. Environment notes (state of the local database)

- `server/data/nawi.db` currently holds **3 users, 0 instruments, 0 test sessions, 0 certificates**
  (the two engineer accounts are real registrations, plus the business owner). The demo dataset is
  gone from this checkout; nothing was reseeded or modified by this audit.
- To exercise the wizard/report/detail screens, a throwaway copy of the API was run on a separate
  port with its own seeded database, plus a throwaway Vite dev config. Both were removed afterwards;
  no project file, config or database change was left behind.

---

## 6. Pre-existing defects found (NOT caused by the redesign, not fixed)

1. **Business-role reads return 500.** `server/src/auth.js` signs the JWT with `name`, but
   `businessScopeSql()` / `canAccessInstrument()` in `server/src/routes.js` read `user.fullName`
   and `user.ownerOf`. `user.fullName` is `undefined`, so SQLite fails with
   `TypeError: Provided value cannot be bound to SQLite parameter 2`. Reproduced with a fresh
   login: `POST /api/auth/login` 200, then `GET /api/instruments` **500**, `/api/reports` **500**,
   `/api/certificates` **500**. Server code and the client's endpoint calls are identical to
   baseline, so this predates the redesign — but it means the business/owner experience cannot be
   validated end-to-end until the claim mismatch is fixed (backend change, out of scope here).
2. **A fresh install seeds no demo data.** `db.js` inserts the business owner during a migration
   before `seedDemoUsers()` runs, and that function returns early when `users` is non-empty.
   A brand-new database therefore ends up with 1 user and 0 instruments/sessions, so first-run
   screens are all empty states. Also identical to baseline.

Minor pre-existing mismatch: the engineer nav shows *Analytics*, and direct visits to admin-only
pages surfaced 403s from `/users`-type endpoints. Nav rules and server rules both match baseline.

---

## 7. Manual checks still required

These were **not** performed and are not claimed as passing:

1. A complete 9-module measurement run with realistic data, MPE/evaluation verdicts per module,
   and mandatory-verification gating before submit.
2. Submit → approver review (ApprovalPanel) → approve → certificate number/issue, on an
   approved session (previous UI-level check of approval validation wiring only).
3. Public verification of a **real approved report** — `report_uid` is only generated at
   approval, so only the not-found state could be exercised here.
4. PDF/print output of an approved certificate (screen print CSS was inspected, not printed).
5. Admin-only surfaces (Users, Settings, audit log) — the current database has **no admin account**.
6. Real SMTP/OTP delivery — `server/.env` has SMTP configured, but the audit ran against a demo-mode
   copy, so only demo code paths were exercised.
7. Visual QA at real device widths, screen-reader pass, `prefers-reduced-motion` /
   `prefers-reduced-transparency` behaviour (CSS rules exist; only inspected, not tested on a
   device).

---

## 8. Remaining risks

- The typography change (system stack + extrabold→700) alters the visual identity even though all
  colours are preserved; it needs explicit sign-off.
- The business role is broken server-side, so the owner-facing UI is unverifiable and would show a
  generic error state where lists belong.
- The empty-workspace first-run state is what a new deployment shows; dashboards, analytics and
  reports are unexercised with data in this checkout.
- No automated tests or lint exist, so future regressions remain dependent on manual QA.
- `screenshots/` is untracked audit output; keep or delete deliberately.
